//! Motion page: same JSON colors/type/spacing, Scene and TextEngine as Gallery.
//! No host, window, renderer, timers or extra UI toolkit is created here.
use super::PageCtx;
use crate::gallery::motion_preview::{MotionPreview, Parameter, PresetCatalog};
use tekes_ui_motion::recipes::{Phase, RecipeKind};
use tekes_ui_platform_macos::{Event, MouseButton, MouseEventKind};
use tekes_ui_scene::{Point, Quad, Rect, Scene, Size};
use tekes_ui_tokens::{CornerRadius, Rgba, Spacing, Stroke, Theme, proposal};

pub const HEIGHT: f32 = 942.0;
const TARGETS: [f64; 3] = [0.15, 0.5, 0.85];

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Action {
    Catalog(PresetCatalog),
    Preset(usize),
    SymbolIcon(usize),
    Target(usize),
    Replay,
    Interrupt,
    ReduceMotion,
    Resume,
}

#[derive(Clone, Copy, Debug)]
pub struct Layout {
    pub content: Rect,
    pub stage: Rect,
    pub graph: Rect,
    pub inspector: Rect,
}
impl Layout {
    pub fn new(content: Rect) -> Self {
        // Keep the same minimum document width as extent(). Narrow windows
        // reveal this fixed fixture through the existing horizontal viewport.
        let content = Rect::new(
            content.min_x(),
            content.min_y(),
            content.size.width.max(840.0),
            HEIGHT,
        );
        let gap = Spacing::Loose.value();
        let side = 280.0;
        let left = content.size.width - side - gap;
        Self {
            content,
            stage: Rect::new(content.min_x(), content.min_y() + 270.0, left, 240.0),
            graph: Rect::new(content.min_x(), content.min_y() + 546.0, left, 180.0),
            inspector: Rect::new(
                content.min_x() + left + gap,
                content.min_y() + 270.0,
                side,
                456.0,
            ),
        }
    }
    pub fn button(self, action: Action) -> Rect {
        let x = self.content.min_x();
        let y = self.content.min_y();
        let gap = Spacing::Regular.value();
        match action {
            Action::Catalog(catalog) => Rect::new(
                x + match catalog {
                    PresetCatalog::Apple => 0.0,
                    PresetCatalog::DesignSystem => 156.0,
                    PresetCatalog::Recipes => 312.0,
                    PresetCatalog::Symbols => 468.0,
                },
                y,
                148.0,
                26.0,
            ),
            Action::SymbolIcon(i) => Rect::new(
                x + (i % 4) as f32 * ((self.content.size.width + gap) / 4.0),
                y + 168.0 + (i / 4) as f32 * 38.0,
                (self.content.size.width - 3.0 * gap) / 4.0,
                30.0,
            ),
            Action::Preset(i) => {
                let width = (self.content.size.width - 4.0 * gap) / 5.0;
                Rect::new(
                    x + (i % 5) as f32 * (width + gap),
                    y + 32.0 + (i / 5) as f32 * 42.0,
                    width,
                    34.0,
                )
            }
            Action::Target(i) => Rect::new(x + i as f32 * 92.0, y + 752.0, 84.0, 34.0),
            Action::Resume => Rect::new(x + 524.0, y + 752.0, 84.0, 34.0),
            Action::Replay => Rect::new(x + 284.0, y + 752.0, 84.0, 34.0),
            Action::Interrupt => Rect::new(x + 376.0, y + 752.0, 140.0, 34.0),
            Action::ReduceMotion => Rect::new(
                self.inspector.min_x() + 16.0,
                self.inspector.max_y() - 52.0,
                self.inspector.size.width - 32.0,
                34.0,
            ),
        }
    }
    pub fn slider(self, p: Parameter) -> Rect {
        let i = Parameter::ALL.iter().position(|a| *a == p).unwrap();
        Rect::new(
            self.inspector.min_x() + 20.0,
            self.inspector.min_y() + 72.0 + i as f32 * 82.0,
            self.inspector.size.width - 40.0,
            24.0,
        )
    }
    pub fn actions(self, count: usize) -> Vec<(Action, Rect)> {
        (0..count)
            .map(Action::Preset)
            .chain((0..3).map(Action::Target))
            .chain([
                Action::Replay,
                Action::Resume,
                Action::Interrupt,
                Action::ReduceMotion,
                Action::Catalog(PresetCatalog::Apple),
                Action::Catalog(PresetCatalog::DesignSystem),
                Action::Catalog(PresetCatalog::Recipes),
                Action::Catalog(PresetCatalog::Symbols),
            ])
            .map(|a| (a, self.button(a)))
            .collect()
    }
    pub(crate) fn state_actions(self, state: &MotionPreview) -> Vec<(Action, Rect)> {
        let mut actions = self.actions(state.presets.len());
        if state.catalog == PresetCatalog::Symbols {
            for (action, rect) in &mut actions {
                if matches!(
                    action,
                    Action::Target(_) | Action::Replay | Action::Resume | Action::Interrupt
                ) {
                    rect.origin.y = self.content.min_y() + 238.0;
                    rect.size.height = 26.0;
                }
            }
            actions.extend(
                (0..tekes_ui_icons::Icon::ALL.len())
                    .map(|i| (Action::SymbolIcon(i), self.button(Action::SymbolIcon(i)))),
            );
        }
        actions
    }
    pub fn reading_scroll(self, down: bool) -> Rect {
        Rect::new(
            self.stage.max_x() - if down { 108.0 } else { 200.0 },
            self.stage.max_y() - 36.0,
            84.0,
            26.0,
        )
    }
    pub fn track(self) -> Rect {
        self.stage.inset(32.0)
    }
}

pub fn extent(content: Rect) -> Size {
    Size::new(content.size.width.max(840.0), HEIGHT)
}

/// Pass the same live-content rectangle used by `build` and raw window event
/// positions together. The host applies viewport bounds routing first; a
/// captured slider must continue receiving drag/up outside those bounds.
#[cfg(test)]
pub fn handle_input(state: &mut MotionPreview, event: &Event, content: Rect) -> bool {
    handle_input_clipped(state, event, content, content)
}

/// `visible` is the renderer's clipped viewport in window coordinates. Keep
/// captured drags alive outside it, but never hover or activate clipped rows.
pub fn handle_input_clipped(
    state: &mut MotionPreview,
    event: &Event,
    content: Rect,
    visible: Rect,
) -> bool {
    let layout = Layout::new(content);
    let set_from_x = |state: &mut MotionPreview, p: Parameter, x: f32| {
        let r = layout.slider(p);
        let unit = ((x - r.min_x()) / r.size.width).clamp(0.0, 1.0);
        let (lo, hi) = state.parameter_range(p);
        state.set_parameter(p, lo + f64::from(unit) * (hi - lo))
    };
    match event {
        Event::Focus(false) => {
            let dirty =
                state.dragging.is_some() || state.hovered.is_some() || state.pressed.is_some();
            state.deactivate();
            dirty
        }
        Event::Mouse(mouse) => {
            let point = Point::new(mouse.position.x as f32, mouse.position.y as f32);
            let actions = layout.state_actions(state);
            let hit = visible
                .contains(point)
                .then(|| actions.iter().position(|(_, r)| r.contains(point)))
                .flatten();
            match mouse.kind {
                MouseEventKind::Down {
                    button: MouseButton::Left,
                    ..
                } => {
                    if !visible.contains(point) {
                        return false;
                    }
                    for p in Parameter::ALL {
                        if layout.slider(p).contains(point) && state.parameter_enabled(p) {
                            state.dragging = Some(p);
                            set_from_x(state, p, point.x);
                            return true;
                        }
                    }
                    if let Some(index) = hit {
                        state.pressed = Some(index);
                        return true;
                    }
                    if state.is_recipe() && state.recipe.kind == RecipeKind::Reading {
                        for down in [false, true] {
                            if layout.reading_scroll(down).contains(point) {
                                state.recipe.scroll_by(if down { 36.0 } else { -36.0 });
                                return true;
                            }
                        }
                    }
                    if state.is_recipe()
                        && state.recipe.kind == RecipeKind::Press
                        && layout.stage.contains(point)
                    {
                        state.retarget(0.85);
                        state.pressed = Some(usize::MAX - 1);
                        return true;
                    }
                    if state.is_recipe()
                        && state.recipe.kind == RecipeKind::DragSnap
                        && layout.stage.contains(point)
                    {
                        let track = layout.track();
                        state.drag_recipe(f64::from((point.x - track.min_x()) / track.size.width));
                        // Reuse the host's established captured-mouse route.
                        state.pressed = Some(usize::MAX);
                        return true;
                    }
                    if layout.stage.contains(point) {
                        let track = layout.track();
                        state.retarget(f64::from((point.x - track.min_x()) / track.size.width));
                        return true;
                    }
                    false
                }
                MouseEventKind::Dragged {
                    button: MouseButton::Left,
                } => {
                    if state.pressed == Some(usize::MAX - 1) {
                        state.retarget(if layout.stage.contains(point) {
                            0.85
                        } else {
                            0.15
                        });
                        true
                    } else if state.recipe_dragging {
                        let track = layout.track();
                        state.drag_recipe(f64::from((point.x - track.min_x()) / track.size.width));
                        true
                    } else {
                        state
                            .dragging
                            .is_some_and(|p| set_from_x(state, p, point.x))
                    }
                }
                MouseEventKind::Up {
                    button: MouseButton::Left,
                    ..
                } => {
                    if state.pressed == Some(usize::MAX - 1) {
                        state.retarget(0.15);
                        state.pressed = None;
                        return true;
                    }
                    if state.recipe_dragging {
                        state.release_recipe();
                        state.pressed = None;
                        return true;
                    }
                    if state.dragging.take().is_some() {
                        return true;
                    }
                    let pressed = state.pressed.take();
                    if let Some(index) = pressed.filter(|i| Some(*i) == hit) {
                        match actions[index].0 {
                            Action::Catalog(catalog) => {
                                state.select_catalog(catalog);
                            }
                            Action::SymbolIcon(i) => state.select_symbol_icon(i),
                            Action::Preset(i) => {
                                state.select(i);
                            }
                            Action::Target(i) => state.retarget(TARGETS[i]),
                            Action::Replay => state.replay(),
                            Action::Resume => {
                                if state.is_recipe() {
                                    state.resume_recipe();
                                }
                            }
                            Action::Interrupt => state.demonstrate_interrupt(),
                            Action::ReduceMotion => {
                                state.set_reduced_motion(!state.manual_reduced_motion());
                            }
                        }
                    }
                    pressed.is_some()
                }
                MouseEventKind::Moved | MouseEventKind::Entered => {
                    let changed = state.hovered != hit;
                    state.hovered = hit;
                    changed
                }
                MouseEventKind::Exited => state.hovered.take().is_some(),
                _ => false,
            }
        }
        _ => false,
    }
}

fn color(theme: Theme, id: &str) -> Rgba {
    proposal::render_color(id, theme).expect("validated motion page color")
}

struct Painter<'a, 'b> {
    ctx: &'a mut PageCtx<'b>,
    scene: &'a mut Scene,
}
impl Painter<'_, '_> {
    fn quad(&mut self, r: Rect, fill: &str, radius: f32, border: bool) {
        let mut quad = Quad::new(r, color(self.ctx.theme, fill)).with_corner_radius(radius);
        if border {
            quad = quad.with_border(Stroke::Rule.value(), color(self.ctx.theme, "border"));
        }
        self.scene.push_quad(quad);
    }
    fn panel(&mut self, r: Rect, fill: &str, radius: f32) {
        let (width, border) =
            tekes_ui_controls::paint::decorative_border(self.ctx.theme, self.ctx.text.scale());
        self.scene.push_quad(
            Quad::new(r, color(self.ctx.theme, fill))
                .with_corner_radius(radius)
                .with_border(width, border),
        );
    }
    fn label(&mut self, r: Rect, text: &str, role: proposal::TextRole, ink: &str) {
        self.ctx.text.proposal_label_in(
            self.scene,
            self.ctx.theme,
            r,
            text,
            role,
            color(self.ctx.theme, ink),
        );
    }
    fn body(&mut self, r: Rect, text: &str) {
        self.label(r, text, proposal::TextRole::UiBody, "primary-text");
    }
    fn caption(&mut self, r: Rect, text: &str) {
        self.label(r, text, proposal::TextRole::UiCaption, "secondary-text");
    }
    // Per-digit cached paragraphs prevent 120Hz telemetry from generating an
    // unbounded set of label shapes or repeatedly invoking CoreText shaping.
    fn number(&mut self, r: Rect, value: f64) {
        self.digits(r, &format!("{value:.2}"), "primary-text");
    }
    fn digits(&mut self, r: Rect, text: &str, ink: &str) {
        let mut x = r.min_x();
        for c in text.chars() {
            let digit = c.to_string();
            let width = self
                .ctx
                .text
                .proposal_label(&digit, proposal::TextRole::UiBody, None)
                .width
                .ceil() as f32;
            self.label(
                Rect::new(x, r.min_y(), width, r.size.height),
                &digit,
                proposal::TextRole::UiBody,
                ink,
            );
            x += width;
        }
    }
    fn faded_quad(&mut self, r: Rect, fill: &str, radius: f32, alpha: f32) {
        self.scene.push_quad(
            Quad::new(
                r,
                color(self.ctx.theme, fill).with_alpha(alpha.clamp(0.0, 1.0)),
            )
            .with_corner_radius(radius),
        );
    }
    fn faded_body(&mut self, r: Rect, text: &str, alpha: f32) {
        self.ctx.text.proposal_label_in(
            self.scene,
            self.ctx.theme,
            r,
            text,
            proposal::TextRole::UiBody,
            color(self.ctx.theme, "primary-text").with_alpha(alpha.clamp(0.0, 1.0)),
        );
    }
    fn polygon(&mut self, points: &[Point], ink: &str) {
        let min = points
            .iter()
            .map(|p| p.y)
            .fold(f32::INFINITY, f32::min)
            .floor();
        let max = points
            .iter()
            .map(|p| p.y)
            .fold(f32::NEG_INFINITY, f32::max)
            .ceil();
        for row in 0..((max - min).max(0.0) as usize).min(320) {
            let y = min + row as f32 + 0.5;
            let mut hits = Vec::with_capacity(4);
            for i in 0..points.len() {
                let a = points[i];
                let b = points[(i + 1) % points.len()];
                if (a.y <= y && b.y > y) || (b.y <= y && a.y > y) {
                    hits.push(a.x + (y - a.y) * (b.x - a.x) / (b.y - a.y));
                }
            }
            hits.sort_by(f32::total_cmp);
            for pair in hits.chunks_exact(2) {
                self.quad(
                    Rect::new(pair[0], y - 0.5, (pair[1] - pair[0]).max(0.0), 1.0),
                    ink,
                    0.0,
                    false,
                );
            }
        }
    }
    fn line(&mut self, a: Point, b: Point, ink: &str) {
        let count = ((b.x - a.x).abs().max((b.y - a.y).abs()) / 1.5)
            .ceil()
            .max(1.0) as usize;
        for i in 0..=count {
            let t = i as f32 / count as f32;
            self.quad(
                Rect::new(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, 1.5, 1.5),
                ink,
                0.75,
                false,
            );
        }
    }
}

pub fn build(ctx: &mut PageCtx<'_>, content: Rect, scene: &mut Scene, state: &MotionPreview) {
    let layout = Layout::new(content);
    let content = layout.content;
    let x = content.min_x();
    let y = content.min_y();
    let mut p = Painter { ctx, scene };
    let radius = CornerRadius::Panel.value();
    // Inspector background precedes its interactive Reduce Motion button.
    p.panel(layout.inspector, "surface-panel", radius);
    p.caption(
        Rect::new(x + 632.0, y, content.size.width - 632.0, 24.0),
        "MOTION LAB",
    );
    for (index, (action, rect)) in layout.state_actions(state).iter().enumerate() {
        let selected = match action {
            Action::Catalog(catalog) => *catalog == state.catalog,
            Action::Preset(i) => *i == state.selected,
            Action::SymbolIcon(i) => tekes_ui_icons::Icon::ALL[*i] == state.symbol_icon,
            Action::ReduceMotion => state.reduced_motion,
            _ => false,
        };
        let fill = if state.pressed == Some(index) {
            "button-pressed"
        } else if selected {
            "row-selection"
        } else if state.hovered == Some(index) {
            "button-hover"
        } else {
            "surface-panel"
        };
        p.quad(*rect, fill, CornerRadius::Control.value(), true);
        let label = match action {
            Action::Catalog(PresetCatalog::Apple) => "Apple defaults",
            Action::Catalog(PresetCatalog::DesignSystem) => "Design System",
            Action::Catalog(PresetCatalog::Recipes) => "Recipes / 配方",
            Action::Catalog(PresetCatalog::Symbols) => "Symbols / 图标",
            Action::Target(0) if state.is_recipe() => "目标 A / 反向",
            Action::Target(1) if state.is_recipe() => "暂停",
            Action::Target(_) if state.is_recipe() => "目标 B / 展开",
            Action::Preset(i) => state.presets[*i].label.as_str(),
            Action::SymbolIcon(i) => tekes_ui_icons::Icon::ALL[*i].label(),
            Action::Target(0) => "A · 0.15",
            Action::Target(1) => "B · 0.50",
            Action::Target(_) => "C · 0.85",
            Action::Replay => "重播",
            Action::Resume => "继续当前",
            Action::Interrupt => "演示中途改目标",
            Action::ReduceMotion => {
                if state.reduced_motion {
                    "减少动态效果 · 开"
                } else {
                    "减少动态效果 · 关"
                }
            }
        };
        let role = proposal::TextRole::UiBody;
        let label_width = p.ctx.text.proposal_label(label, role, None).width as f32;
        p.body(
            Rect::new(
                rect.min_x() + (rect.size.width - label_width).max(0.0) * 0.5,
                rect.min_y(),
                label_width.min(rect.size.width),
                rect.size.height,
            ),
            label,
        );
    }

    let sample = if state.is_recipe() {
        tekes_ui_motion::Sample {
            value: state.recipe.values()[0],
            velocity: state.recipe.velocities()[0],
        }
    } else {
        state.channel.current()
    };
    if state.is_recipe() {
        build_recipe_stage(&mut p, layout, state);
    } else {
        p.panel(layout.stage, "surface-panel", radius);
        p.caption(
            Rect::new(
                layout.stage.min_x() + 24.0,
                layout.stage.min_y() + 16.0,
                layout.stage.size.width - 48.0,
                24.0,
            ),
            "LIVE PREVIEW     点击轨道或 A / B / C，运动中也可切换",
        );
        let track = layout.track();
        let middle = layout.stage.center().y;
        p.quad(
            Rect::new(track.min_x(), middle - 1.0, track.size.width, 2.0),
            "separator",
            1.0,
            false,
        );
        for mark in [0.0, 0.25, 0.5, 0.75, 1.0] {
            let mx = track.min_x() + track.size.width * mark;
            p.quad(Rect::new(mx, middle - 5.0, 1.0, 10.0), "border", 0.0, false);
        }

        let target_x = track.min_x() + state.channel.target() as f32 * track.size.width;
        p.quad(
            Rect::new(target_x - 19.0, middle - 19.0, 38.0, 38.0),
            "surface-panel",
            19.0,
            true,
        );
        p.caption(
            Rect::new(target_x - 20.0, middle + 30.0, 60.0, 22.0),
            "目标",
        );
        p.scene.push_clip(layout.stage);
        let ball_x = track.min_x() + sample.value as f32 * track.size.width;
        p.quad(
            Rect::new(ball_x - 15.0, middle - 15.0, 30.0, 30.0),
            "primary-text",
            15.0,
            false,
        );
        p.scene.pop_clip();
        let status = if state.reduced_motion {
            "Reduce Motion · 即时到达"
        } else if state.channel.is_active() {
            "运行中 · 可随时改目标"
        } else {
            "已停止 · 无动画帧请求"
        };
        p.caption(
            Rect::new(
                track.min_x(),
                layout.stage.max_y() - 40.0,
                track.size.width,
                24.0,
            ),
            status,
        );
    }
    let row = layout.stage.max_y() + 8.0;
    for (i, (label, value)) in [
        (
            if state.is_recipe() && state.recipe.kind.is_rotation() {
                "角度 / °"
            } else {
                "位置"
            },
            if state.is_recipe() && state.recipe.kind.is_rotation() {
                sample.value * state.recipe.parameters.rotation_degrees
            } else {
                sample.value
            },
        ),
        (
            if state.is_recipe() && state.recipe.kind.is_rotation() {
                "角速度 / °s"
            } else {
                "速度 / s"
            },
            if state.is_recipe() && state.recipe.kind.is_rotation() {
                sample.velocity * state.recipe.parameters.rotation_degrees
            } else {
                sample.velocity
            },
        ),
        (
            "目标",
            if state.is_recipe() {
                f64::from(state.recipe.target())
                    * if state.recipe.kind.is_rotation() {
                        state.recipe.parameters.rotation_degrees
                    } else {
                        1.0
                    }
            } else {
                state.channel.target()
            },
        ),
    ]
    .into_iter()
    .enumerate()
    {
        let mx = x + i as f32 * 180.0;
        p.caption(Rect::new(mx, row, 80.0, 24.0), label);
        p.number(Rect::new(mx + 82.0, row, 96.0, 24.0), value);
    }

    p.panel(layout.graph, "surface-panel", radius);
    p.caption(
        Rect::new(
            layout.graph.min_x() + 20.0,
            layout.graph.min_y() + 10.0,
            layout.graph.size.width - 40.0,
            24.0,
        ),
        if state.is_recipe() && state.recipe.kind.is_typing() {
            "REVEAL     每格一个完整显示单元 · 深色为已浮现"
        } else {
            "TRAJECTORY     实线：位置    虚线：目标    下方：速度"
        },
    );
    let graph = Rect::new(
        layout.graph.min_x() + 20.0,
        layout.graph.min_y() + 42.0,
        layout.graph.size.width - 40.0,
        100.0,
    );
    let bottom = graph.max_y();
    let end = state.now.as_secs_f64().max(1.0);
    let start = (end - 4.0).max(0.0);
    let duration = (end - start).max(1.0);
    let to_x = |t: f64| graph.min_x() + ((t - start) / duration) as f32 * graph.size.width;
    p.quad(
        Rect::new(graph.min_x(), bottom, graph.size.width, 1.0),
        "separator",
        0.0,
        false,
    );
    p.scene.push_clip(graph);
    if state.is_recipe() && state.recipe.kind.is_typing() {
        let columns = 12;
        let width = (graph.size.width - 11.0 * 4.0) / 12.0;
        for i in 0..state.recipe.typing_unit_count {
            let cell = Rect::new(
                graph.min_x() + (i % columns) as f32 * (width + 4.0),
                graph.min_y() + (i / columns) as f32 * 18.0,
                width,
                14.0,
            );
            p.quad(
                cell,
                if i < state.recipe.typing.available() {
                    "row-selection"
                } else {
                    "surface-panel"
                },
                3.0,
                true,
            );
            p.faded_quad(
                cell,
                "primary-text",
                3.0,
                state.recipe.typing.opacity(i) as f32,
            );
        }
    } else {
        let points: Vec<_> = state.trace.iter().filter(|s| s.time >= start).collect();
        let stride = points.len().div_ceil(160).max(1);
        let mut previous: Option<(Point, Point)> = None;
        for (index, point) in points.iter().step_by(stride).enumerate() {
            let px = to_x(point.time);
            let pos = Point::new(px, bottom - 20.0 - point.value as f32 * 65.0);
            let velocity = Point::new(
                px,
                bottom - 8.0 - point.velocity.clamp(-6.0, 6.0) as f32 * 1.0,
            );
            if let Some((old_pos, old_velocity)) = previous {
                p.line(old_pos, pos, "primary-text");
                p.line(old_velocity, velocity, "secondary-text");
            }
            if index % 2 == 0 {
                p.quad(
                    Rect::new(px, bottom - 20.0 - point.target as f32 * 65.0, 3.0, 1.5),
                    "tertiary-text",
                    0.0,
                    false,
                );
            }
            previous = Some((pos, velocity));
        }
    }
    p.scene.pop_clip();
    p.caption(
        Rect::new(graph.min_x(), layout.graph.max_y() - 30.0, 100.0, 22.0),
        "时间 / s",
    );
    p.number(
        Rect::new(
            graph.max_x() - 64.0,
            layout.graph.max_y() - 30.0,
            64.0,
            22.0,
        ),
        state.now.as_secs_f64(),
    );

    p.body(
        Rect::new(
            layout.inspector.min_x() + 20.0,
            layout.inspector.min_y() + 12.0,
            240.0,
            28.0,
        ),
        "PARAMETERS / 参数",
    );
    for parameter in Parameter::ALL {
        let r = layout.slider(parameter);
        let enabled = state.parameter_enabled(parameter);
        let ink = if enabled {
            "primary-text"
        } else {
            "disabled-text"
        };
        p.label(
            Rect::new(r.min_x(), r.min_y() - 28.0, 170.0, 24.0),
            state.parameter_label(parameter),
            proposal::TextRole::UiCaption,
            ink,
        );
        p.digits(
            Rect::new(r.max_x() - 56.0, r.min_y() - 28.0, 56.0, 24.0),
            &if enabled {
                format!("{:.2}", state.parameter_value(parameter))
            } else {
                "—".into()
            },
            ink,
        );
        p.quad(
            Rect::new(r.min_x(), r.center().y - 2.0, r.size.width, 4.0),
            "separator",
            2.0,
            false,
        );
        let (lo, hi) = state.parameter_range(parameter);
        let unit = ((state.parameter_value(parameter) - lo) / (hi - lo)).clamp(0.0, 1.0) as f32;
        if enabled {
            p.quad(
                Rect::new(r.min_x(), r.center().y - 2.0, r.size.width * unit, 4.0),
                ink,
                2.0,
                false,
            );
        }
        p.quad(
            Rect::new(
                r.min_x() + r.size.width * unit - 7.0,
                r.center().y - 7.0,
                14.0,
                14.0,
            ),
            if enabled {
                "primary-text"
            } else {
                "disabled-text"
            },
            7.0,
            false,
        );
    }

    let source = if state.catalog == PresetCatalog::Symbols {
        "现有 8 个已确认图标 · 原 SVG 几何 · 稳定分层 / 锚点 / 有序路径"
    } else if state.is_recipe() {
        "TekesUI 实验配方 · 独立属性与项目轨道 · 参数调整替换待执行阶段"
    } else if state.custom {
        "当前为实验参数；重新选择预设可恢复原值"
    } else if state.catalog == PresetCatalog::Apple {
        "Apple 官方公开默认值 · Spring duration 为感知时长，不是强制结束时间"
    } else {
        "预设数值来自现有 JSON Design System"
    };
    p.caption(Rect::new(x, y + 816.0, content.size.width, 24.0), source);
    p.caption(
        Rect::new(x, y + 842.0, content.size.width, 24.0),
        &state.presets[state.selected].source,
    );
    if state.catalog == PresetCatalog::Symbols {
        p.caption(
            Rect::new(x, y + 894.0, content.size.width, 24.0),
            state.symbol_icon.name(),
        );
    }
    p.caption(
        Rect::new(x, y + 868.0, content.size.width, 24.0),
        if state.is_recipe() {
            "收起会反向并取消旧阶段；暂停保持当前画面；展开继续，重播从初态开始。"
        } else if state.catalog == PresetCatalog::Apple {
            "参考 SwiftUI Animation / UnitCurve 官方文档；不代表每个系统控件都使用同一组参数。"
        } else {
            "模型参考 Apple 官方机制；参数来自项目设计系统，非 Apple 系统控件常量。"
        },
    );
    if let Some(error) = &state.error {
        p.body(Rect::new(x, y + 894.0, content.size.width, 24.0), error);
    } else if let Some(event) = state.events.front() {
        // Generation uses cached digits; the event tail has a finite vocabulary.
        if let Some((number, label)) = event.split_once("  ") {
            p.digits(
                Rect::new(x, y + 894.0, 80.0, 24.0),
                number,
                "secondary-text",
            );
            p.caption(
                Rect::new(x + 80.0, y + 894.0, content.size.width - 80.0, 24.0),
                label,
            );
        }
    }
}

fn build_symbol_stage(
    p: &mut Painter<'_, '_>,
    area: Rect,
    state: &MotionPreview,
    effect: tekes_ui_motion::symbols::SymbolEffect,
) {
    use crate::gallery::motion_preview::symbol_assets::CANVAS;
    for (column, label) in ["Whole / 整体", "By Layer / 分层", "Individual / 逐层"]
        .into_iter()
        .enumerate()
    {
        let width = area.size.width / 3.0;
        let cx = area.min_x() + width * (column as f32 + 0.5);
        state.symbol_assets.append_scope(
            p.scene,
            column,
            Rect::new(cx - CANVAS * 0.5, area.min_y() + 4.0, CANVAS, CANVAS),
        );
        p.caption(
            Rect::new(cx - width * 0.5, area.min_y() + 114.0, width, 24.0),
            if state.recipe.kind == RecipeKind::LinearRotation && column == 2 {
                "Layer phase"
            } else {
                label
            },
        );
    }
    let resolved = state
        .symbol_assets
        .resolved_effect(state.symbol_icon, effect);
    if effect != resolved {
        p.caption(
            Rect::new(area.min_x(), area.min_y() + 138.0, area.size.width, 20.0),
            "无共享对应关系 · Magic Replace 降级为 Replace",
        );
    }
}

fn build_recipe_stage(p: &mut Painter<'_, '_>, layout: Layout, state: &MotionPreview) {
    let r = layout.stage;
    let recipe = &state.recipe;
    let [geometry, opacity, detail, preparation] = recipe.values().map(|v| v as f32);
    let g = geometry.clamp(-0.05, 1.1);
    let alpha = opacity.clamp(0.0, 1.0);
    let amount = recipe.parameters.amount as f32;
    p.panel(r, "surface-panel", CornerRadius::Panel.value());
    p.caption(
        Rect::new(r.min_x() + 20.0, r.min_y() + 8.0, r.size.width - 40.0, 24.0),
        recipe.kind.label(),
    );
    let area = Rect::new(
        r.min_x() + 20.0,
        r.min_y() + 38.0,
        r.size.width - 40.0,
        154.0,
    );
    p.scene.push_clip(area);
    match recipe.kind {
        RecipeKind::Symbol(effect) => build_symbol_stage(p, area, state, effect),
        RecipeKind::LinearRotation => build_symbol_stage(
            p,
            area,
            state,
            tekes_ui_motion::symbols::SymbolEffect::Rotate,
        ),
        RecipeKind::SharedElement => {
            let from = Rect::new(area.min_x() + 12.0, area.min_y() + 34.0, 136.0, 88.0);
            let to = Rect::new(
                area.min_x() + area.size.width * 0.29,
                area.min_y() + 4.0,
                area.size.width * 0.68,
                146.0,
            );
            // One stable element is rendered at interpolated geometry, rather
            // than crossfading duplicate cards with unrelated identities.
            let mix = |a: f32, b: f32| a + (b - a) * g;
            let card = Rect::new(
                mix(from.min_x(), to.min_x()),
                mix(from.min_y(), to.min_y()),
                mix(from.size.width, to.size.width),
                mix(from.size.height, to.size.height),
            );
            p.quad(from, "surface-panel", 12.0, true);
            p.quad(to, "surface-panel", 12.0, true);
            let radius = (12.0 + amount * 0.15 * g).max(0.0);
            p.quad(card, "row-selection", radius, true);
            let art = Rect::new(
                card.min_x() + 12.0,
                card.min_y() + 12.0,
                36.0 + 28.0 * g,
                36.0 + 28.0 * g,
            );
            p.quad(art, "primary-text", (8.0 + g * 8.0).max(0.0), false);
            p.body(
                Rect::new(
                    art.max_x() + 12.0,
                    card.min_y() + 12.0,
                    card.size.width - 72.0,
                    24.0,
                ),
                "Mountain stay",
            );
            p.faded_body(
                Rect::new(
                    art.max_x() + 12.0,
                    card.min_y() + 42.0,
                    card.size.width - 90.0,
                    24.0,
                ),
                "同一张卡片 · 同一个身份",
                alpha,
            );
            p.faded_quad(
                Rect::new(
                    card.min_x() + 12.0,
                    card.max_y() - 26.0,
                    (card.size.width - 24.0).max(0.0),
                    6.0,
                ),
                "secondary-text",
                3.0,
                alpha * 0.35,
            );
        }
        RecipeKind::Panel => {
            p.caption(
                Rect::new(area.min_x() + 12.0, area.min_y() + 8.0, 180.0, 24.0),
                "工作区 / Document",
            );
            for i in 0..4 {
                p.quad(
                    Rect::new(
                        area.min_x() + 12.0,
                        area.min_y() + 46.0 + i as f32 * 24.0,
                        area.size.width * 0.5,
                        6.0,
                    ),
                    "separator",
                    3.0,
                    false,
                );
            }
            p.faded_quad(area, "primary-text", 8.0, 0.10 * geometry.clamp(0.0, 1.0));
            let scale = 0.88 + detail.clamp(-0.05, 1.1) * 0.12;
            let width = (area.size.width * 0.62).min(380.0) * scale;
            let height = (146.0 * geometry.max(0.0)).min(160.0);
            let panel = Rect::new(
                area.max_x() - width + amount * (1.0 - g),
                area.center().y - height * 0.5,
                width,
                height,
            );
            p.quad(panel, "surface-panel", 12.0, true);
            p.scene.push_clip(panel);
            p.faded_body(
                Rect::new(
                    panel.min_x() + 16.0,
                    panel.min_y() + 10.0,
                    width - 32.0,
                    26.0,
                ),
                "Inspector",
                alpha,
            );
            for (i, label) in ["布局与对齐", "外观与透明度", "交互与行为"]
                .iter()
                .enumerate()
            {
                p.faded_quad(
                    Rect::new(
                        panel.min_x() + 16.0,
                        panel.min_y() + 46.0 + i as f32 * 28.0,
                        width - 32.0,
                        22.0,
                    ),
                    "row-selection",
                    5.0,
                    alpha,
                );
                p.faded_body(
                    Rect::new(
                        panel.min_x() + 24.0,
                        panel.min_y() + 44.0 + i as f32 * 28.0,
                        width - 48.0,
                        24.0,
                    ),
                    label,
                    alpha,
                );
            }
            p.scene.pop_clip();
        }
        RecipeKind::Success => {
            let cx = area.center().x;
            let cy = area.min_y() + 55.0;
            let pulse = (preparation - detail).clamp(0.0, 1.0) * amount * 0.12;
            let radius = 28.0 + pulse;
            p.quad(
                Rect::new(cx - radius, cy - radius, radius * 2.0, radius * 2.0),
                "row-selection",
                radius,
                false,
            );
            for i in 0..32 {
                let angle = i as f32 / 32.0 * std::f32::consts::TAU - std::f32::consts::FRAC_PI_2;
                p.quad(
                    Rect::new(
                        cx + angle.cos() * 39.0 - 2.0,
                        cy + angle.sin() * 39.0 - 2.0,
                        4.0,
                        4.0,
                    ),
                    if i as f32 / 32.0 < geometry {
                        "primary-text"
                    } else {
                        "separator"
                    },
                    2.0,
                    false,
                );
            }
            let check = detail.clamp(0.0, 1.0);
            p.scene
                .push_clip(Rect::new(cx - 16.0, cy - 14.0, 34.0 * check, 30.0));
            p.line(
                Point::new(cx - 13.0, cy),
                Point::new(cx - 3.0, cy + 10.0),
                "primary-text",
            );
            p.line(
                Point::new(cx - 3.0, cy + 10.0),
                Point::new(cx + 17.0, cy - 12.0),
                "primary-text",
            );
            p.scene.pop_clip();
            for (i, (phase, label)) in [
                (Phase::Preparing, "1 · 准备"),
                (Phase::Working, "2 · 处理中"),
                (Phase::Success, "3 · 成功"),
            ]
            .into_iter()
            .enumerate()
            {
                let width = (area.size.width - 16.0) / 3.0;
                let step = Rect::new(
                    area.min_x() + i as f32 * (width + 8.0),
                    area.max_y() - 34.0,
                    width,
                    30.0,
                );
                p.quad(
                    step,
                    if recipe.phase == phase {
                        "row-selection"
                    } else {
                        "surface-panel"
                    },
                    6.0,
                    true,
                );
                p.body(
                    Rect::new(step.min_x() + 10.0, step.min_y(), width - 20.0, 30.0),
                    label,
                );
            }
        }
        RecipeKind::ListReorder => {
            let step = 21.0 + amount / 80.0;
            let left = area.min_x() + 16.0;
            let width = area.size.width * 0.64;
            let positions = recipe.item_values();
            for (i, label) in [
                "A · 项目计划",
                "B · 设计规范",
                "C · 待删除项目",
                "D · 交互实现",
                "E · 验证记录",
                "F · 新加入项目",
            ]
            .into_iter()
            .enumerate()
            {
                let visibility = if i == 2 {
                    1.0 - alpha
                } else if i == 5 {
                    alpha
                } else {
                    1.0
                };
                let row = Rect::new(
                    left,
                    area.min_y() + positions[i] as f32 * step,
                    width,
                    step - 1.0,
                );
                p.faded_quad(row, "row-selection", 4.0, visibility);
                p.faded_body(
                    Rect::new(
                        row.min_x() + 10.0,
                        row.min_y(),
                        width - 20.0,
                        row.size.height,
                    ),
                    label,
                    visibility,
                );
            }
            p.caption(
                Rect::new(
                    area.min_x() + area.size.width * 0.69,
                    area.min_y() + 12.0,
                    area.size.width * 0.3,
                    24.0,
                ),
                "稳定 ID · 连续排序",
            );
            p.caption(
                Rect::new(
                    area.min_x() + area.size.width * 0.69,
                    area.min_y() + 40.0,
                    area.size.width * 0.3,
                    24.0,
                ),
                "A：原始顺序",
            );
            p.caption(
                Rect::new(
                    area.min_x() + area.size.width * 0.69,
                    area.min_y() + 68.0,
                    area.size.width * 0.3,
                    24.0,
                ),
                "B：增删与重排",
            );
        }
        RecipeKind::SharedAxis => {
            for (incoming, title, subtitle) in [
                (false, "01 · 选择内容", "回到上一步"),
                (true, "02 · 确认设置", "继续到下一步"),
            ] {
                let progress = if incoming { g - 1.0 } else { g };
                let fade = if incoming { alpha } else { 1.0 - alpha };
                let card = Rect::new(
                    area.min_x() + area.size.width * 0.13 - progress * amount,
                    area.min_y() + 12.0,
                    area.size.width * 0.74,
                    128.0,
                );
                p.faded_quad(card, "row-selection", 12.0, fade);
                p.faded_body(
                    Rect::new(
                        card.min_x() + 24.0,
                        card.min_y() + 24.0,
                        card.size.width - 48.0,
                        28.0,
                    ),
                    title,
                    fade,
                );
                p.faded_body(
                    Rect::new(
                        card.min_x() + 24.0,
                        card.min_y() + 64.0,
                        card.size.width - 48.0,
                        24.0,
                    ),
                    subtitle,
                    fade,
                );
            }
        }
        RecipeKind::FadeThrough => {
            let split = 0.2 + recipe.parameters.delay as f32 * 0.6;
            for (incoming, title) in [(false, "项目总览"), (true, "数据分析")] {
                let fade = if incoming {
                    ((alpha - split) / (1.0 - split)).clamp(0.0, 1.0)
                } else {
                    (1.0 - alpha / split).clamp(0.0, 1.0)
                };
                let scale = if incoming {
                    1.0 - (1.0 - g) * amount / 1600.0
                } else {
                    1.0
                };
                let width = area.size.width * 0.76 * scale;
                let card = Rect::new(
                    area.center().x - width / 2.0,
                    area.min_y() + 10.0,
                    width,
                    130.0,
                );
                p.faded_quad(card, "row-selection", 12.0, fade);
                p.faded_body(
                    Rect::new(card.min_x() + 24.0, card.min_y() + 18.0, width - 48.0, 28.0),
                    title,
                    fade,
                );
                for i in 0..3 {
                    p.faded_quad(
                        Rect::new(
                            card.min_x() + 24.0,
                            card.min_y() + 62.0 + i as f32 * 18.0,
                            width - 48.0 - i as f32 * 24.0,
                            6.0,
                        ),
                        "secondary-text",
                        3.0,
                        fade * 0.35,
                    );
                }
            }
        }
        RecipeKind::DragSnap => {
            let track = layout.track();
            let y = area.center().y;
            p.quad(
                Rect::new(track.min_x(), y, track.size.width, 2.0),
                "separator",
                1.0,
                false,
            );
            for i in 0..5 {
                let x = track.min_x() + i as f32 * track.size.width / 4.0;
                p.quad(Rect::new(x - 3.0, y - 3.0, 6.0, 6.0), "border", 3.0, false);
            }
            let x = track.min_x() + geometry * track.size.width;
            let target = track.min_x() + recipe.snap_target() as f32 * track.size.width;
            p.quad(
                Rect::new(target - 20.0, y - 20.0, 40.0, 40.0),
                "surface-panel",
                20.0,
                true,
            );
            p.quad(
                Rect::new(x - 16.0, y - 16.0, 32.0, 32.0),
                "primary-text",
                16.0,
                false,
            );
            p.caption(
                Rect::new(
                    area.min_x() + 8.0,
                    area.max_y() - 28.0,
                    area.size.width - 16.0,
                    24.0,
                ),
                "拖动圆点并松手 · 惯性途中可再次抓住 · 五个吸附点",
            );
        }
        RecipeKind::Stagger => {
            let items = recipe.item_values();
            let width = (area.size.width - 24.0) / 3.0;
            for (i, label) in [
                "01 · 内容",
                "02 · 布局",
                "03 · 外观",
                "04 · 交互",
                "05 · 状态",
                "06 · 验证",
            ]
            .into_iter()
            .enumerate()
            {
                let value = items[i] as f32;
                let fade = value.clamp(0.0, 1.0);
                let card = Rect::new(
                    area.min_x() + (i % 3) as f32 * (width + 12.0),
                    area.min_y() + (i / 3) as f32 * 72.0 + (1.0 - value) * amount * 0.35,
                    width,
                    60.0,
                );
                p.faded_quad(card, "row-selection", 10.0, fade);
                p.faded_body(
                    Rect::new(card.min_x() + 12.0, card.min_y() + 16.0, width - 24.0, 28.0),
                    label,
                    fade,
                );
            }
        }
        RecipeKind::Popover => {
            let anchor = Rect::new(
                area.min_x() + area.size.width * 0.21,
                area.min_y() + 8.0,
                110.0,
                30.0,
            );
            p.quad(anchor, "row-selection", 6.0, true);
            p.body(
                Rect::new(anchor.min_x() + 12.0, anchor.min_y(), 90.0, 30.0),
                "操作菜单 ▾",
            );
            let scale = (0.8 + 0.2 * g).max(0.1);
            let panel = Rect::new(
                anchor.min_x(),
                anchor.max_y() + 6.0 + (1.0 - g) * amount * 0.2,
                220.0 * scale,
                102.0 * scale,
            );
            p.faded_quad(panel, "row-selection", 10.0, alpha);
            p.scene.push_clip(panel);
            for (i, label) in ["编辑内容", "复制链接", "归档项目"].iter().enumerate() {
                p.faded_body(
                    Rect::new(
                        panel.min_x() + 16.0,
                        panel.min_y() + 6.0 + i as f32 * 30.0,
                        panel.size.width - 32.0,
                        26.0,
                    ),
                    label,
                    detail.clamp(0.0, 1.0),
                );
            }
            p.scene.pop_clip();
        }
        RecipeKind::Press => {
            let width = 220.0 - geometry * amount * 0.25;
            let height = 64.0 - geometry * amount * 0.08;
            let button = Rect::new(
                area.center().x - width / 2.0,
                area.center().y - height / 2.0,
                width,
                height,
            );
            p.quad(button, "surface-panel", 12.0 + detail.max(0.0) * 12.0, true);
            p.faded_quad(
                button,
                "row-selection",
                12.0 + detail.max(0.0) * 12.0,
                alpha,
            );
            p.body(
                Rect::new(
                    button.min_x() + 32.0,
                    button.min_y() + height / 2.0 - 14.0,
                    width - 64.0,
                    28.0,
                ),
                "按下并保持",
            );
            p.caption(
                Rect::new(
                    area.min_x() + 12.0,
                    area.max_y() - 26.0,
                    area.size.width - 24.0,
                    24.0,
                ),
                "形状：弹簧回弹     填充：有界效果轨道",
            );
        }
        RecipeKind::Skeleton => {
            let loaded = alpha;
            let x = area.min_x() + area.size.width * 0.14;
            let width = area.size.width * 0.72;
            let shimmer = ((recipe.now().as_secs_f64() / recipe.parameters.duration) % 1.0) as f32;
            for i in 0..4 {
                let row = Rect::new(
                    x,
                    area.min_y() + 12.0 + i as f32 * 32.0,
                    width - i as f32 * 18.0,
                    22.0,
                );
                p.faded_quad(row, "row-selection", 5.0, 1.0 - loaded);
                p.scene.push_clip(row);
                p.faded_quad(
                    Rect::new(
                        x + (width + amount) * shimmer - amount,
                        row.min_y(),
                        amount,
                        row.size.height,
                    ),
                    "secondary-text",
                    4.0,
                    (1.0 - loaded) * 0.12,
                );
                p.scene.pop_clip();
                p.faded_body(
                    row,
                    [
                        "真实内容 · 项目更新",
                        "新增三条设计评审意见",
                        "所有修改已同步",
                        "点击目标 A 模拟重新加载",
                    ][i],
                    loaded,
                );
            }
        }
        RecipeKind::Numeric => {
            let value = recipe.item_values()[0].clamp(0.0, 99999.0);
            let width = 26.0;
            let left = area.center().x - width * 2.5;
            let top = area.center().y - 24.0;
            p.caption(
                Rect::new(left, area.min_y() + 6.0, 200.0, 24.0),
                "TOTAL / 实时指标",
            );
            p.scene.push_clip(Rect::new(left, top, width * 5.0, 40.0));
            for i in 0..5 {
                let place = 10.0_f64.powi(4 - i);
                let scaled = value / place;
                let floor = scaled.floor();
                let fraction = (scaled - floor) as f32;
                let digit = (floor as u32) % 10;
                let next = (digit + 1) % 10;
                let x = left + i as f32 * width;
                p.body(
                    Rect::new(x, top - fraction * 40.0, 24.0, 40.0),
                    &digit.to_string(),
                );
                p.body(
                    Rect::new(x, top + (1.0 - fraction) * 40.0, 24.0, 40.0),
                    &next.to_string(),
                );
            }
            p.scene.pop_clip();
            p.caption(
                Rect::new(
                    area.min_x() + 16.0,
                    area.max_y() - 26.0,
                    area.size.width - 32.0,
                    24.0,
                ),
                "固定数字槽位 · 更新中反向 · 调整增量再切换",
            );
        }
        RecipeKind::Typing | RecipeKind::StreamTyping => {
            let units =
                crate::gallery::motion_preview::typing_fixture(state.locale, recipe.target());
            let full = units.concat();
            let role = proposal::TextRole::UiBody;
            let paragraph = p
                .ctx
                .text
                .proposal_document(&full, role, Some(area.size.width - 32.0));
            let origin = Point::new(area.min_x() + 16.0, area.min_y() + 12.0);
            let mut utf16_end = 0;
            for (i, unit) in units.iter().enumerate() {
                let start = utf16_end;
                utf16_end += unit.encode_utf16().count();
                let alpha = recipe.typing.opacity(i) as f32;
                if alpha <= 0.0 {
                    continue;
                }
                // Keep the original paragraph geometry; never reshape growing
                // prefixes. A ligature or emoji cluster becomes visible only
                // when its full UTF-16 cluster has reached the reveal frontier.
                let mut layer = (*paragraph).clone();
                for line in &mut layer.lines {
                    for run in &mut line.runs {
                        run.glyphs.retain(|g| {
                            g.cluster_utf16.end > start && g.cluster_utf16.end <= utf16_end
                        });
                    }
                }
                p.ctx.text.push(
                    p.scene,
                    &layer,
                    origin,
                    color(p.ctx.theme, "primary-text").with_alpha(alpha),
                );
            }
            p.caption(
                Rect::new(area.min_x() + 16.0, area.max_y() - 28.0, 76.0, 24.0),
                "已到达",
            );
            p.number(
                Rect::new(area.min_x() + 78.0, area.max_y() - 28.0, 60.0, 24.0),
                recipe.typing.available() as f64,
            );
            p.caption(
                Rect::new(area.min_x() + 150.0, area.max_y() - 28.0, 76.0, 24.0),
                "已显示",
            );
            p.number(
                Rect::new(area.min_x() + 212.0, area.max_y() - 28.0, 60.0, 24.0),
                recipe.typing.visible() as f64,
            );
            p.caption(
                Rect::new(
                    area.min_x() + 288.0,
                    area.max_y() - 28.0,
                    area.size.width - 304.0,
                    24.0,
                ),
                "A/B 切换文本",
            );
        }
        RecipeKind::Rotate2D
        | RecipeKind::FlipX
        | RecipeKind::FlipY
        | RecipeKind::SpinBrake
        | RecipeKind::RotateSettle => {
            use tekes_ui_motion::recipes::{RotationAxis, project_rotation};
            let axis = match recipe.kind {
                RecipeKind::FlipX => RotationAxis::X,
                RecipeKind::FlipY => RotationAxis::Y,
                _ => RotationAxis::Z,
            };
            let degrees = f64::from(geometry) * recipe.parameters.rotation_degrees;
            let center = Point::new(area.center().x, area.min_y() + 72.0);
            let project = |x: f64, y: f64| {
                let [px, py] = project_rotation([x, y], degrees, axis, 420.0).unwrap();
                Point::new(center.x + px as f32, center.y + py as f32)
            };
            let corners = [
                project(-52.0, -36.0),
                project(52.0, -36.0),
                project(52.0, 36.0),
                project(-52.0, 36.0),
            ];
            let back = axis != RotationAxis::Z && degrees.to_radians().cos() < 0.0;
            p.polygon(&corners, if back { "separator" } else { "row-selection" });
            for i in 0..4 {
                p.line(corners[i], corners[(i + 1) % 4], "primary-text");
            }
            let mark = [
                project(-40.0, -24.0),
                project(-14.0, -24.0),
                project(-14.0, -16.0),
                project(-40.0, -16.0),
            ];
            p.polygon(&mark, "primary-text");
            // Asymmetric vector marks make orientation legible even after
            // full turns; no upright text is pasted onto a rotating face.
            for (a, b) in [
                ((-12.0, -10.0), (-12.0, 16.0)),
                ((-12.0, -10.0), (12.0, -10.0)),
                ((-12.0, 2.0), (6.0, 2.0)),
            ] {
                p.line(project(a.0, a.1), project(b.0, b.1), "primary-text");
            }
            p.quad(
                Rect::new(center.x - 2.0, center.y - 2.0, 4.0, 4.0),
                "primary-text",
                2.0,
                false,
            );
            p.caption(
                Rect::new(
                    area.min_x() + 8.0,
                    area.max_y() - 24.0,
                    area.size.width - 16.0,
                    22.0,
                ),
                match recipe.kind {
                    RecipeKind::FlipX => "X 轴 · 上下翻转 · 透视投影",
                    RecipeKind::FlipY => "Y 轴 · 左右翻转 · 透视投影",
                    RecipeKind::SpinBrake => "慢起步 → 加速 → 减速刹停 · 中途换向保留角速度",
                    RecipeKind::RotateSettle => "弹簧越过目标后轻微回摆 · 阻尼可调",
                    _ => "Z 轴 · 平面旋转 · 中途反向",
                },
            );
        }
        RecipeKind::TextScan => {
            let role = proposal::TextRole::UiHeading;
            let lines = [
                "DESIGN IN MOTION",
                "让想法逐渐清晰",
                "Thinking, then creating.",
            ];
            let width = lines
                .iter()
                .map(|text| p.ctx.text.proposal_label(text, role, None).width as f32)
                .fold(0.0_f32, f32::max)
                .min(area.size.width - 32.0)
                + 8.0;
            let block = Rect::new(
                area.center().x - width / 2.0,
                area.min_y() + 10.0,
                width,
                108.0,
            );
            let band = tekes_ui_motion::recipes::TextScanBand {
                angle_degrees: recipe.parameters.scan_angle,
                width: recipe.parameters.amount,
            };
            for (i, text) in lines.iter().enumerate() {
                let slot = Rect::new(
                    block.min_x(),
                    block.min_y() + i as f32 * 34.0,
                    block.size.width,
                    30.0,
                );
                p.label(
                    slot,
                    text,
                    role,
                    if state.reduced_motion {
                        "primary-text"
                    } else {
                        "secondary-text"
                    },
                );
                // Raster-aligned horizontal clips approximate a diagonal mask
                // without changing shared renderer shaders. The text itself is
                // redrawn at one stable origin, so only glyph pixels light up.
                for row in 0..30 {
                    let y = slot.min_y() + row as f32;
                    for (fraction, alpha) in [(1.0, 0.22), (0.68, 0.35), (0.36, 0.85)] {
                        if let Some((lo, hi)) = band.span(
                            [f64::from(block.size.width), f64::from(block.size.height)],
                            f64::from(y - block.min_y() + 0.5),
                            f64::from(geometry),
                        ) {
                            let middle = (lo + hi) * 0.5;
                            let half = (hi - lo) * 0.5 * fraction;
                            let lo = middle - half;
                            let hi = middle + half;
                            let left = (block.min_x() + lo as f32).max(slot.min_x());
                            let right = (block.min_x() + hi as f32).min(slot.max_x());
                            if right > left {
                                p.scene.push_clip(Rect::new(left, y, right - left, 1.0));
                                p.ctx.text.proposal_label_in(
                                    p.scene,
                                    p.ctx.theme,
                                    slot,
                                    text,
                                    role,
                                    color(p.ctx.theme, "primary-text").with_alpha(alpha),
                                );
                                p.scene.pop_clip();
                            }
                        }
                    }
                }
            }
            p.caption(
                Rect::new(
                    area.min_x() + 12.0,
                    area.max_y() - 26.0,
                    area.size.width - 24.0,
                    24.0,
                ),
                "亮带只照亮字形 · A/B 改变扫描方向 · 暂停 / 继续当前",
            );
        }
        RecipeKind::PageSwitch => {
            let rail = Rect::new(area.min_x(), area.min_y(), 92.0, area.size.height);
            p.quad(rail, "row-selection", 8.0, false);
            for (i, label) in ["总览", "项目", "设置"].iter().enumerate() {
                p.caption(
                    Rect::new(
                        rail.min_x() + 12.0,
                        rail.min_y() + 12.0 + i as f32 * 34.0,
                        68.0,
                        26.0,
                    ),
                    label,
                );
            }
            let bounds = Rect::new(
                rail.max_x() + 16.0,
                area.min_y(),
                area.size.width - 108.0,
                area.size.height,
            );
            for (incoming, title) in [(false, "工作区 A"), (true, "工作区 B")] {
                let fade = if incoming { alpha } else { 1.0 - alpha };
                let scale = if incoming {
                    1.0 - (1.0 - g) * amount / 2000.0
                } else {
                    1.0
                };
                let width = bounds.size.width * scale;
                let card = Rect::new(
                    bounds.center().x - width / 2.0,
                    bounds.min_y() + (1.0 - g) * if incoming { 16.0 } else { 0.0 },
                    width,
                    bounds.size.height,
                );
                p.faded_quad(card, "surface-panel", 8.0, fade);
                p.faded_body(
                    Rect::new(card.min_x() + 16.0, card.min_y() + 12.0, width - 32.0, 28.0),
                    title,
                    fade,
                );
                for i in 0..3 {
                    p.faded_quad(
                        Rect::new(
                            card.min_x() + 16.0,
                            card.min_y() + 56.0 + i as f32 * 26.0,
                            width - 32.0,
                            18.0,
                        ),
                        "row-selection",
                        4.0,
                        fade,
                    );
                }
            }
        }
        RecipeKind::Reading => {
            let height = recipe.inserted_height() as f32;
            let column = (area.size.width - 16.0) / 2.0;
            for (i, anchored) in [false, true].into_iter().enumerate() {
                let pane = Rect::new(
                    area.min_x() + i as f32 * (column + 16.0),
                    area.min_y(),
                    column,
                    area.size.height,
                );
                p.caption(
                    Rect::new(pane.min_x() + 8.0, pane.min_y(), column - 16.0, 22.0),
                    if anchored {
                        "补偿滚动 · 阅读位置稳定"
                    } else {
                        "对照 · 未补偿滚动"
                    },
                );
                let viewport = Rect::new(
                    pane.min_x(),
                    pane.min_y() + 26.0,
                    column,
                    pane.size.height - 26.0,
                );
                p.quad(viewport, "surface-panel", 6.0, true);
                p.scene.push_clip(viewport);
                let scroll = if anchored {
                    recipe.scroll_offset() as f32
                } else {
                    recipe.user_scroll as f32
                };
                let inserted = Rect::new(
                    viewport.min_x() + 4.0,
                    viewport.min_y() - scroll,
                    column - 8.0,
                    height.max(0.0),
                );
                p.faded_quad(inserted, "row-selection", 4.0, alpha);
                if height > 20.0 {
                    p.faded_body(
                        Rect::new(
                            inserted.min_x() + 8.0,
                            inserted.min_y() + 4.0,
                            column - 24.0,
                            24.0,
                        ),
                        "新到达的内容",
                        alpha,
                    );
                }
                for row in 0..9 {
                    let y = viewport.min_y() + row as f32 * 36.0 + height - scroll;
                    let rect = Rect::new(viewport.min_x() + 4.0, y, column - 8.0, 32.0);
                    if row == 2 {
                        p.quad(rect, "row-selection", 4.0, true);
                    }
                    p.body(
                        Rect::new(rect.min_x() + 8.0, y, column - 24.0, 30.0),
                        [
                            "01 · 背景与目标",
                            "02 · 设计约束",
                            "03 · 正在阅读的内容",
                            "04 · 交互方案",
                            "05 · 视觉细节",
                            "06 · 验证记录",
                            "07 · 后续工作",
                            "08 · 附录",
                            "09 · 参考资料",
                        ][row],
                    );
                }
                p.scene.pop_clip();
            }
        }
    }
    p.scene.pop_clip();
    let status = if state.reduced_motion {
        "减少动态效果 · 即时完成"
    } else if recipe.phase == Phase::Cancelled {
        "已暂停 / 反向 · 可继续或重播"
    } else if recipe.needs_frame() {
        "运行中 · 可随时改参或反向"
    } else {
        "已停止 · 无动画帧请求"
    };
    p.caption(
        Rect::new(
            r.min_x() + 20.0,
            r.max_y() - 34.0,
            if recipe.kind == RecipeKind::Reading {
                r.size.width - 270.0
            } else {
                r.size.width - 40.0
            },
            24.0,
        ),
        status,
    );
    if recipe.kind == RecipeKind::Reading {
        for down in [false, true] {
            let button = layout.reading_scroll(down);
            p.quad(button, "surface-panel", 6.0, true);
            p.body(
                Rect::new(
                    button.min_x() + 8.0,
                    button.min_y(),
                    button.size.width - 16.0,
                    button.size.height,
                ),
                if down { "向下阅读" } else { "向上阅读" },
            );
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tekes_ui_platform_macos::{Modifiers, MouseEvent, Point as NativePoint};
    fn mouse(kind: MouseEventKind, p: Point) -> Event {
        Event::Mouse(MouseEvent {
            kind,
            position: NativePoint {
                x: f64::from(p.x),
                y: f64::from(p.y),
            },
            modifiers: Modifiers::NONE,
        })
    }
    #[test]
    fn existing_icon_selectors_use_native_motion_hit_routing() {
        let content = Rect::new(24.0, 24.0, 1104.0, HEIGHT);
        let layout = Layout::new(content);
        let mut state = MotionPreview::default();
        state.select_catalog(PresetCatalog::Symbols);
        for i in 0..tekes_ui_icons::Icon::ALL.len() {
            let point = layout.button(Action::SymbolIcon(i)).center();
            for kind in [
                MouseEventKind::Down {
                    button: MouseButton::Left,
                    click_count: 1,
                },
                MouseEventKind::Up {
                    button: MouseButton::Left,
                    click_count: 1,
                },
            ] {
                assert!(handle_input(&mut state, &mouse(kind, point), content));
            }
            assert_eq!(state.symbol_icon, tekes_ui_icons::Icon::ALL[i]);
            assert!(state.needs_animation());
            state.pause_recipe();
            assert!(!state.needs_animation());
        }
    }

    #[test]
    fn every_action_uses_same_layout_for_drawing_and_hit_routing() {
        let content = Rect::new(312.0, 80.0, 1104.0, 790.0);
        let layout = Layout::new(content);
        let mut state = MotionPreview::default();
        for (action, rect) in layout.state_actions(&state) {
            assert!(rect.min_x() >= content.min_x() && rect.max_x() <= content.max_x());
            let at = rect.center();
            assert!(handle_input(
                &mut state,
                &mouse(
                    MouseEventKind::Down {
                        button: MouseButton::Left,
                        click_count: 1
                    },
                    at
                ),
                content
            ));
            assert!(handle_input(
                &mut state,
                &mouse(
                    MouseEventKind::Up {
                        button: MouseButton::Left,
                        click_count: 1
                    },
                    at
                ),
                content
            ));
            if let Action::Preset(i) = action {
                assert_eq!(state.selected, i);
            }
        }
    }

    #[test]
    fn clipped_input_cancels_outside_button_release_but_keeps_slider_capture() {
        let content = Rect::new(24.0, 24.0, 1104.0, HEIGHT);
        let visible = Rect::new(24.0, 24.0, 1104.0, 420.0);
        let layout = Layout::new(content);
        let mut state = MotionPreview::default();
        let button = layout
            .button(Action::Catalog(PresetCatalog::Recipes))
            .center();
        let outside = Point::new(visible.max_x() + 4.0, visible.max_y() + 4.0);
        assert!(handle_input_clipped(
            &mut state,
            &mouse(
                MouseEventKind::Down {
                    button: MouseButton::Left,
                    click_count: 1,
                },
                button,
            ),
            content,
            visible,
        ));
        assert!(handle_input_clipped(
            &mut state,
            &mouse(
                MouseEventKind::Up {
                    button: MouseButton::Left,
                    click_count: 1,
                },
                outside,
            ),
            content,
            visible,
        ));
        assert_eq!(state.catalog, PresetCatalog::Apple);

        let parameter = Parameter::ALL[0];
        let slider = layout.slider(parameter);
        let before = state.parameter_value(parameter);
        assert!(handle_input_clipped(
            &mut state,
            &mouse(
                MouseEventKind::Down {
                    button: MouseButton::Left,
                    click_count: 1,
                },
                slider.center(),
            ),
            content,
            visible,
        ));
        assert!(handle_input_clipped(
            &mut state,
            &mouse(
                MouseEventKind::Dragged {
                    button: MouseButton::Left,
                },
                outside,
            ),
            content,
            visible,
        ));
        assert_ne!(state.parameter_value(parameter), before);
        assert!(handle_input_clipped(
            &mut state,
            &mouse(
                MouseEventKind::Up {
                    button: MouseButton::Left,
                    click_count: 1,
                },
                outside,
            ),
            content,
            visible,
        ));
        assert_eq!(state.dragging, None);
    }
    #[test]
    fn motion_recipes_controls_pause_reverse_scroll_and_change_parameters() {
        let content = Rect::new(24.0, 24.0, 1104.0, HEIGHT);
        let layout = Layout::new(content);
        let click = |state: &mut MotionPreview, point: Point| {
            for kind in [
                MouseEventKind::Down {
                    button: MouseButton::Left,
                    click_count: 1,
                },
                MouseEventKind::Up {
                    button: MouseButton::Left,
                    click_count: 1,
                },
            ] {
                handle_input(state, &mouse(kind, point), content);
            }
        };
        let mut state = MotionPreview::default();
        click(
            &mut state,
            layout
                .button(Action::Catalog(PresetCatalog::Recipes))
                .center(),
        );
        assert!(state.is_recipe());
        for kind in 0..RecipeKind::ALL.len() {
            click(&mut state, layout.button(Action::Preset(kind)).center());
            state.animate(0.07);
            let before = state.recipe.values();
            click(&mut state, layout.button(Action::Target(1)).center());
            state.animate(2.0);
            assert_eq!(state.recipe.values(), before);
            assert!(!state.needs_animation());
            click(&mut state, layout.button(Action::Target(2)).center());
            assert!(state.needs_animation());
            click(&mut state, layout.slider(Parameter::Frequency).center());
            let (lo, hi) = state.parameter_range(Parameter::Frequency);
            assert!((state.parameter_value(Parameter::Frequency) - (lo + hi) * 0.5).abs() < 0.001);
            click(&mut state, layout.button(Action::Target(0)).center());
            for _ in 0..500 {
                state.animate(0.02);
            }
            assert_eq!(state.recipe.values(), [0.0; 4]);
            assert!(!state.needs_animation());
        }
        state.select(3);
        state.pause_recipe();
        let old = state.recipe.user_scroll;
        click(&mut state, layout.reading_scroll(true).center());
        assert_eq!(state.recipe.user_scroll, old + 36.0);
        assert!(!state.needs_animation());
    }

    #[test]
    fn motion_recipe_drag_and_press_use_captured_mouse_routes() {
        let content = Rect::new(24.0, 24.0, 1104.0, HEIGHT);
        let layout = Layout::new(content);
        let down = MouseEventKind::Down {
            button: MouseButton::Left,
            click_count: 1,
        };
        let up = MouseEventKind::Up {
            button: MouseButton::Left,
            click_count: 1,
        };
        let drag = MouseEventKind::Dragged {
            button: MouseButton::Left,
        };
        let mut state = MotionPreview::default();
        state.select_catalog(PresetCatalog::Recipes);
        state.select(7);
        let point = layout.stage.center();
        handle_input(&mut state, &mouse(down, point), content);
        assert!(state.recipe_dragging);
        assert!(state.pressed.is_some());
        handle_input(
            &mut state,
            &mouse(drag, Point::new(layout.stage.max_x() + 120.0, point.y)),
            content,
        );
        assert_eq!(state.recipe.values()[0], 1.0);
        handle_input(&mut state, &mouse(up, point), content);
        assert!(!state.recipe_dragging);
        assert!(state.pressed.is_none());
        state.animate(0.1);
        handle_input(&mut state, &mouse(down, point), content);
        handle_input(&mut state, &Event::Focus(false), content);
        assert!(!state.recipe_dragging);
        assert!(!state.needs_animation());
        state.select(10);
        handle_input(&mut state, &mouse(down, point), content);
        assert!(state.recipe.target());
        handle_input(
            &mut state,
            &mouse(drag, Point::new(-100.0, -100.0)),
            content,
        );
        assert!(!state.recipe.target());
        handle_input(&mut state, &mouse(drag, point), content);
        assert!(state.recipe.target());
        handle_input(&mut state, &mouse(up, point), content);
        assert!(!state.recipe.target());
    }

    #[test]
    fn slider_capture_drag_and_focus_loss() {
        let content = Rect::new(312.0, 80.0, 1104.0, 790.0);
        let layout = Layout::new(content);
        let mut state = MotionPreview::default();
        let p = layout.slider(Parameter::Frequency).center();
        handle_input(
            &mut state,
            &mouse(
                MouseEventKind::Down {
                    button: MouseButton::Left,
                    click_count: 1,
                },
                p,
            ),
            content,
        );
        assert_eq!(state.dragging, Some(Parameter::Frequency));
        handle_input(
            &mut state,
            &mouse(
                MouseEventKind::Dragged {
                    button: MouseButton::Left,
                },
                Point::new(3000.0, p.y),
            ),
            content,
        );
        assert_eq!(state.frequency, Parameter::Frequency.range().1);
        assert!(handle_input(&mut state, &Event::Focus(false), content));
        assert!(state.dragging.is_none());
    }

    #[test]
    fn manual_toggle_is_independent_of_system_reduction_in_the_real_hit_path() {
        let content = Rect::new(312.0, 80.0, 1104.0, HEIGHT);
        let mut state = MotionPreview::default();
        state.set_system_reduced_motion(true);
        let point = Layout::new(content).button(Action::ReduceMotion).center();
        for (kind, count) in [
            (
                MouseEventKind::Down {
                    button: MouseButton::Left,
                    click_count: 1,
                },
                0,
            ),
            (
                MouseEventKind::Up {
                    button: MouseButton::Left,
                    click_count: 1,
                },
                1,
            ),
        ] {
            handle_input(&mut state, &mouse(kind, point), content);
            assert_eq!(state.manual_reduced_motion(), count == 1);
            assert!(state.reduced_motion);
        }
        state.set_system_reduced_motion(false);
        assert!(state.reduced_motion);
        assert!(!state.needs_animation());
    }

    #[test]
    fn translated_and_narrow_document_layout_keeps_controls_and_footer_in_extent() {
        for width in [100.0, 640.0, 840.0, 1104.0] {
            let content = Rect::new(-40.0, -230.0, width, 200.0);
            let layout = Layout::new(content);
            assert_eq!(layout.content.size, extent(content));
            for (_, rect) in layout.actions(RecipeKind::ALL.len()) {
                assert!(rect.min_x() >= layout.content.min_x());
                assert!(rect.max_x() <= layout.content.max_x());
                assert!(rect.min_y() >= layout.content.min_y());
                assert!(rect.max_y() <= layout.content.max_y());
            }
            assert!(layout.content.min_y() + 894.0 + 24.0 < layout.content.max_y());
            assert!(layout.stage.size.width >= 544.0);
            for parameter in Parameter::ALL {
                assert!(layout.slider(parameter).size.width > 0.0);
            }
        }
    }

    #[test]
    fn motion_recipes_reuse_cached_labels_and_render_finite_geometry() {
        use crate::gallery::{static_text::StaticText, text::TextEngine};
        use tekes_ui_scene::Primitive;
        let content = Rect::new(24.0, 24.0, 1104.0, HEIGHT);
        let mut text = TextEngine::new();
        let mut fixture = StaticText::new(None);
        for theme in Theme::ALL {
            for scale in [1.0, 2.0] {
                text.set_scale(scale);
                let mut ctx = PageCtx {
                    theme,
                    text: &mut text,
                    static_text: &mut fixture,
                };
                let mut scene = Scene::new();
                let mut state = MotionPreview::default();
                for catalog in [PresetCatalog::Recipes, PresetCatalog::Symbols] {
                    state.select_catalog(catalog);
                    Painter {
                        ctx: &mut ctx,
                        scene: &mut scene,
                    }
                    .digits(content, "0123456789.-#", "primary-text");
                    for index in 0..state.presets.len() {
                        state.select(index);
                        for dt in [0.0, 0.2, 0.6, 4.0] {
                            state.animate(dt);
                            build(&mut ctx, content, &mut scene, &state);
                        }
                        let shapes = ctx.text.shape_count();
                        state.replay();
                        for _ in 0..120 {
                            state.animate(1.0 / 120.0);
                            ctx.text.begin_frame();
                            scene.clear();
                            build(&mut ctx, content, &mut scene, &state);
                            assert_eq!(
                                ctx.text.shape_count(),
                                shapes,
                                "recipe {index} must reuse shapes"
                            );
                            assert!(scene.primitives().iter().all(|p| match p {
                                Primitive::Quad(q) =>
                                    q.rect.origin.x.is_finite()
                                        && q.rect.origin.y.is_finite()
                                        && q.rect.size.width.is_finite()
                                        && q.rect.size.height.is_finite()
                                        && q.rect.size.width >= 0.0
                                        && q.rect.size.height >= 0.0,
                                _ => true,
                            }));
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn rebuilds_cache_telemetry_and_keep_reduce_motion_button_above_background() {
        use crate::gallery::{static_text::StaticText, text::TextEngine};
        use tekes_ui_scene::Primitive;
        let content = Rect::new(24.0, 24.0, 1104.0, HEIGHT);
        let mut text = TextEngine::new();
        let mut fixture = StaticText::new(None);
        for theme in Theme::ALL {
            for scale in [1.0, 2.0] {
                text.set_scale(scale);
                let mut ctx = PageCtx {
                    theme,
                    text: &mut text,
                    static_text: &mut fixture,
                };
                let mut scene = Scene::new();
                let mut state = MotionPreview::default();
                // Prime the finite telemetry alphabet and all lifecycle labels.
                Painter {
                    ctx: &mut ctx,
                    scene: &mut scene,
                }
                .digits(content, "0123456789.-#", "primary-text");
                build(&mut ctx, content, &mut scene, &state);
                state.replay();
                build(&mut ctx, content, &mut scene, &state);
                state.animate(0.5);
                build(&mut ctx, content, &mut scene, &state);
                state.animate(2.0);
                build(&mut ctx, content, &mut scene, &state);
                let shapes = ctx.text.shape_count();
                state.replay();
                for _ in 0..240 {
                    state.animate(1.0 / 120.0);
                    ctx.text.begin_frame();
                    scene.clear();
                    build(&mut ctx, content, &mut scene, &state);
                    assert_eq!(
                        ctx.text.shape_count(),
                        shapes,
                        "telemetry must reuse cached shapes"
                    );
                }
                state.set_reduced_motion(true);
                ctx.text.begin_frame();
                scene.clear();
                build(&mut ctx, content, &mut scene, &state);
                let center = Layout::new(content).button(Action::ReduceMotion).center();
                let top = scene
                    .primitives()
                    .iter()
                    .rev()
                    .find_map(|p| match p {
                        Primitive::Quad(q) if q.rect.contains(center) => Some(q),
                        _ => None,
                    })
                    .unwrap();
                assert_eq!(top.fill, color(theme, "row-selection"));
                assert!(scene.primitives().iter().all(|p| match p {
                    Primitive::Quad(q) =>
                        q.rect.size.width.is_finite() && q.rect.size.height.is_finite(),
                    _ => true,
                }));
            }
        }
    }
}
