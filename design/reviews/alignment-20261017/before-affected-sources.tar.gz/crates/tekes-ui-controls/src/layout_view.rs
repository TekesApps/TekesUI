//! Component-owned presentation runtimes for layout and navigation controls.
//!
//! Existing model structs stay source compatible. These views bind their model
//! to a single resolved frame, paint through the shared token painters, and own
//! pointer/key arming so Gallery only supplies placement, text shaping, and
//! event translation.
use crate::{
    Button, ButtonLayout, ButtonSize, ButtonTextAlign, ButtonTextRenderer, ControlKey,
    composite::{MenuEvent, MenuLayout, MenuView},
    extended::{
        Axis, Breadcrumb, ComboBox, CommandPalette, ControlFrame, Disclosure, Grid, Link,
        SegmentedControl, SplitView, Stack,
    },
    paint::ButtonVariant,
};
use tekes_ui_scene::{Point, Rect, Scene};
use tekes_ui_tokens::{Palette, proposal};

fn safe_clip(scene: &mut Scene, clip: Option<Rect>) -> bool {
    if let Some(clip) = clip {
        if clip.origin.x.is_finite()
            && clip.origin.y.is_finite()
            && clip.size.width.is_finite()
            && clip.size.height.is_finite()
            && clip.max_x().is_finite()
            && clip.max_y().is_finite()
            && clip.size.width > 0.
            && clip.size.height > 0.
        {
            scene.push_clip(clip);
            true
        } else {
            false
        }
    } else {
        false
    }
}
fn valid(frame: Rect, clip: Option<Rect>) -> bool {
    frame.origin.x.is_finite()
        && frame.origin.y.is_finite()
        && frame.size.width.is_finite()
        && frame.size.height.is_finite()
        && frame.max_x().is_finite()
        && frame.max_y().is_finite()
        && frame.size.width >= 0.
        && frame.size.height >= 0.
        && clip.is_none_or(|c| {
            c.origin.x.is_finite()
                && c.origin.y.is_finite()
                && c.size.width.is_finite()
                && c.size.height.is_finite()
                && c.max_x().is_finite()
                && c.max_y().is_finite()
                && c.size.width > 0.
                && c.size.height > 0.
        })
}

fn has_area(rect: Rect) -> bool {
    rect.size.width.is_finite()
        && rect.size.height.is_finite()
        && rect.size.width > 0.
        && rect.size.height > 0.
        && rect.max_x().is_finite()
        && rect.max_y().is_finite()
}

/// Separates event ownership from a model value changing. Hosts use `consumed`
/// for routing and `changed` for invalidation or event logging.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct ComponentEvent {
    pub consumed: bool,
    pub changed: bool,
}

/// Platform asset backend for one canonical production icon. The backend may
/// resolve/cache SVG raster data or an existing image handle, while IconView
/// owns fitted size, semantic currentColor tint, and the same clip used by hit
/// geometry. No Gallery-only icon artwork belongs in this trait.
pub trait IconRenderer {
    fn draw_icon(
        &mut self,
        scene: &mut Scene,
        canonical_name: &str,
        frame: Rect,
        tint: tekes_ui_tokens::Rgba,
    );
}
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct IconLayout {
    pub frame: Rect,
    pub artboard: Rect,
    pub visible: Option<Rect>,
}
#[derive(Clone, Copy, Debug, Default)]
pub struct IconView {
    layout: IconLayout,
}
impl IconView {
    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        scene: &mut Scene,
        renderer: &mut impl IconRenderer,
        canonical_name: &str,
        frame: Rect,
        requested_size: f32,
        clip: Option<Rect>,
        palette: Palette,
    ) -> IconLayout {
        if canonical_name.trim().is_empty() || !valid(frame, clip) {
            self.layout = IconLayout::default();
            return self.layout;
        }
        let visible = ControlFrame::new(frame, clip).visible_frame();
        let natural = if requested_size.is_finite() && requested_size > 0. {
            requested_size
        } else {
            proposal::metric("size", "size-icon-artboard").unwrap_or(24.)
        };
        let side = natural
            .min(frame.size.width.max(0.))
            .min(frame.size.height.max(0.));
        let artboard = Rect::new(
            frame.center().x - side * 0.5,
            frame.center().y - side * 0.5,
            side,
            side,
        );
        self.layout = IconLayout {
            frame,
            artboard,
            visible,
        };
        if let Some(v) = visible {
            scene.push_clip(v);
            let tint = palette
                .color("primary-text")
                .expect("icon semantic ink token");
            renderer.draw_icon(scene, canonical_name, artboard, tint);
            scene.pop_clip();
        }
        self.layout
    }
    pub fn layout(&self) -> IconLayout {
        self.layout
    }
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct LayoutItems {
    pub frame: Rect,
    pub visible: Option<Rect>,
    pub items: Vec<ControlFrame>,
}

/// Stack owns arrangement and clipping; child painting remains with children.
#[derive(Clone, Debug, Default)]
pub struct StackView {
    model: Stack,
    layout: LayoutItems,
}
impl StackView {
    pub fn new(model: Stack) -> Self {
        Self {
            model,
            layout: LayoutItems::default(),
        }
    }
    pub fn model(&self) -> &Stack {
        &self.model
    }
    pub fn model_mut(&mut self) -> &mut Stack {
        &mut self.model
    }
    pub fn render(&mut self, bounds: Rect, count: usize, clip: Option<Rect>) -> &LayoutItems {
        self.layout = if valid(bounds, clip) {
            let frame = ControlFrame::new(bounds, clip).frame();
            LayoutItems {
                frame,
                visible: ControlFrame::new(bounds, clip).visible_frame(),
                items: self
                    .model
                    .layout(frame, count)
                    .into_iter()
                    .map(|r| ControlFrame::new(r, clip))
                    .collect(),
            }
        } else {
            LayoutItems::default()
        };
        &self.layout
    }
    pub fn layout(&self) -> &LayoutItems {
        &self.layout
    }
}

#[derive(Clone, Debug)]
pub struct GridView {
    model: Grid,
    layout: LayoutItems,
}
impl GridView {
    pub fn new(model: Grid) -> Self {
        Self {
            model,
            layout: LayoutItems::default(),
        }
    }
    pub fn model(&self) -> &Grid {
        &self.model
    }
    pub fn model_mut(&mut self) -> &mut Grid {
        &mut self.model
    }
    pub fn render(
        &mut self,
        bounds: Rect,
        count: usize,
        row_height: f32,
        clip: Option<Rect>,
    ) -> &LayoutItems {
        self.layout = if valid(bounds, clip) {
            let frame = ControlFrame::new(bounds, clip).frame();
            LayoutItems {
                frame,
                visible: ControlFrame::new(bounds, clip).visible_frame(),
                items: self
                    .model
                    .layout(frame, count, row_height)
                    .into_iter()
                    .map(|r| ControlFrame::new(r, clip))
                    .collect(),
            }
        } else {
            LayoutItems::default()
        };
        &self.layout
    }
    pub fn layout(&self) -> &LayoutItems {
        &self.layout
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct SeparatorLayout {
    pub frame: Rect,
    pub visible: Option<Rect>,
}
#[derive(Clone, Copy, Debug, Default)]
pub struct SeparatorView {
    layout: SeparatorLayout,
}
impl SeparatorView {
    pub fn render(
        &mut self,
        scene: &mut Scene,
        frame: Rect,
        axis: Axis,
        clip: Option<Rect>,
        palette: Palette,
    ) -> SeparatorLayout {
        self.layout = if valid(frame, clip) {
            let f = ControlFrame::new(frame, clip);
            if let Some(v) = f.visible_frame() {
                let clipped = safe_clip(scene, clip);
                super::extended::separator(scene, f.frame(), palette, axis);
                if clipped {
                    scene.pop_clip();
                }
                let _ = v;
            }
            SeparatorLayout {
                frame: f.frame(),
                visible: f.visible_frame(),
            }
        } else {
            SeparatorLayout::default()
        };
        self.layout
    }
    pub fn layout(&self) -> SeparatorLayout {
        self.layout
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct SplitViewLayout {
    pub frame: ControlFrame,
    pub leading: ControlFrame,
    pub divider: ControlFrame,
    pub trailing: ControlFrame,
    pub divider_hit: Option<Rect>,
}
#[derive(Clone, Debug)]
pub struct SplitViewView {
    layout: SplitViewLayout,
    axis: Axis,
    dragging: bool,
    window_active: bool,
}
impl SplitViewView {
    pub fn new(axis: Axis) -> Self {
        Self {
            layout: SplitViewLayout::default(),
            axis,
            dragging: false,
            window_active: true,
        }
    }
    pub fn render(
        &mut self,
        scene: &mut Scene,
        model: &mut SplitView,
        bounds: Rect,
        clip: Option<Rect>,
        palette: Palette,
    ) -> SplitViewLayout {
        if !valid(bounds, clip) {
            self.dragging = false;
            self.layout = SplitViewLayout::default();
            return self.layout;
        }
        let f = ControlFrame::new(bounds, clip);
        let (leading, divider, trailing) = model.layout(f.frame(), self.axis);
        self.layout = SplitViewLayout {
            frame: f,
            leading: ControlFrame::new(leading, clip),
            divider: ControlFrame::new(divider, clip),
            trailing: ControlFrame::new(trailing, clip),
            divider_hit: ControlFrame::new(divider.inset(-4.), clip).visible_frame(),
        };
        if !self.layout.frame.visible_frame().is_some_and(has_area) {
            self.cancel(model);
        }
        if !model.is_constrained(f.frame(), self.axis)
            && self.layout.divider.visible_frame().is_some_and(has_area)
        {
            let clipped = safe_clip(scene, clip);
            super::extended::separator(
                scene,
                divider,
                palette,
                match self.axis {
                    Axis::Horizontal => Axis::Vertical,
                    Axis::Vertical => Axis::Horizontal,
                },
            );
            if clipped {
                scene.pop_clip();
            }
        }
        self.layout
    }
    pub fn layout(&self) -> SplitViewLayout {
        self.layout
    }
    pub fn pointer_down(&mut self, p: Point, model: &mut SplitView) -> bool {
        if !self.window_active || !self.layout.divider_hit.is_some_and(|r| r.contains(p)) {
            return false;
        }
        let axis = match self.axis {
            Axis::Horizontal => p.x,
            Axis::Vertical => p.y,
        };
        self.dragging = model.begin_drag(axis, self.layout.frame.frame(), self.axis);
        self.dragging
    }
    pub fn pointer_move(&mut self, p: Point, model: &mut SplitView) -> bool {
        if !self.window_active || !self.dragging {
            return false;
        }
        model.drag_to(
            match self.axis {
                Axis::Horizontal => p.x,
                Axis::Vertical => p.y,
            },
            self.layout.frame.frame(),
            self.axis,
        )
    }
    pub fn pointer_up(&mut self, model: &mut SplitView) -> bool {
        let was = std::mem::replace(&mut self.dragging, false);
        model.end_drag();
        was
    }
    pub fn key(&mut self, key: ControlKey, model: &mut SplitView) -> bool {
        if !self.window_active {
            return false;
        }
        model.key_in(key, self.layout.frame.frame(), self.axis)
    }
    pub fn cancel(&mut self, model: &mut SplitView) -> bool {
        let was = std::mem::replace(&mut self.dragging, false);
        model.cancel_drag();
        was
    }
    pub fn set_window_active(&mut self, active: bool, model: &mut SplitView) {
        self.window_active = active;
        if !active {
            self.cancel(model);
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct ButtonComponentLayout {
    pub frame: Rect,
    pub visible: Option<Rect>,
    pub content: Rect,
}
#[derive(Clone, Debug)]
struct ButtonRuntime {
    button: Button,
    layout: ButtonComponentLayout,
    focused: bool,
    window_active: bool,
    press_target: bool,
}
impl Default for ButtonRuntime {
    fn default() -> Self {
        Self {
            button: Button::default(),
            layout: ButtonComponentLayout::default(),
            focused: false,
            window_active: true,
            press_target: false,
        }
    }
}
impl ButtonRuntime {
    #[allow(clippy::too_many_arguments)]
    fn render(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        label: &str,
        frame: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
        variant: ButtonVariant,
    ) -> ButtonComponentLayout {
        if !valid(frame, clip) {
            self.cancel();
            self.layout = ButtonComponentLayout::default();
            return self.layout;
        }
        self.button.state.focused = self.focused && self.window_active;
        let l = self.button.render(
            scene,
            text,
            label,
            frame,
            clip,
            palette,
            variant,
            ButtonSize::Body,
            role,
            ButtonTextAlign::Leading,
        );
        self.layout = ButtonComponentLayout {
            frame: l.frame,
            visible: l.visible,
            content: l.content,
        };
        if !l.visible.is_some_and(has_area) || self.button.state.disabled {
            self.blur();
        }
        self.layout
    }
    #[allow(clippy::too_many_arguments)]
    fn render_icon_label(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        label: &str,
        frame: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
        variant: ButtonVariant,
        icon_slot_width: f32,
    ) -> ButtonComponentLayout {
        if !valid(frame, clip) {
            self.cancel();
            self.layout = ButtonComponentLayout::default();
            return self.layout;
        }
        let inset = proposal::metric("spacing", "space-relaxed").unwrap_or(12.);
        let available = (frame.size.width - inset * 2.).max(0.);
        let slot_width = icon_slot_width.max(0.).min(available);
        let text_width = (available - slot_width).max(0.);
        let label_size = if label.is_empty() {
            Size::default()
        } else {
            text.measure(label, role, text_width)
        };
        let vertical_inset = ((proposal::metric("size", "size-action-button").unwrap_or(40.)
            - role.style().line_height)
            * 0.5)
            .max(0.);
        let button_frame = Rect::new(
            frame.min_x(),
            frame.min_y(),
            frame.size.width,
            frame
                .size
                .height
                .max(label_size.height + vertical_inset * 2.),
        );
        self.button.state.focused = self.focused && self.window_active;
        let button_layout = self.button.render(
            scene,
            text,
            "",
            button_frame,
            clip,
            palette,
            variant,
            ButtonSize::Body,
            role,
            ButtonTextAlign::Leading,
        );
        let content = Rect::new(
            button_layout.content.min_x() + slot_width,
            button_layout.frame.center().y - label_size.height * 0.5,
            text_width,
            label_size.height,
        );
        self.layout = ButtonComponentLayout {
            frame: button_layout.frame,
            visible: button_layout.visible,
            content,
        };
        let icon_side = proposal::metric("size", "size-icon-artboard").unwrap_or(24.);
        self.icon_frame = Rect::new(
            button_layout.content.min_x() + (slot_width - icon_side) * 0.5,
            button_layout.frame.center().y - icon_side * 0.5,
            icon_side.min(slot_width),
            icon_side.min(slot_width),
        );
        if let Some(visible) = button_layout.visible.filter(|v| has_area(*v)) {
            if !label.is_empty() && has_area(content) {
                scene.push_clip(visible);
                let ink = palette.color("primary-text").expect("primary text token");
                text.draw(scene, label, role, content, ButtonTextAlign::Leading, ink);
                scene.pop_clip();
            }
        } else {
            self.cancel();
            self.layout = ButtonComponentLayout::default();
            self.icon_frame = Rect::default();
        }
        self.layout
    }
    fn pointer_move(&mut self, p: Point) {
        self.button.pointer_move_at(p);
    }
    fn pointer_down(&mut self, p: Point) -> bool {
        if !self.window_active || self.button.state.disabled {
            return false;
        }
        let armed = self.button.pointer_down_at(p);
        self.press_target = armed;
        if armed {
            self.focused = true;
            self.button.state.focused = true;
        }
        armed
    }
    fn pointer_up(&mut self, p: Point) -> bool {
        let was = self.press_target;
        self.press_target = false;
        self.button.pointer_up_at(p) && was && self.window_active
    }
    fn key(&mut self, key: ControlKey, down: bool) -> bool {
        self.window_active
            && self.focused
            && !self.button.state.disabled
            && self.button.key(key, down)
    }
    fn focus(&mut self, visible: bool) {
        self.focused = true;
        self.button.state.focused = true;
        self.button.state.focus_visible = visible;
    }
    fn blur(&mut self) {
        self.focused = false;
        self.button.state.focused = false;
        self.button.state.focus_visible = false;
        self.cancel();
    }
    fn cancel(&mut self) -> bool {
        let had = self.press_target || self.button.state.pressed;
        self.press_target = false;
        self.button.cancel();
        had
    }
    fn active(&mut self, v: bool) {
        self.window_active = v;
        if !v {
            self.blur();
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct DisclosureView {
    runtime: ButtonRuntime,
    icon: IconView,
    icon_frame: Rect,
}
impl DisclosureView {
    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        model: &Disclosure,
        label: &str,
        frame: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
    ) -> ButtonComponentLayout {
        self.runtime.button.state.disabled = model.disabled;
        self.runtime.render_icon_label(
            scene,
            text,
            label,
            frame,
            clip,
            palette,
            role,
            ButtonVariant::Primary,
            24.,
        )
    }
    /// Paints the state icon in the fixed leading slot established by `render`.
    /// Hosts can call this after releasing their text-engine borrow.
    pub fn render_icon(
        &mut self,
        scene: &mut Scene,
        renderer: &mut impl IconRenderer,
        model: &Disclosure,
        clip: Option<Rect>,
        palette: Palette,
        icon_size: f32,
    ) -> IconLayout {
        self.icon.render(
            scene,
            renderer,
            if model.open { "chevron-down" } else { "chevron-right" },
            self.icon_frame,
            icon_size,
            clip,
            palette,
        )
    }
    #[allow(clippy::too_many_arguments)]
    pub fn render_with_icon(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        renderer: &mut impl IconRenderer,
        model: &Disclosure,
        label: &str,
        frame: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
        icon_size: f32,
    ) -> ButtonComponentLayout {
        let layout = self.render(scene, text, model, label, frame, clip, palette, role);
        self.render_icon(scene, renderer, model, clip, palette, icon_size);
        layout
    }
    pub fn icon_frame(&self) -> Rect {
        self.icon_frame
    }
    pub fn pointer_move(&mut self, p: Point) {
        self.runtime.pointer_move(p)
    }
    pub fn pointer_down(&mut self, p: Point) -> bool {
        self.runtime.pointer_down(p)
    }
    pub fn pointer_up(&mut self, p: Point, model: &mut Disclosure) -> bool {
        if self.runtime.pointer_up(p) {
            model.toggle()
        } else {
            false
        }
    }
    pub fn key_event(
        &mut self,
        k: ControlKey,
        down: bool,
        model: &mut Disclosure,
    ) -> ComponentEvent {
        if !matches!(k, ControlKey::Enter | ControlKey::Space) {
            return ComponentEvent::default();
        }
        let consumed = self.runtime.window_active
            && self.runtime.focused
            && !self.runtime.button.state.disabled;
        let activated = self.runtime.key(k, down);
        let changed = activated && model.toggle();
        ComponentEvent { consumed, changed }
    }
    pub fn key(&mut self, k: ControlKey, down: bool, model: &mut Disclosure) -> bool {
        self.key_event(k, down, model).changed
    }
    pub fn focus(&mut self, v: bool) {
        self.runtime.focus(v)
    }
    pub fn blur(&mut self) {
        self.runtime.blur()
    }
    pub fn cancel(&mut self) -> bool {
        self.runtime.cancel()
    }
    pub fn layout(&self) -> ButtonComponentLayout {
        self.runtime.layout
    }
    pub fn activate(&mut self, model: &mut Disclosure) -> bool {
        model.toggle()
    }
    pub fn set_window_active(&mut self, active: bool) {
        self.runtime.window_active = active;
        if !active {
            self.runtime.blur();
        }
    }
}

#[derive(Clone, Debug)]
pub struct IconButtonView {
    runtime: ButtonRuntime,
    icon: IconView,
}
impl IconButtonView {
    pub fn new() -> Self {
        Self {
            runtime: ButtonRuntime::default(),
            icon: IconView::default(),
        }
    }
    pub fn render(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        model: &mut crate::extended::IconButton,
        frame: Rect,
        clip: Option<Rect>,
        palette: Palette,
    ) -> ButtonComponentLayout {
        self.runtime.button.state.disabled = model.button.state.disabled;
        let l = self.runtime.render(
            scene,
            text,
            "",
            frame,
            clip,
            palette,
            proposal::TextRole::UiBody,
            ButtonVariant::Quiet,
        );
        model.button.state = self.runtime.button.state;
        l
    }
    /// Render the icon as part of the component's resolved frame. The Gallery
    /// supplies only its existing asset backend; centering and clipping stay
    /// with this view.
    #[allow(clippy::too_many_arguments)]
    pub fn render_with_icon(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        renderer: &mut impl IconRenderer,
        canonical_name: &str,
        model: &mut crate::extended::IconButton,
        frame: Rect,
        clip: Option<Rect>,
        palette: Palette,
        icon_size: f32,
    ) -> ButtonComponentLayout {
        let layout = self.render(scene, text, model, frame, clip, palette);
        self.render_icon(scene, renderer, canonical_name, clip, palette, icon_size);
        layout
    }
    /// Paint the icon after the host has released its text adapter borrow.
    /// Geometry still comes from the latest component-owned button layout.
    pub fn render_icon(
        &mut self,
        scene: &mut Scene,
        renderer: &mut impl IconRenderer,
        canonical_name: &str,
        clip: Option<Rect>,
        palette: Palette,
        icon_size: f32,
    ) -> IconLayout {
        self.icon.render(
            scene,
            renderer,
            canonical_name,
            self.runtime.layout.frame,
            icon_size,
            clip,
            palette,
        )
    }
    pub fn icon_layout(&self) -> IconLayout {
        self.icon.layout()
    }
    pub fn pointer_move(&mut self, p: Point) {
        self.runtime.pointer_move(p)
    }
    pub fn pointer_down(&mut self, p: Point) -> bool {
        self.runtime.pointer_down(p)
    }
    pub fn pointer_up(&mut self, p: Point, model: &mut crate::extended::IconButton) -> bool {
        let a = self.runtime.pointer_up(p);
        model.button.state = self.runtime.button.state;
        a
    }
    pub fn key(
        &mut self,
        k: ControlKey,
        down: bool,
        model: &mut crate::extended::IconButton,
    ) -> bool {
        self.key_event(k, down, model).changed
    }
    pub fn key_event(
        &mut self,
        k: ControlKey,
        down: bool,
        model: &mut crate::extended::IconButton,
    ) -> ComponentEvent {
        let consumed = matches!(k, ControlKey::Enter | ControlKey::Space)
            && self.runtime.window_active
            && self.runtime.focused
            && !model.button.state.disabled;
        self.runtime.button.state.disabled = model.button.state.disabled;
        let changed = self.runtime.key(k, down);
        model.button.state = self.runtime.button.state;
        ComponentEvent { consumed, changed }
    }
    pub fn activate(&mut self, model: &mut crate::extended::IconButton) -> bool {
        self.runtime.focus(false);
        self.key(ControlKey::Enter, true, model)
    }
    pub fn focus(&mut self, v: bool) {
        self.runtime.focus(v)
    }
    pub fn blur(&mut self) {
        self.runtime.blur()
    }
    pub fn layout(&self) -> ButtonComponentLayout {
        self.runtime.layout
    }
    pub fn cancel(&mut self) -> bool {
        self.runtime.cancel()
    }
    pub fn set_window_active(&mut self, v: bool) {
        self.runtime.active(v)
    }
}
impl Default for IconButtonView {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Clone, Debug)]
pub struct LinkView {
    button: Button,
    layout: ButtonComponentLayout,
    focused: bool,
    focus_visible: bool,
    hovered: bool,
    pressed: bool,
    window_active: bool,
    visible: Option<Rect>,
}
impl LinkView {
    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        model: &mut Link,
        label: &str,
        frame: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
    ) -> ButtonComponentLayout {
        self.button.state.disabled = model.button.state.disabled;
        let visible = ControlFrame::new(frame, clip).visible_frame();
        if !visible.is_some_and(has_area) || model.button.state.disabled {
            self.blur();
        }
        let inset = proposal::metric("spacing", "space-button-body-inset")
            .unwrap_or(8.)
            .max(0.);
        let content = Rect::new(
            frame.min_x() + inset,
            frame.min_y(),
            (frame.size.width - inset * 2.).max(0.),
            frame.size.height.max(0.),
        );
        self.layout = ButtonComponentLayout {
            frame,
            visible,
            content,
        };
        self.visible = visible;
        self.button.state.hovered = self.hovered && visible.is_some() && self.window_active;
        self.button.state.pressed = self.pressed && self.hovered && self.window_active;
        self.button.state.focused = self.focused && self.window_active;
        self.button.state.focus_visible = self.focused && self.focus_visible && self.window_active;
        if let Some(v) = visible {
            scene.push_clip(v);
            let ink = crate::extended::link_underline(scene, frame, palette, self.button.state);
            text.draw(scene, label, role, content, ButtonTextAlign::Leading, ink);
            scene.pop_clip();
        }
        model.button.state = self.button.state;
        self.layout
    }
    pub fn pointer_move(&mut self, p: Point) {
        self.hovered = self.window_active && self.visible.is_some_and(|v| v.contains(p));
        if self.pressed && !self.hovered {
            self.button.state.pressed = false;
        }
    }
    pub fn pointer_down(&mut self, p: Point) -> bool {
        if !self.window_active
            || self.button.state.disabled
            || !self.visible.is_some_and(|v| v.contains(p))
        {
            return false;
        }
        self.pressed = true;
        self.hovered = true;
        self.focused = true;
        self.focus_visible = false;
        self.button.pointer_down();
        true
    }
    pub fn pointer_up(&mut self, p: Point, model: &mut Link) -> bool {
        let armed = std::mem::replace(&mut self.pressed, false);
        let inside = self.window_active && self.visible.is_some_and(|v| v.contains(p));
        let activated = self.button.pointer_up(inside) && armed && self.window_active;
        model.button.state = self.button.state;
        activated
    }
    pub fn key(&mut self, k: ControlKey, down: bool, model: &mut Link) -> ComponentEvent {
        if k != ControlKey::Enter
            || !self.focused
            || !self.window_active
            || self.button.state.disabled
        {
            return ComponentEvent::default();
        }
        self.button.state.focused = true;
        let changed = self.button.key(k, down);
        model.button.state = self.button.state;
        ComponentEvent {
            consumed: true,
            changed,
        }
    }
    pub fn activate(&mut self, model: &mut Link) -> bool {
        if !self.focused {
            self.focus(false);
        }
        self.key(ControlKey::Enter, true, model).changed
    }
    pub fn focus(&mut self, visible: bool) {
        self.focused = true;
        self.focus_visible = visible;
        self.button.state.focused = true;
        self.button.state.focus_visible = visible;
    }
    pub fn blur(&mut self) {
        self.focused = false;
        self.focus_visible = false;
        self.button.blur();
        self.cancel();
    }
    pub fn cancel(&mut self) -> bool {
        let had = self.pressed || self.button.state.pressed;
        self.pressed = false;
        self.button.cancel();
        had
    }
    pub fn layout(&self) -> ButtonComponentLayout {
        self.layout
    }
    pub fn set_window_active(&mut self, v: bool) {
        self.window_active = v;
        if !v {
            self.blur();
        }
    }
}
impl Default for LinkView {
    fn default() -> Self {
        Self {
            button: Button::default(),
            layout: ButtonComponentLayout::default(),
            focused: false,
            focus_visible: false,
            hovered: false,
            pressed: false,
            window_active: true,
            visible: None,
        }
    }
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct SegmentedLayout {
    pub frame: Rect,
    pub items: Vec<ButtonLayout>,
}
#[derive(Clone, Debug)]
pub struct SegmentedControlView {
    buttons: Vec<Button>,
    layout: SegmentedLayout,
    focused: Option<usize>,
    focus_visible: bool,
    hovered: Option<usize>,
    pressed: Option<usize>,
    space_armed: Option<usize>,
    window_active: bool,
}
impl SegmentedControlView {
    pub fn new(count: usize) -> Self {
        Self {
            buttons: vec![Button::default(); count],
            layout: SegmentedLayout::default(),
            focused: None,
            focus_visible: false,
            hovered: None,
            pressed: None,
            space_armed: None,
            window_active: true,
        }
    }
    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        model: &mut SegmentedControl,
        labels: &[&str],
        frame: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
        compact: bool,
    ) -> SegmentedLayout {
        if !valid(frame, clip) {
            self.cancel();
            self.focused = None;
            self.hovered = None;
            self.layout = SegmentedLayout::default();
            return self.layout.clone();
        }
        let count = model.len().min(labels.len()).min(self.buttons.len());
        let cells = Stack::new(Axis::Horizontal).layout(frame, count);
        let mut items = Vec::with_capacity(count);
        let clipped = safe_clip(scene, clip);
        for i in 0..count {
            let button = &mut self.buttons[i];
            let disabled = !model.is_enabled(i);
            button.state.disabled = disabled;
            button.state.selected = model.selected == i;
            button.state.focused = self.window_active && self.focused == Some(i);
            button.state.focus_visible = button.state.focused && self.focus_visible;
            button.state.hovered = self.window_active && self.hovered == Some(i);
            button.state.pressed = self.window_active && self.pressed == Some(i);
            let size = if compact {
                ButtonSize::Sm
            } else {
                ButtonSize::Md
            };
            let l = button.render(
                scene,
                text,
                labels[i],
                cells[i],
                clip,
                palette,
                ButtonVariant::Quiet,
                size,
                role,
                ButtonTextAlign::Leading,
            );
            items.push(l);
        }
        if clipped {
            scene.pop_clip();
        }
        self.layout = SegmentedLayout { frame, items };
        if !self
            .layout
            .items
            .iter()
            .any(|item| item.visible.is_some_and(has_area))
        {
            self.cancel();
            self.focused = None;
            self.hovered = None;
        }
        self.layout.clone()
    }
    pub fn pointer_move(&mut self, p: Point) {
        self.hovered = self.layout.items.iter().position(|l| l.hit_test(p));
        for (i, b) in self.buttons.iter_mut().enumerate() {
            b.pointer_move_at(p);
            if self.pressed == Some(i) {
                b.state.pressed = self.hovered == Some(i)
            }
        }
    }
    pub fn pointer_down(&mut self, p: Point) -> Option<usize> {
        if !self.window_active {
            return None;
        }
        let i = self.layout.items.iter().position(|l| l.hit_test(p))?;
        if self.buttons[i].state.disabled {
            return None;
        }
        self.buttons[i].pointer_down_at(p);
        self.pressed = Some(i);
        self.focused = Some(i);
        self.focus_visible = false;
        Some(i)
    }
    pub fn pointer_up(&mut self, p: Point, model: &mut SegmentedControl) -> Option<usize> {
        let i = self.pressed.take()?;
        let ok = self.buttons.get_mut(i).is_some_and(|b| b.pointer_up_at(p));
        if ok && self.window_active && model.select(i) {
            Some(i)
        } else {
            None
        }
    }
    pub fn key_event(
        &mut self,
        key: ControlKey,
        down: bool,
        model: &mut SegmentedControl,
    ) -> ComponentEvent {
        let Some(index) = self.focused.filter(|_| self.window_active) else {
            return ComponentEvent::default();
        };
        if !model.is_enabled(index) {
            return ComponentEvent::default();
        }
        if key == ControlKey::Space {
            if down {
                if self.space_armed.is_none() {
                    self.space_armed = Some(index);
                }
                return ComponentEvent {
                    consumed: true,
                    changed: false,
                };
            }
            let armed = self.space_armed.take() == Some(index);
            let changed = armed && model.select(index);
            return ComponentEvent {
                consumed: true,
                changed,
            };
        }
        if !down {
            return ComponentEvent::default();
        }
        let supported = matches!(
            key,
            ControlKey::Left
                | ControlKey::Right
                | ControlKey::Up
                | ControlKey::Down
                | ControlKey::Home
                | ControlKey::End
        );
        if !supported {
            return ComponentEvent::default();
        }
        self.focus_visible = true;
        let changed = model.key(key);
        if changed {
            self.focused = Some(model.selected);
        }
        ComponentEvent {
            consumed: true,
            changed,
        }
    }
    pub fn key(&mut self, key: ControlKey, down: bool, model: &mut SegmentedControl) -> bool {
        self.key_event(key, down, model).changed
    }
    pub fn select(&mut self, index: usize, model: &mut SegmentedControl) -> bool {
        let changed = model.select(index);
        if changed {
            self.focused = Some(index);
            self.focus_visible = false;
            self.cancel();
        }
        changed
    }
    pub fn focus(&mut self, i: usize) {
        self.focus_with_visibility(i, true)
    }
    pub fn focus_with_visibility(&mut self, i: usize, visible: bool) {
        if i < self.buttons.len() && self.buttons.get(i).is_some_and(|b| !b.state.disabled) {
            self.focused = Some(i);
            self.focus_visible = visible;
        }
    }
    pub fn blur(&mut self) {
        self.focused = None;
        self.focus_visible = false;
        self.cancel();
    }
    pub fn cancel(&mut self) -> bool {
        let pointer = self.pressed.take().is_some();
        let keyboard = self.space_armed.take().is_some();
        for b in &mut self.buttons {
            b.cancel();
        }
        pointer || keyboard
    }
    pub fn set_window_active(&mut self, v: bool) {
        self.window_active = v;
        if !v {
            self.blur();
        }
    }
    pub fn layout(&self) -> &SegmentedLayout {
        &self.layout
    }
}
impl Default for SegmentedControlView {
    fn default() -> Self {
        Self::new(0)
    }
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct BreadcrumbLayout {
    pub frame: Rect,
    pub items: Vec<ControlFrame>,
}
#[derive(Clone, Debug)]
pub struct BreadcrumbView {
    layout: BreadcrumbLayout,
    buttons: Vec<Button>,
    focused: Option<usize>,
    focus_visible: bool,
    hovered: Option<usize>,
    pressed: Option<usize>,
    window_active: bool,
}
impl BreadcrumbView {
    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        model: &Breadcrumb,
        labels: &[&str],
        frame: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
    ) -> BreadcrumbLayout {
        if !valid(frame, clip) {
            self.cancel();
            self.focused = None;
            self.hovered = None;
            self.layout = BreadcrumbLayout::default();
            return self.layout.clone();
        }
        let n = model.items.len().min(labels.len());
        self.buttons.resize_with(n, Button::default);
        let mut cells = Vec::new();
        let mut x = frame.min_x();
        for (i, label) in labels.iter().take(n).enumerate() {
            let size = Button::measure(
                text,
                label,
                (frame.max_x() - x).max(0.),
                ButtonSize::Body,
                role,
            );
            let w = if i + 1 == n {
                (frame.max_x() - x).max(0.)
            } else {
                (size.width + 22.).min((frame.max_x() - x).max(0.))
            };
            cells.push(Rect::new(x, frame.min_y(), w, frame.size.height));
            x += w;
            if i + 1 < n {
                x += 8.;
            }
        }
        let clipped = safe_clip(scene, clip);
        let mut items = Vec::new();
        for i in 0..n {
            let b = &mut self.buttons[i];
            b.state.disabled = i + 1 == n;
            b.state.selected = i + 1 == n;
            b.state.focused = self.window_active && self.focused == Some(i);
            b.state.focus_visible = b.state.focused && self.focus_visible;
            b.state.hovered = self.window_active && self.hovered == Some(i);
            b.state.pressed = self.window_active && self.pressed == Some(i);
            let l = b.render(
                scene,
                text,
                labels[i],
                cells[i],
                clip,
                palette,
                ButtonVariant::Quiet,
                ButtonSize::Body,
                role,
                ButtonTextAlign::Leading,
            );
            if i + 1 < n {
                let separator = Rect::new(
                    (cells[i].max_x() - 13.0).max(cells[i].min_x()),
                    frame.min_y(),
                    (cells[i].max_x() - 5.0).max(cells[i].min_x())
                        - (cells[i].max_x() - 13.0).max(cells[i].min_x()),
                    frame.size.height,
                );
                text.draw(
                    scene,
                    "/",
                    role,
                    separator,
                    ButtonTextAlign::Center,
                    palette.color("primary-text").expect("primary text token"),
                );
            }
            items.push(ControlFrame::new(l.frame, clip));
        }
        if clipped {
            scene.pop_clip();
        }
        self.layout = BreadcrumbLayout { frame, items };
        if !self
            .layout
            .items
            .iter()
            .any(|item| item.visible_frame().is_some_and(has_area))
        {
            self.cancel();
            self.focused = None;
            self.hovered = None;
        }
        self.layout.clone()
    }
    pub fn pointer_move(&mut self, p: Point) {
        self.hovered = self
            .window_active
            .then(|| self.layout.items.iter().position(|l| l.contains(p)))
            .flatten();
        for b in &mut self.buttons {
            b.pointer_move_at(p);
        }
    }
    pub fn pointer_down(&mut self, p: Point) -> Option<usize> {
        if !self.window_active {
            return None;
        }
        let i = self.layout.items.iter().position(|l| l.contains(p))?;
        if i + 1 == self.layout.items.len() || self.buttons[i].state.disabled {
            return None;
        }
        self.buttons[i].pointer_down_at(p);
        self.pressed = Some(i);
        self.focused = Some(i);
        self.focus_visible = false;
        Some(i)
    }
    pub fn pointer_up(&mut self, p: Point, model: &Breadcrumb) -> Option<usize> {
        let i = self.pressed.take()?;
        if self.window_active && self.buttons[i].pointer_up_at(p) {
            model.activate(i)
        } else {
            None
        }
    }
    pub fn key_event(
        &mut self,
        k: ControlKey,
        down: bool,
        model: &Breadcrumb,
    ) -> (bool, Option<usize>) {
        let Some(i) = self.focused.filter(|_| self.window_active) else {
            return (false, None);
        };
        if k == ControlKey::Space || k == ControlKey::Enter {
            if down && k == ControlKey::Enter {
                return (true, model.activate(i));
            }
            return (true, None);
        }
        (false, None)
    }
    pub fn key(&mut self, k: ControlKey, down: bool, model: &Breadcrumb) -> Option<usize> {
        self.key_event(k, down, model).1
    }
    pub fn activate(&mut self, index: usize, model: &Breadcrumb) -> Option<usize> {
        self.focused = Some(index);
        self.focus_visible = false;
        model.activate(index)
    }
    pub fn focus(&mut self, i: usize) {
        self.focus_with_visibility(i, true)
    }
    pub fn focus_with_visibility(&mut self, i: usize, visible: bool) {
        if i + 1 < self.buttons.len() && !self.buttons[i].state.disabled {
            self.focused = Some(i);
            self.focus_visible = visible;
        }
    }
    pub fn blur(&mut self) {
        self.focused = None;
        self.focus_visible = false;
        self.cancel();
    }
    pub fn cancel(&mut self) -> bool {
        let had = self.pressed.take().is_some();
        for b in &mut self.buttons {
            b.cancel();
        }
        had
    }
    pub fn set_window_active(&mut self, v: bool) {
        self.window_active = v;
        if !v {
            self.blur();
        }
    }
    pub fn layout(&self) -> &BreadcrumbLayout {
        &self.layout
    }
}
impl Default for BreadcrumbView {
    fn default() -> Self {
        Self {
            layout: BreadcrumbLayout::default(),
            buttons: Vec::new(),
            focused: None,
            focus_visible: false,
            hovered: None,
            pressed: None,
            window_active: true,
        }
    }
}

/// Shared popup adapter for ComboBox and CommandPalette. The editable text
/// surface remains a host bridge; option layout, clipping, hover, keyboard
/// navigation, and popup dismissal are owned here.
#[derive(Debug)]
pub struct FilteredMenuView {
    menu: crate::Menu,
    menu_view: MenuView,
    mapping: Vec<usize>,
    layout: Option<MenuLayout>,
}
impl FilteredMenuView {
    pub fn new() -> Self {
        Self {
            menu: crate::Menu::new(0),
            menu_view: MenuView::new_external(),
            mapping: Vec::new(),
            layout: None,
        }
    }
    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        items: &[String],
        mapping: &[usize],
        active: Option<usize>,
        open: bool,
        anchor: Rect,
        visible: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
        compact: bool,
    ) -> Option<MenuLayout> {
        self.mapping = mapping.to_vec();
        self.menu.items.count = items.len();
        self.menu.items.selected = active.unwrap_or(0).min(items.len().saturating_sub(1));
        self.menu.open = open;
        if open {
            let _ = self
                .menu_view
                .set_window_active_with_model(&mut self.menu, true);
        }
        let labels: Vec<&str> = items.iter().map(String::as_str).collect();
        let l = self.menu_view.render_with_model(
            &mut self.menu,
            scene,
            text,
            &labels,
            anchor,
            visible,
            clip,
            palette,
            role,
            compact,
        )?;
        self.layout = Some(l.clone());
        Some(l)
    }
    pub fn pointer_move(&mut self, p: Point) -> bool {
        let before = self.menu.items.selected;
        self.menu_view.pointer_move_with_model(&mut self.menu, p);
        before != self.menu.items.selected
    }
    pub fn pointer_down(&mut self, p: Point) -> MenuEvent {
        self.menu_view.pointer_down_with_model(&mut self.menu, p)
    }
    pub fn pointer_up(&mut self, p: Point) -> MenuEvent {
        self.menu_view.pointer_up_with_model(&mut self.menu, p)
    }
    pub fn key(&mut self, k: ControlKey, down: bool) -> MenuEvent {
        self.menu_view.key_with_model(&mut self.menu, k, down)
    }
    pub fn active_index(&self) -> Option<usize> {
        self.mapping.get(self.menu.items.selected).copied()
    }
    pub fn original_index(&self, filtered_index: usize) -> Option<usize> {
        self.mapping.get(filtered_index).copied()
    }
    pub fn is_visible(&self) -> bool {
        self.layout
            .as_ref()
            .is_some_and(|layout| layout.visible.is_some_and(has_area))
    }
    pub fn dismiss(&mut self) {
        let _ = self
            .menu_view
            .set_window_active_with_model(&mut self.menu, false);
        self.menu.open = false;
    }
    pub fn cancel(&mut self) {
        let _ = self
            .menu_view
            .set_window_active_with_model(&mut self.menu, false);
        self.menu.open = false;
    }
    pub fn layout(&self) -> Option<&MenuLayout> {
        self.layout.as_ref()
    }
}
impl Default for FilteredMenuView {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct SelectLayout {
    pub trigger: ButtonLayout,
    pub popup: Option<MenuLayout>,
}
impl Default for SelectLayout {
    fn default() -> Self {
        Self {
            trigger: ButtonLayout {
                frame: Rect::default(),
                content: Rect::default(),
                visible: None,
                label_size: tekes_ui_scene::Size::default(),
            },
            popup: None,
        }
    }
}
#[derive(Debug)]
pub struct SelectView {
    trigger: Button,
    menu: MenuView,
    layout: SelectLayout,
    window_active: bool,
    disabled: bool,
}
impl SelectView {
    pub fn new(_count: usize) -> Self {
        Self {
            trigger: Button::default(),
            menu: MenuView::new_external(),
            layout: SelectLayout::default(),
            window_active: true,
            disabled: false,
        }
    }
    pub fn set_disabled(&mut self, disabled: bool, model: &mut crate::Select) {
        self.disabled = disabled;
        self.trigger.state.disabled = disabled;
        self.menu.set_disabled_with_model(&mut model.menu, disabled);
        if disabled {
            self.cancel(model);
        }
    }
    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        model: &mut crate::Select,
        labels: &[&str],
        frame: Rect,
        viewport: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
        compact: bool,
    ) -> SelectLayout {
        if !valid(frame, clip) {
            self.cancel(model);
            self.layout = SelectLayout::default();
            return self.layout.clone();
        }
        self.trigger.state.disabled = self.disabled;
        self.trigger.state.focused =
            self.trigger.state.focused && self.window_active && !self.disabled;
        let selected = model.selected.min(labels.len().saturating_sub(1));
        let title = labels.get(selected).copied().unwrap_or("");
        let trigger = self.trigger.render(
            scene,
            text,
            title,
            frame,
            clip,
            palette,
            ButtonVariant::Primary,
            ButtonSize::Body,
            role,
            ButtonTextAlign::Leading,
        );
        model.menu.items.count = labels.len();
        if !model.menu.open {
            model.menu.items.selected = model.selected.min(labels.len().saturating_sub(1));
        } else if model.menu.items.selected >= labels.len() {
            model.menu.items.selected = labels.len().saturating_sub(1);
        }
        if model.menu.open {
            let _ = self
                .menu
                .set_window_active_with_model(&mut model.menu, self.window_active);
        }
        let popup = if model.menu.open {
            self.menu.render_with_model(
                &mut model.menu,
                scene,
                text,
                labels,
                trigger.frame,
                viewport,
                clip,
                palette,
                role,
                compact,
            )
        } else {
            None
        };
        self.layout = SelectLayout { trigger, popup };
        if !self.layout.trigger.visible.is_some_and(has_area)
            || model.menu.open
                && self
                    .layout
                    .popup
                    .as_ref()
                    .is_none_or(|layout| !layout.visible.is_some_and(has_area))
        {
            self.cancel(model);
        }
        self.layout.clone()
    }
    pub fn pointer_move(&mut self, p: Point, model: &mut crate::Select) {
        if !self.window_active || self.disabled {
            return;
        }
        self.trigger.pointer_move_at(p);
        if model.menu.open {
            self.menu.pointer_move_with_model(&mut model.menu, p);
        }
    }
    pub fn pointer_down(&mut self, p: Point, model: &mut crate::Select) -> bool {
        if !self.window_active || self.disabled {
            return false;
        }
        let mut dismissed = false;
        if model.menu.open {
            if self
                .layout
                .popup
                .as_ref()
                .is_some_and(|l| l.visible.is_some_and(|v| v.contains(p)))
            {
                let _ = self.menu.pointer_down_with_model(&mut model.menu, p);
                return true;
            }
            dismissed = matches!(
                self.menu.pointer_down_with_model(&mut model.menu, p),
                MenuEvent::Dismissed { .. }
            );
        }
        self.trigger.pointer_down_at(p) || dismissed
    }
    pub fn pointer_up(&mut self, p: Point, model: &mut crate::Select) -> MenuEvent {
        if !self.window_active || self.disabled {
            return MenuEvent::None;
        }
        if model.menu.open {
            let event = self.menu.pointer_up_with_model(&mut model.menu, p);
            if let MenuEvent::Activated { index, .. } = event {
                let _ = model.choose(index);
            }
            return event;
        }
        if self.trigger.pointer_up_at(p) {
            if model.menu.open {
                model.menu.open = false;
            } else {
                self.menu.show_with_model(&mut model.menu, 0);
                model.menu.items.selected =
                    model.selected.min(model.menu.items.count.saturating_sub(1));
            }
        } else if model.menu.open {
            model.menu.open = false;
        }
        MenuEvent::None
    }
    pub fn key(&mut self, key: ControlKey, down: bool, model: &mut crate::Select) -> MenuEvent {
        if !self.window_active || self.disabled {
            return MenuEvent::None;
        }
        if model.menu.open {
            let event = self.menu.key_with_model(&mut model.menu, key, down);
            if let MenuEvent::Activated { index, .. } = event {
                let _ = model.choose(index);
            }
            event
        } else if matches!(key, ControlKey::Enter | ControlKey::Space)
            && self.trigger.key(key, down)
        {
            self.menu.show_with_model(&mut model.menu, 0);
            model.menu.items.selected =
                model.selected.min(model.menu.items.count.saturating_sub(1));
            MenuEvent::None
        } else {
            MenuEvent::None
        }
    }
    pub fn wheel_event(
        &mut self,
        input: crate::MenuWheelInput,
        model: &crate::Select,
    ) -> crate::MenuWheelEvent {
        if !self.window_active || !model.menu.open {
            return crate::MenuWheelEvent::Ignored;
        }
        self.menu.wheel_event_with_model(&model.menu, input)
    }
    pub fn focus(&mut self, visible: bool) {
        self.trigger.state.focused = true;
        self.trigger.state.focus_visible = visible;
    }
    pub fn blur(&mut self, model: &mut crate::Select) {
        self.trigger.blur();
        model.menu.open = false;
        let _ = self
            .menu
            .set_window_active_with_model(&mut model.menu, false);
    }
    pub fn cancel(&mut self, model: &mut crate::Select) {
        self.trigger.cancel();
        model.menu.open = false;
        let _ = self
            .menu
            .set_window_active_with_model(&mut model.menu, false);
    }
    pub fn set_window_active(&mut self, active: bool, model: &mut crate::Select) {
        self.window_active = active;
        let _ = self
            .menu
            .set_window_active_with_model(&mut model.menu, active);
        if !active {
            self.cancel(model);
        }
    }
    pub fn layout(&self) -> &SelectLayout {
        &self.layout
    }
}
impl Default for SelectView {
    fn default() -> Self {
        Self::new(0)
    }
}

#[derive(Debug, Default)]
pub struct ComboBoxView {
    pub options: FilteredMenuView,
}
impl ComboBoxView {
    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        model: &mut ComboBox,
        anchor: Rect,
        visible: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
        compact: bool,
    ) -> Option<MenuLayout> {
        if model.disabled {
            model.open = false;
            self.options.cancel();
        }
        let map = model.filtered();
        let filtered: Vec<String> = map.iter().map(|i| model.items[*i].clone()).collect();
        let active = model.active.and_then(|i| map.iter().position(|x| *x == i));
        self.options.render(
            scene, text, &filtered, &map, active, model.open, anchor, visible, clip, palette, role,
            compact,
        )
    }
    pub fn pointer_move(&mut self, p: Point, model: &mut ComboBox) {
        if self.options.pointer_move(p) {
            model.active = self.options.active_index();
        }
    }
    pub fn pointer_down(&mut self, p: Point) -> MenuEvent {
        self.options.pointer_down(p)
    }
    pub fn pointer_up(&mut self, p: Point, model: &mut ComboBox) -> Option<usize> {
        if let MenuEvent::Activated { index, .. } = self.options.pointer_up(p) {
            let original = *self.options.mapping.get(index)?;
            model.selected = Some(original);
            model.query = model.items[original].clone();
            model.open = false;
            self.options.cancel();
            Some(original)
        } else {
            None
        }
    }
    pub fn key_event(&mut self, k: ControlKey, down: bool, model: &mut ComboBox) -> ComponentEvent {
        if model.disabled {
            return ComponentEvent::default();
        }
        let supported = matches!(
            k,
            ControlKey::Escape | ControlKey::Enter | ControlKey::Up | ControlKey::Down
        );
        let can_open = !model.open && matches!(k, ControlKey::Enter | ControlKey::Down);
        if !supported || (!model.open && !can_open) {
            return ComponentEvent::default();
        }
        let before = (
            model.open,
            model.active,
            model.selected,
            model.query.clone(),
        );
        if down {
            // The model owns the current filtered mapping and active item. A
            // text command can arrive before another render, so routing keys
            // through the last rendered menu would use stale query results.
            let _ = model.key(k);
            if !model.open {
                self.options.cancel();
            }
        }
        ComponentEvent {
            consumed: true,
            changed: before
                != (
                    model.open,
                    model.active,
                    model.selected,
                    model.query.clone(),
                ),
        }
    }
    pub fn key(&mut self, k: ControlKey, down: bool, model: &mut ComboBox) -> Option<usize> {
        let before = model.selected;
        let event = self.key_event(k, down, model);
        if event.changed && model.selected != before {
            model.selected
        } else {
            None
        }
    }
}
#[derive(Debug)]
pub struct CommandPaletteView {
    pub options: FilteredMenuView,
    trigger: Button,
    trigger_layout: Option<ButtonLayout>,
    window_active: bool,
}
impl CommandPaletteView {
    #[allow(clippy::too_many_arguments)]
    pub fn render_trigger(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        model: &mut CommandPalette,
        label: &str,
        frame: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
    ) -> ButtonLayout {
        self.trigger.state.disabled = model.combo.disabled;
        if model.combo.disabled {
            self.cancel(model);
        }
        self.trigger_layout = Some(self.trigger.render(
            scene,
            text,
            label,
            frame,
            clip,
            palette,
            ButtonVariant::Primary,
            ButtonSize::Body,
            role,
            ButtonTextAlign::Leading,
        ));
        self.trigger_layout.unwrap_or_else(|| ButtonLayout {
            frame: Rect::default(),
            content: Rect::default(),
            visible: None,
            label_size: tekes_ui_scene::Size::default(),
        })
    }
    pub fn pointer_down_trigger(&mut self, p: Point) -> bool {
        if !self.window_active || self.trigger.state.disabled {
            return false;
        }
        self.trigger.pointer_down_at(p)
    }
    pub fn pointer_up_trigger(&mut self, p: Point, model: &mut CommandPalette) -> bool {
        let activated = self.trigger.pointer_up_at(p);
        if activated && self.window_active {
            model.open();
            true
        } else {
            false
        }
    }
    pub fn trigger_key(
        &mut self,
        k: ControlKey,
        down: bool,
        model: &mut CommandPalette,
    ) -> ComponentEvent {
        if !self.window_active
            || self.trigger.state.disabled
            || !self.trigger.state.focused
            || !matches!(k, ControlKey::Enter | ControlKey::Space)
        {
            return ComponentEvent::default();
        }
        let changed = self.trigger.key(k, down);
        if changed {
            model.open();
        }
        ComponentEvent {
            consumed: true,
            changed,
        }
    }
    pub fn open(&mut self, model: &mut CommandPalette) {
        model.open();
    }
    pub fn focus_trigger(&mut self, visible: bool) {
        self.trigger.state.focused = true;
        self.trigger.state.focus_visible = visible;
    }
    pub fn blur(&mut self, model: &mut CommandPalette) {
        self.trigger.blur();
        self.cancel(model);
    }
    pub fn cancel(&mut self, model: &mut CommandPalette) {
        model.combo.open = false;
        self.trigger.cancel();
        self.options.cancel();
    }
    pub fn set_window_active(&mut self, active: bool, model: &mut CommandPalette) {
        self.window_active = active;
        if !active {
            self.blur(model);
        }
    }
    pub fn trigger_layout(&self) -> Option<ButtonLayout> {
        self.trigger_layout
    }
    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        model: &mut CommandPalette,
        anchor: Rect,
        visible: Rect,
        clip: Option<Rect>,
        palette: Palette,
        role: proposal::TextRole,
        compact: bool,
    ) -> Option<MenuLayout> {
        if model.combo.disabled {
            model.combo.open = false;
            self.options.cancel();
        }
        if model.combo.open {
            let _ = self
                .options
                .menu_view
                .set_window_active_with_model(&mut self.options.menu, true);
        }
        let map = model.combo.filtered();
        let items: Vec<String> = map.iter().map(|i| model.combo.items[*i].clone()).collect();
        let active = model
            .combo
            .active
            .and_then(|i| map.iter().position(|x| *x == i));
        self.options.render(
            scene,
            text,
            &items,
            &map,
            active,
            model.combo.open,
            anchor,
            visible,
            clip,
            palette,
            role,
            compact,
        )
    }
    pub fn key_event(
        &mut self,
        k: ControlKey,
        down: bool,
        model: &mut CommandPalette,
    ) -> ComponentEvent {
        if model.combo.disabled {
            return ComponentEvent::default();
        }
        if !model.combo.open
            || !matches!(
                k,
                ControlKey::Escape | ControlKey::Up | ControlKey::Down | ControlKey::Enter
            )
        {
            return ComponentEvent::default();
        }
        let before = (
            model.combo.open,
            model.combo.active,
            model.combo.selected,
            model.combo.query.clone(),
        );
        if down {
            // CommandPalette shares the ComboBox model contract. Resolve from
            // its live query rather than a menu mapping populated by render.
            let _ = model.combo.key(k);
            if !model.combo.open {
                self.options.cancel();
            }
        }
        ComponentEvent {
            consumed: true,
            changed: before
                != (
                    model.combo.open,
                    model.combo.active,
                    model.combo.selected,
                    model.combo.query.clone(),
                ),
        }
    }
    pub fn key(&mut self, k: ControlKey, down: bool, model: &mut CommandPalette) -> Option<usize> {
        let before = model.combo.selected;
        let event = self.key_event(k, down, model);
        if event.changed && model.combo.selected != before {
            model.combo.selected
        } else {
            None
        }
    }
    pub fn pointer_move(&mut self, p: Point, model: &mut CommandPalette) {
        if self.options.pointer_move(p) {
            model.combo.active = self.options.active_index();
        }
    }
    pub fn pointer_down(&mut self, p: Point) -> MenuEvent {
        self.options.pointer_down(p)
    }
    pub fn pointer_up(&mut self, p: Point, model: &mut CommandPalette) -> Option<usize> {
        if let MenuEvent::Activated { index, .. } = self.options.pointer_up(p) {
            let original = *self.options.mapping.get(index)?;
            model.combo.selected = Some(original);
            model.combo.query = model.combo.items[original].clone();
            model.combo.open = false;
            self.options.cancel();
            Some(original)
        } else {
            None
        }
    }
}
impl Default for CommandPaletteView {
    fn default() -> Self {
        Self {
            options: FilteredMenuView::default(),
            trigger: Button::default(),
            trigger_layout: None,
            window_active: true,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tekes_ui_scene::Size;
    use tekes_ui_tokens::Theme;

    struct FixedText;
    impl ButtonTextRenderer for FixedText {
        fn measure(&mut self, text: &str, role: proposal::TextRole, max_width: f32) -> Size {
            Size::new(
                (text.chars().count() as f32 * 8.).min(max_width),
                role.style().line_height,
            )
        }
        fn draw(
            &mut self,
            _: &mut Scene,
            _: &str,
            _: proposal::TextRole,
            _: Rect,
            _: ButtonTextAlign,
            _: tekes_ui_tokens::Rgba,
        ) {
        }
    }

    #[test]
    fn stack_and_grid_views_preserve_frames_and_reject_overflow_geometry() {
        let clip = Rect::new(10., 10., 20., 20.);
        let mut stack = StackView::new(Stack {
            axis: Axis::Horizontal,
            gap: 4.,
        });
        let l = stack
            .render(Rect::new(0., 0., 100., 30.), 2, Some(clip))
            .clone();
        assert_eq!(l.items[0].frame(), Rect::new(0., 0., 48., 30.));
        assert_eq!(
            l.items[0].visible_frame(),
            Some(Rect::new(10., 10., 20., 20.))
        );
        let mut grid = GridView::new(Grid::new(2));
        assert_eq!(
            grid.render(Rect::new(0., 0., 80., 80.), 3, 20., None)
                .items
                .len(),
            3
        );
        assert!(
            stack
                .render(Rect::new(f32::MAX, 0., f32::MAX, 30.), 2, None)
                .items
                .is_empty()
        );
        assert!(
            grid.render(
                Rect::new(0., 0., 80., 80.),
                3,
                20.,
                Some(Rect::new(f32::MAX, 0., f32::MAX, 20.))
            )
            .visible
            .is_none()
        );
    }

    #[test]
    fn disclosure_space_down_is_consumed_and_release_toggles_once() {
        let mut view = DisclosureView::default();
        let mut model = Disclosure::default();
        view.focus(true);
        let down = view.key_event(ControlKey::Space, true, &mut model);
        assert!(down.consumed);
        assert!(!down.changed);
        assert!(!model.open);
        let up = view.key_event(ControlKey::Space, false, &mut model);
        assert!(up.consumed);
        assert!(up.changed);
        assert!(model.open);
        assert!(!view.key_event(ControlKey::Space, false, &mut model).changed);
    }

    #[test]
    fn combo_box_preserves_closed_open_and_disabled_model_semantics() {
        let mut view = ComboBoxView::default();
        let mut model = ComboBox {
            items: vec!["A".into(), "B".into()],
            active: Some(0),
            ..Default::default()
        };
        let opened = view.key_event(ControlKey::Enter, true, &mut model);
        assert!(opened.consumed && opened.changed);
        assert!(model.open);
        assert_eq!(model.selected, None);
        model.disabled = true;
        let before = (
            model.open,
            model.active,
            model.selected,
            model.query.clone(),
        );
        assert!(!view.key_event(ControlKey::Enter, true, &mut model).consumed);
        assert_eq!(
            before,
            (model.open, model.active, model.selected, model.query)
        );
    }

    #[test]
    fn combo_box_keys_use_live_query_without_an_intervening_render() {
        let mut view = ComboBoxView::default();
        let mut model = ComboBox {
            items: vec!["Automatic".into(), "Compact".into(), "Comfortable".into()],
            ..Default::default()
        };
        model.set_query("Com");

        let down = view.key_event(ControlKey::Down, true, &mut model);
        assert!(down.consumed);
        assert_eq!(model.active, Some(2));
        let enter = view.key_event(ControlKey::Enter, true, &mut model);
        assert!(enter.consumed && enter.changed);
        assert_eq!(model.selected, Some(2));
        assert_eq!(model.query, "Comfortable");
        assert!(!model.open);
    }

    #[test]
    fn command_palette_keys_use_live_query_without_an_intervening_render() {
        let mut view = CommandPaletteView::default();
        let mut model = CommandPalette {
            combo: ComboBox {
                items: vec!["Automatic".into(), "Compact".into(), "Comfortable".into()],
                ..Default::default()
            },
        };
        model.open();
        model.combo.set_query("Com");

        let down = view.key_event(ControlKey::Down, true, &mut model);
        assert!(down.consumed);
        assert_eq!(model.combo.active, Some(2));
        let enter = view.key_event(ControlKey::Enter, true, &mut model);
        assert!(enter.consumed && enter.changed);
        assert_eq!(model.combo.selected, Some(2));
        assert_eq!(model.combo.query, "Comfortable");
        assert!(!model.combo.open);
    }

    #[test]
    fn select_keeps_menu_cursor_across_render_close_and_reopen() {
        let mut view = SelectView::new(3);
        let mut model = crate::Select::new(3);
        let labels = ["One", "Two", "Three"];
        let mut scene = Scene::default();
        let mut text = FixedText;
        let palette = Palette::from(Theme::LIGHT);
        let frame = Rect::new(20., 20., 180., 40.);
        let viewport = Rect::new(0., 0., 240., 220.);
        view.render(
            &mut scene,
            &mut text,
            &mut model,
            &labels,
            frame,
            viewport,
            None,
            palette,
            proposal::TextRole::UiBody,
            false,
        );
        view.focus(true);
        assert_eq!(
            view.key(ControlKey::Enter, true, &mut model),
            MenuEvent::None
        );
        let _ = view.key(ControlKey::Enter, false, &mut model);
        view.render(
            &mut scene,
            &mut text,
            &mut model,
            &labels,
            frame,
            viewport,
            None,
            palette,
            proposal::TextRole::UiBody,
            false,
        );
        let _ = view.key(ControlKey::Down, true, &mut model);
        assert_eq!(model.menu.items.selected, 1, "navigation before render");
        let _ = view.key(ControlKey::Down, false, &mut model);
        view.render(
            &mut scene,
            &mut text,
            &mut model,
            &labels,
            frame,
            viewport,
            None,
            palette,
            proposal::TextRole::UiBody,
            false,
        );
        assert_eq!(model.menu.items.selected, 1, "navigation after render");
        assert_eq!(
            view.key(ControlKey::Enter, true, &mut model),
            MenuEvent::Activated {
                index: 1,
                restore_focus: Some(0)
            }
        );
        assert_eq!(model.selected, 1);
        let _ = view.key(ControlKey::Enter, false, &mut model);
        view.render(
            &mut scene,
            &mut text,
            &mut model,
            &labels,
            frame,
            viewport,
            None,
            palette,
            proposal::TextRole::UiBody,
            false,
        );
        let _ = view.key(ControlKey::Enter, true, &mut model);
        assert!(model.menu.open, "menu reopens after prior selection");
        let _ = view.key(ControlKey::Enter, false, &mut model);
        view.render(
            &mut scene,
            &mut text,
            &mut model,
            &labels,
            frame,
            viewport,
            None,
            palette,
            proposal::TextRole::UiBody,
            false,
        );
        let _ = view.key(ControlKey::Down, true, &mut model);
        assert_eq!(
            model.menu.items.selected, 2,
            "reopened navigation before render"
        );
        let _ = view.key(ControlKey::Down, false, &mut model);
        view.render(
            &mut scene,
            &mut text,
            &mut model,
            &labels,
            frame,
            viewport,
            None,
            palette,
            proposal::TextRole::UiBody,
            false,
        );
        assert_eq!(
            model.menu.items.selected, 2,
            "reopened navigation after render"
        );
        assert_eq!(
            view.key(ControlKey::Enter, true, &mut model),
            MenuEvent::Activated {
                index: 2,
                restore_focus: Some(0)
            }
        );
        assert_eq!(model.selected, 2);
        let _ = view.key(ControlKey::Enter, false, &mut model);
    }

    #[test]
    fn select_pointer_release_requires_a_matching_down_and_outside_down_dismisses() {
        let mut view = SelectView::new(3);
        let mut model = crate::Select::new(3);
        let labels = ["One", "Two", "Three"];
        let mut scene = Scene::default();
        let mut text = FixedText;
        let palette = Palette::from(Theme::LIGHT);
        let frame = Rect::new(20., 20., 180., 40.);
        let viewport = Rect::new(0., 0., 240., 220.);
        view.render(
            &mut scene,
            &mut text,
            &mut model,
            &labels,
            frame,
            viewport,
            None,
            palette,
            proposal::TextRole::UiBody,
            false,
        );
        view.focus(true);
        let _ = view.key(ControlKey::Enter, true, &mut model);
        let _ = view.key(ControlKey::Enter, false, &mut model);
        let layout = view.render(
            &mut scene,
            &mut text,
            &mut model,
            &labels,
            frame,
            viewport,
            None,
            palette,
            proposal::TextRole::UiBody,
            false,
        );
        let item = layout.popup.as_ref().unwrap().items[1].frame.center();

        assert_eq!(view.pointer_up(item, &mut model), MenuEvent::None);
        assert!(model.menu.open, "an unpaired release must not dismiss");
        assert_eq!(model.selected, 0);

        let _ = view.pointer_down(item, &mut model);
        let outside = Point::new(230., 210.);
        view.pointer_move(outside, &mut model);
        assert_eq!(view.pointer_up(outside, &mut model), MenuEvent::None);
        assert!(model.menu.open, "dragging out does not commit or dismiss");
        assert_eq!(model.selected, 0);

        let _ = view.pointer_down(item, &mut model);
        assert!(matches!(
            view.pointer_up(item, &mut model),
            MenuEvent::Activated { index: 1, .. }
        ));
        assert_eq!(model.selected, 1);
        assert!(!model.menu.open);

        view.render(
            &mut scene,
            &mut text,
            &mut model,
            &labels,
            frame,
            viewport,
            None,
            palette,
            proposal::TextRole::UiBody,
            false,
        );
        let _ = view.key(ControlKey::Enter, true, &mut model);
        let _ = view.key(ControlKey::Enter, false, &mut model);
        assert!(
            model.menu.open,
            "selection can reopen after pointer capture"
        );
        let _ = view.pointer_down(outside, &mut model);
        assert!(!model.menu.open, "outside pointer-down dismisses the menu");
    }

    #[test]
    fn select_render_does_not_reactivate_an_inactive_menu_runtime() {
        let mut view = SelectView::new(2);
        let mut model = crate::Select::new(2);
        let labels = ["One", "Two"];
        let mut scene = Scene::default();
        let mut text = FixedText;
        let palette = Palette::from(Theme::LIGHT);
        let frame = Rect::new(20., 20., 180., 40.);
        let viewport = Rect::new(0., 0., 240., 220.);
        view.set_window_active(false, &mut model);
        model.menu.open = true;
        let _ = view.render(
            &mut scene,
            &mut text,
            &mut model,
            &labels,
            frame,
            viewport,
            None,
            palette,
            proposal::TextRole::UiBody,
            false,
        );
        assert_eq!(
            view.key(ControlKey::Down, true, &mut model),
            MenuEvent::None
        );
        assert!(!model.menu.open, "inactive rendering cancels the menu");
    }

    #[test]
    fn link_hidden_by_clip_cancels_old_pointer_arm() {
        let mut view = LinkView::default();
        let mut model = Link::default();
        let mut scene = Scene::default();
        let mut text = FixedText;
        let palette = Palette::from(Theme::LIGHT);
        let frame = Rect::new(0., 0., 120., 32.);
        view.render(
            &mut scene,
            &mut text,
            &mut model,
            "Open",
            frame,
            None,
            palette,
            proposal::TextRole::UiBody,
        );
        assert!(view.pointer_down(Point::new(20., 16.)));
        view.render(
            &mut scene,
            &mut text,
            &mut model,
            "Open",
            frame,
            Some(Rect::new(300., 300., 30., 30.)),
            palette,
            proposal::TextRole::UiBody,
        );
        view.render(
            &mut scene,
            &mut text,
            &mut model,
            "Open",
            frame,
            None,
            palette,
            proposal::TextRole::UiBody,
        );
        assert!(!view.pointer_up(Point::new(20., 16.), &mut model));
    }

    #[test]
    fn link_needs_down_and_cancels_when_released_outside() {
        let mut view = LinkView::default();
        let mut model = Link::default();
        let mut scene = Scene::default();
        let mut text = FixedText;
        let palette = Palette::from(Theme::LIGHT);
        let frame = Rect::new(0., 0., 120., 32.);
        view.render(
            &mut scene,
            &mut text,
            &mut model,
            "Open",
            frame,
            None,
            palette,
            proposal::TextRole::UiBody,
        );
        view.pointer_move(Point::new(20., 16.));
        assert!(!view.pointer_up(Point::new(20., 16.), &mut model));
        assert!(view.pointer_down(Point::new(20., 16.)));
        view.pointer_move(Point::new(200., 16.));
        assert!(!view.pointer_up(Point::new(200., 16.), &mut model));
    }

    #[test]
    fn segmented_space_is_consumed_and_selects_once_on_release() {
        let mut view = SegmentedControlView::new(2);
        let mut model = SegmentedControl::new(2);
        view.focus_with_visibility(1, true);
        let down = view.key_event(ControlKey::Space, true, &mut model);
        assert!(down.consumed);
        assert!(!down.changed);
        let up = view.key_event(ControlKey::Space, false, &mut model);
        assert!(up.consumed);
        assert!(up.changed);
        assert_eq!(model.selected, 1);
        assert!(!view.key_event(ControlKey::Space, false, &mut model).changed);
    }

    #[test]
    fn split_view_runtime_cancels_drag_when_window_deactivates_or_hidden() {
        let mut v = SplitViewView::new(Axis::Horizontal);
        let mut model = SplitView::new(0.5);
        v.render(
            &mut Scene::default(),
            &mut model,
            Rect::new(0., 0., 200., 100.),
            None,
            Palette::from(Theme::LIGHT),
        );
        assert!(v.pointer_down(Point::new(100., 50.), &mut model));
        v.render(
            &mut Scene::default(),
            &mut model,
            Rect::new(0., 0., 200., 100.),
            Some(Rect::new(300., 300., 10., 10.)),
            Palette::from(Theme::LIGHT),
        );
        assert!(!v.pointer_move(Point::new(140., 50.), &mut model));
        v.set_window_active(false, &mut model);
        assert!(!v.pointer_move(Point::new(140., 50.), &mut model));
    }
}
