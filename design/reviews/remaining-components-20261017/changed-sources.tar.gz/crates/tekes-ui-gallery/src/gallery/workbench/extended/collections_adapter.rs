//! Gallery adapters for the collection and document components.
//!
//! The Gallery supplies deterministic example data and the available viewport.
//! Component geometry, clipping, paint and input remain in the production views.
use super::super::{Entry, PageCtx, StoryState, line};
use super::{ExtendedStory, controls};
use tekes_ui_controls::{
    ControlKey,
    collections_view::{
        ChartView, CodeBlockView, CollectionEvent, DataTableView, DiffViewRuntime, ListView,
        MarkdownView, TreeView,
    },
};
use tekes_ui_scene::{Point, Rect, Scene};
use tekes_ui_tokens::Palette;

/// Whether an input reached the component and whether it changed the model.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(super) struct InputResult {
    pub consumed: bool,
    pub changed: bool,
}

/// One runtime per existing component model. Gallery fixtures stay on
/// `ExtendedStory`; this struct contains only presentation and interaction state.
#[derive(Debug, Default)]
pub(super) struct CollectionsViews {
    pub list: ListView,
    pub tree: TreeView,
    pub table: DataTableView,
    pub chart: ChartView,
    pub markdown: MarkdownView,
    pub code: CodeBlockView,
    pub diff: DiffViewRuntime,
}

pub(super) fn is_collection(renderer: &str) -> bool {
    matches!(
        renderer,
        "list" | "tree" | "data-table" | "chart" | "markdown" | "code-block" | "diff-view"
    )
}

/// Render one of the registered collection/document stories with its real
/// production view. Returns false for renderers owned by another adapter.
#[allow(clippy::too_many_arguments)]
pub(super) fn build(
    ext: &mut ExtendedStory,
    entry: &Entry,
    state: &mut StoryState,
    ctx: &mut PageCtx<'_>,
    scene: &mut Scene,
    body: Rect,
    clip: Rect,
    palette: Palette,
) -> bool {
    let renderer = entry.renderer();
    if !is_collection(renderer) {
        return false;
    }
    let clip = body
        .intersection(&clip)
        .unwrap_or(Rect::new(body.min_x(), body.min_y(), 0.0, 0.0));
    state.hits.retain(|(id, _)| !component_id(renderer, *id));
    let text_scale = ctx.text.type_scale();
    let x = body.min_x();
    let y = body.min_y();
    let width = body.size.width.max(0.0);

    match renderer {
        "list" => {
            let labels = ["Overview", "Documents", "Images", "Archive", "Trash"]
                .into_iter()
                .map(str::to_owned)
                .collect::<Vec<_>>();
            let frame = Rect::new(x, y, width.min(360.0), body.size.height.max(0.0));
            let layout = ext.collections_views.list.render_scaled(
                scene,
                ctx.text,
                &ext.list,
                &labels,
                frame,
                Some(clip),
                palette,
                text_scale,
            );
            ext.rows = layout.items.iter().map(|item| item.frame).collect();
            for item in layout.items {
                push_hit(state, 30 + item.id, item.visible);
            }
            line(
                ctx,
                scene,
                Rect::new(x, y + 212.0, width, 26.0),
                "Single selection. Up / Down move; Home / End jump to first / last.",
            );
        }
        "tree" => {
            let frame = Rect::new(x, y, width.min(420.0), body.size.height.max(0.0));
            let layout = ext.collections_views.tree.render(
                scene,
                ctx.text,
                &ext.tree,
                frame,
                Some(clip),
                palette,
            );
            ext.rows = layout.items.iter().map(|item| item.frame).collect();
            for item in layout.items {
                push_hit(state, 30 + item.id, item.visible);
            }
            line(
                ctx,
                scene,
                Rect::new(x, y + 128.0, width, 28.0),
                "Right expands; Left collapses or moves to the parent. Up / Down navigate visible rows.",
            );
        }
        "data-table" => {
            let headers = ["Name", "Kind", "Updated"]
                .into_iter()
                .map(str::to_owned)
                .collect::<Vec<_>>();
            let names = ["Project", "Notes", "Assets", "Archive", "Readme"];
            let kinds = ["Folder", "Text", "Image", "Folder", "Text"];
            let updated = ["Today", "Yesterday", "Monday", "Friday", "Tuesday"];
            let rows = (0..ext.table.rows.min(names.len()))
                .map(|row| {
                    vec![
                        format!("{} {}", names[row], row + 1),
                        kinds[row].to_owned(),
                        updated[row].to_owned(),
                    ]
                })
                .collect::<Vec<_>>();
            let mut order = (0..rows.len()).collect::<Vec<_>>();
            if let Some((column, direction)) = ext.table.sort {
                order.sort_by(|left, right| rows[*left].get(column).cmp(&rows[*right].get(column)));
                if direction == controls::SortDirection::Descending {
                    order.reverse();
                }
            }
            ext.visible_rows = order.clone();
            let frame = Rect::new(x, y, width.min(720.0), body.size.height.max(0.0));
            let layout = ext.collections_views.table.render(
                scene,
                ctx.text,
                &ext.table,
                &headers,
                &rows,
                &order,
                frame,
                Some(clip),
                palette,
            );
            ext.rows = layout.rows.iter().map(|item| item.frame).collect();
            for header in layout.headers {
                push_hit(state, 20 + header.id, header.visible);
            }
            for row in layout.rows {
                push_hit(state, 30 + row.id, row.visible);
            }
        }
        "chart" => {
            let frame = Rect::new(
                x,
                y + 8.0,
                width.min(760.0),
                (body.size.height - 36.0).max(0.0),
            );
            let layout = ext.collections_views.chart.render(
                scene,
                ctx.text,
                &mut ext.chart,
                frame,
                Some(clip),
                palette,
                text_scale,
            );
            for bar in &layout.geometry.bars {
                let rect = bar.rect.inset(-6.0);
                push_hit(state, 30 + bar.index, rect.intersection(&clip));
            }
            let invalid_count = ext
                .chart
                .data()
                .iter()
                .filter(|datum| !datum.value.is_finite())
                .count();
            if invalid_count > 0 {
                line(
                    ctx,
                    scene,
                    Rect::new(x, frame.max_y() + 4.0, width, 22.0),
                    &format!("{invalid_count} non-finite values omitted"),
                );
            }
        }
        "markdown" => {
            let frame = Rect::new(x, y, width, body.size.height.max(0.0));
            let layout = ext.collections_views.markdown.render(
                scene,
                ctx.text,
                &ext.markdown,
                frame,
                Some(clip),
                palette,
                text_scale,
            );
            let note_y = (body.max_y() - 28.0).max(frame.min_y() + layout.content_height + 12.0);
            line(
                ctx,
                scene,
                Rect::new(x, note_y, width, 24.0),
                "Supported subset: headings, paragraphs, bullets and fenced code.",
            );
        }
        "code-block" => {
            let frame = Rect::new(
                x,
                y + 8.0,
                width.min(680.0),
                (body.size.height - 18.0).max(80.0),
            );
            ext.collections_views.code.render(
                scene,
                ctx.text,
                &ext.code,
                frame,
                Some(clip),
                palette,
                text_scale,
            );
            line(
                ctx,
                scene,
                Rect::new(x + 14.0, (body.max_y() - 34.0).max(y + 90.0), width, 24.0),
                "Plain light surface; syntax coloring and editing are not part of this component.",
            );
        }
        "diff-view" => {
            let frame = Rect::new(x, y, width.min(700.0), (body.size.height - 42.0).max(0.0));
            let layout = ext.collections_views.diff.render(
                scene,
                ctx.text,
                &ext.diff,
                frame,
                Some(clip),
                palette,
                text_scale,
            );
            line(
                ctx,
                scene,
                Rect::new(
                    x,
                    (frame.min_y() + layout.content_height + 12.0 + 2.0 * text_scale)
                        .min(body.max_y() - 24.0),
                    width,
                    24.0,
                ),
                "Deterministic line-based LCS fixture; large inputs fall back to delete/add blocks.",
            );
        }
        _ => return false,
    }
    true
}

fn component_id(renderer: &str, id: usize) -> bool {
    match renderer {
        "list" => (30..35).contains(&id),
        "tree" => (30..usize::MAX).contains(&id),
        "data-table" => (20..23).contains(&id) || (30..35).contains(&id),
        "chart" => (30..34).contains(&id),
        _ => false,
    }
}
fn push_hit(state: &mut StoryState, id: usize, rect: Option<Rect>) {
    if let Some(rect) = rect.filter(|rect| rect.size.width > 0.0 && rect.size.height > 0.0) {
        state.hits.push((id, rect));
    }
}
fn result(
    event: CollectionEvent,
    renderer: &str,
    log: &mut impl FnMut(String),
) -> Option<InputResult> {
    let (changed, message) = match event {
        CollectionEvent::Ignored => return None,
        CollectionEvent::Handled => (false, None),
        CollectionEvent::Changed => (true, None),
        CollectionEvent::Activated(index) => {
            (false, Some(format!("{renderer}: activated {index}")))
        }
        CollectionEvent::Toggled(index) => (true, Some(format!("tree node: {index}"))),
    };
    if let Some(message) = message {
        log(message);
    }
    Some(InputResult {
        consumed: true,
        changed,
    })
}

pub(super) fn accepts_key(renderer: &str, focus: Option<usize>) -> bool {
    let Some(id) = focus else {
        return false;
    };
    match renderer {
        "list" => (30..35).contains(&id),
        "tree" => id >= 30,
        "data-table" => (20..23).contains(&id) || (30..35).contains(&id),
        "chart" => (30..34).contains(&id),
        _ => false,
    }
}

pub(super) fn activate(
    ext: &mut ExtendedStory,
    renderer: &str,
    id: usize,
    log: &mut impl FnMut(String),
) -> Option<InputResult> {
    match (renderer, id) {
        ("list", 30..=34) => result(
            ext.collections_views
                .list
                .key(ControlKey::Enter, true, &mut ext.list),
            renderer,
            log,
        ),
        ("tree", id) if id >= 30 => result(
            ext.collections_views
                .tree
                .key(ControlKey::Enter, true, &mut ext.tree),
            renderer,
            log,
        ),
        ("data-table", id) if (30..35).contains(&id) || (20..23).contains(&id) => result(
            ext.collections_views
                .table
                .key(ControlKey::Enter, true, &mut ext.table),
            renderer,
            log,
        ),
        ("chart", 30..=33) => Some(InputResult {
            consumed: true,
            changed: false,
        }),
        _ => None,
    }
}

pub(super) fn key(
    ext: &mut ExtendedStory,
    renderer: &str,
    focus: Option<usize>,
    key: ControlKey,
    down: bool,
    log: &mut impl FnMut(String),
) -> Option<InputResult> {
    if !is_collection(renderer) || !accepts_key(renderer, focus) {
        return None;
    }
    let event = match renderer {
        "list" => ext.collections_views.list.key(key, down, &mut ext.list),
        "tree" => {
            let id = focus?.saturating_sub(30);
            if !ext.tree.visible().contains(&id)
                || ext.tree.nodes().get(id).is_none_or(|node| node.disabled)
            {
                return Some(InputResult {
                    consumed: true,
                    changed: false,
                });
            }
            ext.collections_views.tree.key(key, down, &mut ext.tree)
        }
        "data-table" => ext.collections_views.table.key(key, down, &mut ext.table),
        "chart" => ext.collections_views.chart.key(key, down, &mut ext.chart),
        _ => return None,
    };
    let result = result(event, renderer, log);
    if result.is_some_and(|r| r.changed) {
        match renderer {
            "list" => {
                ext.selected = ext.list.selected.unwrap_or_default();
                ext.focused = ext.list.selected.map(|index| 30 + index);
            }
            "tree" => {
                ext.selected = ext.tree.selected.unwrap_or_default();
                ext.focused = ext.tree.selected.map(|index| 30 + index);
            }
            "data-table" => {
                ext.selected = ext.table.selected_row.unwrap_or_default();
                if focus.is_some_and(|id| (20..23).contains(&id))
                    && matches!(key, ControlKey::Left | ControlKey::Right)
                {
                    let column = focus.unwrap_or(20).saturating_sub(20);
                    let next = if key == ControlKey::Right {
                        (column + 1).min(ext.table.columns.saturating_sub(1))
                    } else {
                        column.saturating_sub(1)
                    };
                    ext.focused = Some(20 + next);
                } else {
                    ext.focused = ext.table.selected_row.map(|index| 30 + index);
                }
            }
            "chart" => {
                ext.selected = ext.chart.selected().unwrap_or_default();
                ext.focused = ext.chart.selected().map(|index| 30 + index);
            }
            _ => {}
        }
        log(format!("{renderer}: keyboard state changed"));
    }
    result
}

pub(super) fn pointer_move(
    ext: &mut ExtendedStory,
    renderer: &str,
    point: Point,
    _hit: Option<usize>,
    _log: &mut impl FnMut(String),
) -> Option<InputResult> {
    let changed = match renderer {
        "list" => ext.collections_views.list.pointer_move(point),
        "tree" => ext.collections_views.tree.pointer_move(point),
        "data-table" => ext.collections_views.table.pointer_move(point),
        "chart" => ext
            .collections_views
            .chart
            .pointer_move(point, &mut ext.chart),
        _ => return None,
    };
    Some(InputResult {
        consumed: true,
        changed,
    })
}

pub(super) fn pointer_down(
    ext: &mut ExtendedStory,
    renderer: &str,
    point: Point,
    _id: Option<usize>,
    log: &mut impl FnMut(String),
) -> Option<InputResult> {
    let event = match renderer {
        "list" => ext
            .collections_views
            .list
            .pointer_down(point, &mut ext.list),
        "tree" => ext
            .collections_views
            .tree
            .pointer_down(point, &mut ext.tree),
        "data-table" => ext
            .collections_views
            .table
            .pointer_down(point, &mut ext.table),
        "chart" => ext
            .collections_views
            .chart
            .pointer_down(point, &mut ext.chart),
        _ => return None,
    };
    let result = result(event, renderer, log);
    if result.is_some() {
        ext.focused = _id;
    }
    if result.is_some_and(|r| r.changed) {
        match renderer {
            "list" => ext.selected = ext.list.selected.unwrap_or_default(),
            "tree" => ext.selected = ext.tree.selected.unwrap_or_default(),
            "data-table" => ext.selected = ext.table.selected_row.unwrap_or_default(),
            "chart" => ext.selected = ext.chart.selected().unwrap_or_default(),
            _ => {}
        }
        if !matches!(renderer, "tree") {
            log(format!("{renderer}: selection changed"));
        }
    }
    result
}

pub(super) fn pointer_up(
    ext: &mut ExtendedStory,
    renderer: &str,
    point: Point,
    _hit: Option<usize>,
    log: &mut impl FnMut(String),
) -> Option<InputResult> {
    let event = match renderer {
        "list" => ext.collections_views.list.pointer_up(point, &mut ext.list),
        "tree" => ext.collections_views.tree.pointer_up(point, &mut ext.tree),
        "data-table" => ext
            .collections_views
            .table
            .pointer_up(point, &mut ext.table),
        "chart" => {
            return Some(InputResult {
                consumed: true,
                changed: false,
            });
        }
        _ => return None,
    };
    let result = result(event, renderer, log);
    if result.is_some_and(|r| r.changed) {
        match renderer {
            "list" => ext.selected = ext.list.selected.unwrap_or_default(),
            "tree" => ext.selected = ext.tree.selected.unwrap_or_default(),
            "data-table" => ext.selected = ext.table.selected_row.unwrap_or_default(),
            _ => {}
        }
    }
    result
}

pub(super) fn focus_changed(
    ext: &mut ExtendedStory,
    renderer: &str,
    focus: Option<usize>,
    keyboard: bool,
) {
    match renderer {
        "list" => {
            if let Some(index) = focus
                .and_then(|id| id.checked_sub(30))
                .filter(|i| *i < ext.list.count)
            {
                ext.collections_views.list.focus(index, keyboard);
            } else {
                ext.collections_views.list.blur();
            }
        }
        "tree" => {
            if let Some(index) = focus.and_then(|id| id.checked_sub(30)).filter(|i| {
                ext.tree.visible().contains(i)
                    && ext.tree.nodes().get(*i).is_some_and(|node| !node.disabled)
            }) {
                ext.collections_views.tree.focus(index, keyboard);
            } else {
                ext.collections_views.tree.blur();
            }
        }
        "data-table" => match focus {
            Some(id @ 20..=22) => ext.collections_views.table.focus_header(id - 20, keyboard),
            Some(id @ 30..=34) if id - 30 < ext.table.rows => {
                ext.collections_views.table.focus_row(id - 30, keyboard)
            }
            _ => ext.collections_views.table.blur(),
        },
        "chart" => {
            if focus.is_some_and(|id| (30..34).contains(&id)) {
                ext.collections_views.chart.focus(keyboard, &mut ext.chart);
            } else {
                ext.collections_views.chart.blur(&mut ext.chart);
            }
        }
        _ => {}
    }
}

pub(super) fn blur(ext: &mut ExtendedStory, renderer: &str) {
    focus_changed(ext, renderer, None, false);
}
pub(super) fn window_active(ext: &mut ExtendedStory, renderer: &str, active: bool) {
    match renderer {
        "list" => ext.collections_views.list.set_window_active(active),
        "tree" => ext.collections_views.tree.set_window_active(active),
        "data-table" => ext.collections_views.table.set_window_active(active),
        "chart" => ext
            .collections_views
            .chart
            .set_window_active(active, &mut ext.chart),
        _ => {}
    }
}
