//! Gallery stories for the additional production control models.
//!
//! The story owns deterministic fixtures and scene placement. Interaction semantics
//! are delegated to `tekes_ui_controls::extended` models.
use super::super::pages::showcase::{Icon, draw_icon};
use super::{Entry, PageCtx, StoryState, action, event_log, label, line, quiet_action};
use tekes_ui_controls::{
    BarChart, ChartDatum, ControlKey, ControlState, RadioGroupView, SelectionEvent, SliderView,
    SwitchView, extended as controls, paint, paint_bar_chart_with_text_scale,
};
use tekes_ui_scene::{Point, Rect, Scene};
use tekes_ui_tokens::{ColorRole, Palette, proposal};

fn centered_label(
    ctx: &mut PageCtx<'_>,
    scene: &mut Scene,
    slot: Rect,
    text: &str,
    role: proposal::TextRole,
    color: tekes_ui_tokens::Rgba,
) {
    ctx.text
        .proposal_label_in(scene, ctx.theme, slot, text, role, color);
}

pub(super) fn supports(renderer: &str) -> bool {
    matches!(
        renderer,
        "stack"
            | "grid"
            | "separator"
            | "disclosure"
            | "split-view"
            | "icon-button"
            | "link"
            | "combo-box"
            | "slider"
            | "radio-group"
            | "switch"
            | "segmented-control"
            | "breadcrumb"
            | "command-palette"
            | "list"
            | "tree"
            | "data-table"
            | "chart"
            | "tooltip"
            | "popover"
            | "toast"
            | "banner"
            | "status-badge"
            | "progress"
            | "empty-state"
            | "markdown"
            | "code-block"
            | "diff-view"
    )
}
pub(super) fn supports_disabled(renderer: &str) -> bool {
    matches!(
        renderer,
        "disclosure"
            | "icon-button"
            | "link"
            | "combo-box"
            | "slider"
            | "radio-group"
            | "switch"
            | "segmented-control"
    )
}
pub(super) fn supports_story(renderer: &str, story: &str) -> bool {
    match story {
        "states" => matches!(
            renderer,
            "disclosure" | "icon-button" | "link" | "slider" | "radio-group" | "switch"
        ),
        "behaviors" => matches!(
            renderer,
            "disclosure"
                | "split-view"
                | "icon-button"
                | "link"
                | "combo-box"
                | "slider"
                | "radio-group"
                | "switch"
                | "segmented-control"
                | "breadcrumb"
                | "command-palette"
                | "list"
                | "tree"
                | "data-table"
                | "chart"
                | "tooltip"
                | "popover"
                | "toast"
                | "banner"
                | "progress"
        ),
        "variants" => matches!(renderer, "stack" | "grid" | "separator" | "split-view"),
        _ => false,
    }
}

/// Only route component-owned keys into the production model. In particular,
/// focus on the Docs/Reset tabs or the native text input must never mutate a
/// nearby story control.
pub(super) fn handles_key(
    renderer: &str,
    key: ControlKey,
    focus: Option<usize>,
    s: &ExtendedStory,
) -> bool {
    if matches!(renderer, "combo-box" | "command-palette") {
        let (open, has_candidates) = if renderer == "combo-box" {
            (s.combo.open, !s.combo.filtered().is_empty())
        } else {
            (s.command.combo.open, !s.command.combo.filtered().is_empty())
        };
        let list_key = matches!(key, ControlKey::Up | ControlKey::Down | ControlKey::Enter);
        return focus == Some(1000)
            && (key == ControlKey::Escape && open || list_key && has_candidates);
    }
    match renderer {
        "popover" => s.popover.open && (focus == Some(20) || key == ControlKey::Escape),
        "tooltip" => (focus == Some(20) || s.hovered == Some(20)) && key == ControlKey::Escape,
        "slider" | "disclosure" | "switch" | "icon-button" | "link" => focus == Some(20),
        "split-view" => focus == Some(90),
        "radio-group" => focus.is_some_and(|id| (30..33).contains(&id)),
        "segmented-control" => focus.is_some_and(|id| (30..33).contains(&id)),
        "breadcrumb" => focus.is_some_and(|id| (30..33).contains(&id)),
        "list" => focus.is_some_and(|id| (30..35).contains(&id)),
        "tree" => focus.is_some_and(|id| (30..33).contains(&id)),
        "data-table" => focus.is_some_and(|id| (30..35).contains(&id) || (20..23).contains(&id)),
        "chart" => focus.is_some_and(|id| (30..34).contains(&id)),
        _ => false,
    }
}

#[derive(Debug)]
pub(super) struct ExtendedStory {
    pub stack: controls::Stack,
    pub grid: controls::Grid,
    pub disclosure: controls::Disclosure,
    pub split: controls::SplitView,
    pub split_bounds: Rect,
    pub pointer_dragging: Option<usize>,
    pub icon_button: controls::IconButton,
    pub link: controls::Link,
    pub slider: controls::Slider,
    pub slider_view: SliderView,
    pub radio: controls::RadioGroup,
    pub radio_view: RadioGroupView,
    pub switch: controls::Switch,
    pub switch_view: SwitchView,
    pub segmented: controls::SegmentedControl,
    pub breadcrumb: controls::Breadcrumb,
    pub command: controls::CommandPalette,
    pub combo: controls::ComboBox,
    pub list: controls::List,
    pub tree: controls::Tree,
    pub table: controls::DataTable,
    pub chart: BarChart,
    pub tooltip: controls::Tooltip,
    pub popover: controls::Popover,
    pub banner: controls::Banner,
    pub toast: controls::Toast,
    pub progress: controls::Progress,
    pub markdown: controls::Markdown,
    pub code: controls::CodeBlock,
    pub diff: controls::DiffView,
    pub disabled: bool,
    pub hovered: Option<usize>,
    pub focused: Option<usize>,
    pub tooltip_dismissed: bool,
    pub visible_rows: Vec<usize>,
    pub hits: Vec<(usize, Rect)>,
    pub rows: Vec<Rect>,
    pub query: String,
    pub selected: usize,
    pub empty_state_created: bool,
}

impl Default for ExtendedStory {
    fn default() -> Self {
        let mut tree = controls::Tree::default();
        let root = tree.add("Workspace", None).unwrap();
        tree.add("Documents", Some(root)).unwrap();
        tree.add("Design system", Some(root)).unwrap();
        tree.toggle(root);
        let mut command = controls::CommandPalette::default();
        command.combo.items = ["Open Settings", "Create workspace", "Search files"]
            .into_iter()
            .map(str::to_owned)
            .collect();
        Self {
            stack: controls::Stack::new(controls::Axis::Horizontal),
            grid: controls::Grid::new(3),
            disclosure: controls::Disclosure::default(),
            split: controls::SplitView::new(0.5),
            split_bounds: Rect::default(),
            pointer_dragging: None,
            icon_button: controls::IconButton::new("Create item").expect("accessible name"),
            link: controls::Link::default(),
            slider: controls::Slider::new(50., 0., 100., 5.).unwrap(),
            slider_view: SliderView::new(),
            radio: controls::RadioGroup::new(3),
            radio_view: RadioGroupView::new(),
            switch: controls::Switch::default(),
            switch_view: SwitchView::new(),
            segmented: controls::SegmentedControl::new(3),
            breadcrumb: controls::Breadcrumb {
                items: ["Workspace", "Documents", "Drafts"]
                    .into_iter()
                    .map(str::to_owned)
                    .collect(),
            },
            command,
            combo: controls::ComboBox {
                items: ["Automatic", "Compact", "Comfortable"]
                    .into_iter()
                    .map(str::to_owned)
                    .collect(),
                ..Default::default()
            },
            list: controls::List::new(5),
            tree,
            table: controls::DataTable::new(5, 3),
            chart: BarChart::new(
                [
                    ChartDatum::new("Plan", 4.0),
                    ChartDatum::new("Build", 7.0),
                    ChartDatum::new("Review", 5.0),
                    ChartDatum::new("Release", 9.0),
                ]
                .into_iter()
                .collect(),
            ),
            tooltip: controls::Tooltip {
                visible: false,
                text: "A deterministic tooltip fixture".into(),
            },
            popover: controls::Popover::default(),
            banner: controls::Banner {
                message: "Your workspace has unsaved changes.".into(),
                tone: controls::NoticeTone::Info,
                dismissible: true,
                visible: true,
            },
            toast: controls::Toast::new("Changes saved", controls::NoticeTone::Success, 5000),
            progress: controls::Progress::new(0.6),
            markdown: controls::Markdown::parse(
                "# Release notes\n\nA readable paragraph describing this deterministic workspace fixture.\n\n- Stable fixtures\n- Token-driven rendering",
            ),
            code: controls::CodeBlock {
                language: "rust".into(),
                source: "let ready = true;\nprintln!(\"{ready}\");".into(),
            },
            diff: controls::DiffView::between(
                "title = \"Gallery\"\nstatus = \"planned\"",
                "title = \"Gallery\"\nstatus = \"experimental\"",
            ),
            disabled: false,
            hovered: None,
            focused: None,
            tooltip_dismissed: false,
            visible_rows: Vec::new(),
            hits: Vec::new(),
            rows: Vec::new(),
            query: String::new(),
            selected: 0,
            empty_state_created: false,
        }
    }
}

impl ExtendedStory {
    pub(super) fn set_window_active(&mut self, active: bool) {
        self.slider_view.set_window_active(active);
        self.radio_view.set_window_active(active);
        self.switch_view.set_window_active(active);
        if !active {
            self.cancel_pointer();
            self.focused = None;
        }
    }
    pub(super) fn blur_selection_controls(&mut self) {
        self.cancel_pointer();
        self.slider_view.blur();
        self.radio_view.blur();
        self.switch_view.blur();
        self.focused = None;
    }

    /// Keep the retained selection runtimes in sync with the host's immediate
    /// focus move, even when a frame has not been rebuilt yet.
    pub(super) fn host_focus_changed(
        &mut self,
        renderer: &str,
        target: usize,
        focus_visible: bool,
    ) {
        match renderer {
            "slider" => {
                if target == 20 && !self.disabled {
                    self.slider_view.focus(focus_visible);
                } else {
                    self.slider_view.blur();
                }
            }
            "switch" => {
                if target == 20 && !self.disabled {
                    self.switch_view.focus(focus_visible);
                } else {
                    self.switch_view.blur();
                }
            }
            "radio-group" => {
                if (30..30 + self.radio.len()).contains(&target) && !self.disabled {
                    self.radio_view
                        .focus(&self.radio, Some(target - 30), focus_visible);
                } else {
                    self.radio_view.blur();
                }
            }
            _ => {}
        }
        self.focused = Some(target);
    }

    pub(super) fn matrix(
        &mut self,
        e: &Entry,
        s: &StoryState,
        ctx: &mut PageCtx<'_>,
        scene: &mut Scene,
        c: Rect,
    ) {
        scene.push_clip(c);
        let x = c.min_x();
        let y = c.min_y();
        let width = c.size.width.max(0.);
        let columns = if width < 520. { 2 } else { 3 };
        let cell_w = (width / columns as f32).max(0.);
        let states: Vec<(&str, ControlState)> = match e.renderer() {
            "switch" | "radio-group" => vec![
                (
                    "Checked · default",
                    ControlState {
                        selected: true,
                        ..Default::default()
                    },
                ),
                (
                    "Checked · hover",
                    ControlState {
                        selected: true,
                        hovered: true,
                        ..Default::default()
                    },
                ),
                (
                    "Checked · pressed",
                    ControlState {
                        selected: true,
                        pressed: true,
                        ..Default::default()
                    },
                ),
                (
                    "Checked · focus-visible",
                    ControlState {
                        selected: true,
                        focused: true,
                        focus_visible: true,
                        ..Default::default()
                    },
                ),
                (
                    "Checked · disabled",
                    ControlState {
                        selected: true,
                        disabled: true,
                        ..Default::default()
                    },
                ),
                ("Unchecked", ControlState::default()),
                (
                    "Unchecked · disabled",
                    ControlState {
                        disabled: true,
                        ..Default::default()
                    },
                ),
            ],
            "slider" => vec![
                ("Default", ControlState::default()),
                (
                    "Hover",
                    ControlState {
                        hovered: true,
                        ..Default::default()
                    },
                ),
                (
                    "Pressed",
                    ControlState {
                        pressed: true,
                        ..Default::default()
                    },
                ),
                (
                    "Focus-visible",
                    ControlState {
                        focused: true,
                        focus_visible: true,
                        ..Default::default()
                    },
                ),
                (
                    "Disabled",
                    ControlState {
                        disabled: true,
                        ..Default::default()
                    },
                ),
            ],
            _ => vec![
                ("Default", ControlState::default()),
                (
                    "Hover",
                    ControlState {
                        hovered: true,
                        ..Default::default()
                    },
                ),
                (
                    "Pressed",
                    ControlState {
                        pressed: true,
                        ..Default::default()
                    },
                ),
                (
                    "Focus-visible",
                    ControlState {
                        focused: true,
                        focus_visible: true,
                        ..Default::default()
                    },
                ),
                (
                    "Disabled",
                    ControlState {
                        disabled: true,
                        ..Default::default()
                    },
                ),
                (
                    "Selected · hover",
                    ControlState {
                        selected: true,
                        hovered: true,
                        ..Default::default()
                    },
                ),
            ],
        };
        line(
            ctx,
            scene,
            Rect::new(x, y, width, 28.),
            "Visual comparison only. Use Playground for real focus and keyboard behavior.",
        );
        for (n, (name, state)) in states.into_iter().enumerate() {
            let col = n % columns;
            let row = n / columns;
            let rect = Rect::new(
                x + col as f32 * cell_w,
                y + 38. + row as f32 * 82.,
                (cell_w - 12.).max(0.),
                62.,
            );
            label(
                ctx,
                scene,
                Rect::new(rect.min_x(), rect.min_y(), rect.size.width, 20.),
                name,
                false,
            );
            let control = Rect::new(
                rect.min_x(),
                rect.min_y() + 24.,
                rect.size.width.min(220.),
                36.,
            );
            let palette = Palette {
                theme: ctx.theme,
                brand: s.brand,
            };
            match e.renderer() {
                "switch" => controls::switch_with_state(
                    scene,
                    Rect::new(control.min_x(), control.min_y() + 5., 48., 26.),
                    palette,
                    state,
                ),
                "radio-group" => controls::radio_with_state(
                    scene,
                    Rect::new(control.min_x(), control.min_y() + 9., 18., 18.),
                    palette,
                    state,
                ),
                "slider" => {
                    let mut slider =
                        controls::Slider::new(50., 0., 100., 5.).expect("valid fixture");
                    slider.disabled = state.disabled;
                    controls::slider(scene, control, palette, slider, state);
                }
                "disclosure" => {
                    paint::button(scene, control, palette, state);
                    label(ctx, scene, control.inset(8.), "Details", false);
                }
                "link" => {
                    let ink = controls::link_underline(scene, control, palette, state);
                    ctx.text.proposal_label_in(
                        scene,
                        ctx.theme,
                        control.inset(8.),
                        "Open documentation",
                        proposal::TextRole::UiBody,
                        ink,
                    );
                }
                "icon-button" => {
                    paint::button(scene, control, palette, state);
                    draw_icon(ctx, scene, control.inset(10.), Icon::Plus);
                }
                _ => {}
            }
        }
        scene.pop_clip();
    }

    pub(super) fn behaviors(
        &mut self,
        e: &Entry,
        ctx: &mut PageCtx<'_>,
        scene: &mut Scene,
        c: Rect,
    ) {
        let text = match e.renderer() {
            "disclosure" => {
                "Enter or Space toggles the disclosure. Collapsed content is not mounted in the fixture."
            }
            "split-view" => {
                "Drag the divider after its 4 pt dead zone. Arrow keys adjust; Home and End set limits. Escape restores the starting ratio. Constrained widths expose master/detail pane selection."
            }
            "icon-button" => {
                "Accessible name: Create item. Enter and Space activate; pointer activation requires press and release on the same control."
            }
            "link" => "Enter follows the link action. Space does not activate a link.",
            "combo-box" => {
                "Type to filter. Arrow keys move the active option, Enter commits, Escape closes. Marked IME composition is passed to the native text input first."
            }
            "slider" => {
                "Left and Right adjust by the declared step; Home and End move to the range bounds. Pointer drag updates the value."
            }
            "radio-group" | "segmented-control" => {
                "Arrow keys move selection; Space selects the focused item. Disabled items are skipped."
            }
            "switch" => "Space toggles the focused value. Disabled state prevents changes.",
            "breadcrumb" => {
                "Activate a crumb to navigate to its ancestor. It does not consume Space as a link activation."
            }
            "command-palette" => {
                "Open the palette, type to filter, use arrow keys to move, Enter to run, and Escape to close."
            }
            "list" => {
                "Single selection. Up and Down move; Home and End select the first and last row."
            }
            "tree" => {
                "Up and Down move among visible rows. Right expands or enters the first child; Left collapses or moves to the parent."
            }
            "data-table" => {
                "Activate a header to sort deterministically. Up and Down move through rows; Enter selects the focused row."
            }
            "chart" => {
                "Arrow keys move the selected data mark. Non-finite values are omitted and are not selectable."
            }
            "tooltip" => {
                "Hover or focus-visible reveals the tooltip. Escape dismisses it until pointer leave or focus changes."
            }
            "popover" => {
                "Activate the trigger, then Escape or click outside. Dismissal restores focus to the invoker."
            }
            "toast" => {
                "Dismiss or advance the deterministic fixture timer by one second. No wall-clock timer is used."
            }
            "banner" => "Dismiss the notice; Reset restores its initial visible state.",
            "progress" => "Advance the value in 10% steps. The value is clamped to 100%.",
            _ => "This component is a static rendering specimen in this release.",
        };
        label(ctx, scene, c, text, false);
    }

    pub(super) fn variants(
        &mut self,
        e: &Entry,
        s: &StoryState,
        ctx: &mut PageCtx<'_>,
        scene: &mut Scene,
        c: Rect,
    ) {
        let palette = Palette {
            theme: ctx.theme,
            brand: s.brand,
        };
        let x = c.min_x();
        let y = c.min_y();
        let w = c.size.width.max(0.);
        match e.renderer() {
            "stack" => {
                for (index, gap) in [0., 8., 16.].into_iter().enumerate() {
                    let row = Rect::new(x, y + index as f32 * 72., w.min(620.), 58.);
                    label(
                        ctx,
                        scene,
                        Rect::new(row.min_x(), row.min_y(), row.size.width, 18.),
                        &format!("Gap: {gap:.0} pt"),
                        false,
                    );
                    self.stack.gap = gap;
                    for cell in self.stack.layout(
                        Rect::new(row.min_x(), row.min_y() + 20., row.size.width, 36.),
                        3,
                    ) {
                        paint::surface(scene, cell, palette, true);
                    }
                }
            }
            "grid" => {
                for (index, cols) in [2, 3, 4].into_iter().enumerate() {
                    let top = y + index as f32 * 82.;
                    label(
                        ctx,
                        scene,
                        Rect::new(x, top, w, 18.),
                        &format!("{cols} columns"),
                        false,
                    );
                    self.grid.columns = cols;
                    for cell in
                        self.grid
                            .layout(Rect::new(x, top + 22., w.min(620.), 58.), cols * 2, 26.)
                    {
                        paint::surface(scene, cell, palette, true);
                    }
                }
            }
            "separator" => {
                label(
                    ctx,
                    scene,
                    Rect::new(x, y, w.min(320.), 28.),
                    "Horizontal",
                    false,
                );
                controls::separator(
                    scene,
                    Rect::new(x, y + 36., w.min(620.), 12.),
                    palette,
                    controls::Axis::Horizontal,
                );
                label(
                    ctx,
                    scene,
                    Rect::new(x, y + 60., w.min(320.), 28.),
                    "Vertical",
                    false,
                );
                controls::separator(
                    scene,
                    Rect::new(x + 340., y + 48., 12., 160.),
                    palette,
                    controls::Axis::Vertical,
                );
            }
            "split-view" => {
                for (index, ratio) in [0.3, 0.5, 0.7].into_iter().enumerate() {
                    let bounds = Rect::new(x, y + index as f32 * 110. + 20., w.min(620.), 78.);
                    label(
                        ctx,
                        scene,
                        Rect::new(x, bounds.min_y() - 20., w, 18.),
                        &format!("Leading {:.0}%", ratio * 100.),
                        false,
                    );
                    self.split.set_ratio(ratio);
                    let (leading, divider, trailing) =
                        self.split.layout(bounds, controls::Axis::Horizontal);
                    paint::surface(scene, leading, palette, true);
                    controls::separator(scene, divider, palette, controls::Axis::Vertical);
                    paint::surface(scene, trailing, palette, true);
                }
            }
            _ => {}
        }
    }

    pub(super) fn activate(
        &mut self,
        renderer: &str,
        id: usize,
        log: &mut impl FnMut(String),
    ) -> bool {
        if self.disabled && !matches!(id, 0 | 10) {
            return false;
        }
        match (renderer, id) {
            (_, 10) => {
                self.disabled = !self.disabled;
                log(format!("disabled: {}", self.disabled));
                true
            }
            ("disclosure", 20) => {
                let changed = self.disclosure.toggle();
                log(format!("disclosure: {}", self.disclosure.open));
                changed
            }
            ("split-view", 91) => {
                self.split.choose_visible(controls::Pane::Leading);
                log("split pane: leading".into());
                true
            }
            ("split-view", 92) => {
                self.split.choose_visible(controls::Pane::Trailing);
                log("split pane: trailing".into());
                true
            }
            ("icon-button", 20) => {
                self.icon_button.button.state.focused = true;
                self.icon_button.pointer_down();
                let changed = self.icon_button.pointer_up(true);
                if changed {
                    log(format!(
                        "icon-button: {}",
                        self.icon_button.accessible_name()
                    ));
                }
                changed
            }
            ("link", 20) => {
                self.link.button.state.focused = true;
                self.link.pointer_down();
                let changed = self.link.pointer_up(true);
                if changed {
                    log("link: activated".into());
                }
                changed
            }
            ("slider", 20) => {
                let changed = self.slider.key(ControlKey::Right);
                if changed {
                    log(format!("value: {}", self.slider.value()));
                }
                changed
            }
            ("radio-group", 30..=32) => {
                let changed = self.radio.select(id - 30);
                if changed {
                    log(format!("radio: {}", id - 30));
                }
                changed
            }
            ("switch", 20) => {
                let changed = self.switch.toggle();
                if changed {
                    log(format!("switch: {}", self.switch.checked));
                }
                changed
            }
            ("segmented-control", 30..=32) => {
                let changed = self.segmented.select(id - 30);
                if changed {
                    log(format!("segment: {}", id - 30));
                }
                changed
            }
            ("breadcrumb", 30..=32) => {
                let target = self.breadcrumb.activate(id - 30);
                if let Some(n) = target {
                    self.selected = n;
                    log(format!("breadcrumb: {n}"));
                    true
                } else {
                    false
                }
            }
            ("command-palette", 20) => {
                self.command.open();
                log("command palette: open".into());
                true
            }
            ("command-palette", 40..=42) => {
                self.command.combo.selected = Some(id - 40);
                self.command.combo.open = false;
                log(format!("command: {}", id - 40));
                true
            }
            ("combo-box", 40..=42) => {
                let i = id - 40;
                self.combo.selected = Some(i);
                self.combo.query = self.combo.items[i].clone();
                self.combo.open = false;
                log(format!("combo selection: {i}"));
                true
            }
            ("list", 30..=34) => {
                let changed = self.list.select(id - 30);
                if changed {
                    self.selected = id - 30;
                    log(format!("list selection: {}", id - 30));
                }
                changed
            }
            ("tree", 30..=32) => {
                let node = id - 30;
                let changed = if self
                    .tree
                    .nodes()
                    .get(node)
                    .is_some_and(|_| self.tree.nodes().iter().any(|c| c.parent == Some(node)))
                {
                    self.tree.toggle(node)
                } else {
                    self.tree.select(node)
                };
                if changed {
                    log(format!("tree node: {node}"));
                }
                changed
            }
            ("data-table", 30..=34) => {
                let display = id - 30;
                let row = self.visible_rows.get(display).copied().unwrap_or(display);
                let changed = self.table.select_row(row);
                if changed {
                    self.selected = row;
                    log(format!("row: {row}"));
                }
                changed
            }
            ("data-table", 20..=22) => {
                let changed = self.table.sort_by(id - 20);
                if changed {
                    log(format!("sort column: {}", id - 20));
                }
                changed
            }
            ("chart", 30..=33) => {
                let changed = self.chart.select(id - 30);
                if changed {
                    log(format!("chart point: {}", id - 30));
                }
                changed
            }
            ("tooltip", 20) => {
                self.tooltip.visible = !self.tooltip.visible;
                log(format!("tooltip: {}", self.tooltip.visible));
                true
            }
            ("popover", 20) => {
                if self.popover.open {
                    self.focused = self.popover.close();
                    log("popover: closed; focus restored".into());
                } else {
                    self.popover.show(20);
                    log("popover: open".into());
                }
                true
            }
            ("popover", 21) => {
                self.focused = self.popover.close();
                log("popover: outside dismissed; focus restored".into());
                true
            }
            ("toast", 20) => {
                let changed = self.toast.visible;
                self.toast.dismiss();
                if changed {
                    log("toast: dismissed".into());
                }
                changed
            }
            ("toast", 21) => {
                if self.toast.visible {
                    self.toast.advance(1000);
                    log("toast timer: advanced 1 s".into());
                } else {
                    self.toast
                        .show("Changes saved", controls::NoticeTone::Success, 5000);
                    log("toast: shown (5 s fixture)".into());
                }
                true
            }
            ("banner", 20) => {
                let changed = self.banner.dismiss();
                if changed {
                    log("banner: dismissed".into());
                }
                changed
            }
            ("progress", 20) => {
                let next = (self.progress.value() + 0.1).min(1.);
                let changed = self.progress.set(next);
                if changed {
                    log(format!("progress: {:.0}%", next * 100.));
                }
                changed
            }
            ("empty-state", 20) => {
                self.empty_state_created = true;
                log("empty-state action: created Documents fixture item".into());
                true
            }
            _ => false,
        }
    }

    pub(super) fn key(
        &mut self,
        renderer: &str,
        key: ControlKey,
        down: bool,
        log: &mut impl FnMut(String),
    ) -> bool {
        if !down {
            return match renderer {
                "icon-button" => self.icon_button.key(key, false),
                "link" => self.link.key(key, false),
                "slider" => self.slider_view.key(key, false, &mut self.slider),
                "radio-group" => !matches!(
                    self.radio_view.key(key, false, &mut self.radio),
                    SelectionEvent::Ignored
                ),
                "switch" => !matches!(
                    self.switch_view.key(key, false, &mut self.switch),
                    SelectionEvent::Ignored
                ),
                _ => supports(renderer),
            };
        }
        if self.disabled {
            self.cancel_pointer();
            return true;
        }
        let changed = match renderer {
            "slider" => self.slider_view.key(key, true, &mut self.slider),
            "radio-group" => {
                self.radio_view.key(key, true, &mut self.radio) != SelectionEvent::Ignored
            }
            "segmented-control" if key == ControlKey::Space => self
                .focused
                .and_then(|id| id.checked_sub(30))
                .is_some_and(|i| self.segmented.select(i)),
            "segmented-control" => self.segmented.key(key),
            "list" => self.list.key(key),
            "tree" => self.tree.key(key),
            "data-table" => self.table.key(key),
            "chart" => self.chart.key(key),
            "split-view" => self
                .split
                .key_in(key, self.split_bounds, controls::Axis::Horizontal),
            "combo-box" => {
                let was_open = self.combo.open;
                let selected = self.combo.key(key).is_some();
                selected
                    || self.combo.open != was_open
                    || self.combo.open && matches!(key, ControlKey::Up | ControlKey::Down)
            }
            "command-palette" => {
                let was_open = self.command.combo.open;
                let selected = self.command.key(key).is_some();
                selected
                    || self.command.combo.open != was_open
                    || self.command.combo.open && matches!(key, ControlKey::Up | ControlKey::Down)
            }
            "link" if key == ControlKey::Enter => {
                self.link.button.state.focused = self.focused == Some(20);
                self.link.key(key, true)
            }
            "icon-button" => {
                self.icon_button.button.state.focused = self.focused == Some(20);
                self.icon_button.key(key, true)
            }
            "disclosure" if matches!(key, ControlKey::Enter | ControlKey::Space) => {
                self.disclosure.toggle()
            }
            "switch" => {
                self.switch_view.key(key, true, &mut self.switch) != SelectionEvent::Ignored
            }
            "popover" if key == ControlKey::Escape && self.popover.open => {
                self.focused = self.popover.close();
                true
            }
            "tooltip" if key == ControlKey::Escape => {
                self.tooltip.visible = false;
                self.tooltip_dismissed = true;
                true
            }
            _ => return false,
        };
        if changed {
            match renderer {
                "radio-group" => self.focused = self.radio_view.focused().map(|i| 30 + i),
                "segmented-control" => self.focused = Some(30 + self.segmented.selected),
                "list" => self.focused = self.list.selected.map(|i| 30 + i),
                "tree" => self.focused = self.tree.selected.map(|i| 30 + i),
                "data-table" => self.focused = self.table.selected_row.map(|i| 30 + i),
                "chart" => {
                    self.focused = self.chart.selected().map(|i| 30 + i);
                    self.chart.set_focused(true, true);
                }
                _ => {}
            }
            log(format!("{}: keyboard state changed", renderer));
        }
        true
    }

    pub(super) fn draw(
        &mut self,
        e: &Entry,
        s: &mut StoryState,
        ctx: &mut PageCtx<'_>,
        scene: &mut Scene,
        c: Rect,
    ) {
        let story_hit_start = s.hits.len();
        self.hits.clear();
        self.rows.clear();
        scene.push_clip(c);
        let x = c.min_x();
        let y = c.min_y();
        let w = c.size.width;
        let has_disabled_toggle = supports_disabled(e.renderer());
        let body_top = if has_disabled_toggle { 46. } else { 0. };
        if has_disabled_toggle {
            quiet_action(
                s,
                ctx,
                scene,
                10,
                Rect::new(x, y, 112., 32.),
                if self.disabled { "Enabled" } else { "Disabled" },
                (self.disabled, false),
            );
        }
        let body = Rect::new(
            x,
            y + body_top,
            w,
            (c.max_y() - y - body_top - 116.).max(0.),
        );
        let control_clip = match s.button_clip {
            Some(ancestor) => body.intersection(&ancestor).unwrap_or(Rect::new(
                body.min_x(),
                body.min_y(),
                0.,
                0.,
            )),
            None => body,
        };
        s.button_clip = Some(body);
        scene.push_clip(body);
        let bx = body.min_x();
        let by = body.min_y();
        let bw = body.size.width;
        let palette = Palette {
            theme: ctx.theme,
            brand: s.brand,
        };
        if self.disabled && self.pointer_dragging.is_some() {
            self.cancel_pointer();
        }
        self.disclosure.disabled = self.disabled;
        self.slider.disabled = self.disabled;
        self.switch.disabled = self.disabled;
        if self.disabled {
            self.slider_view.cancel();
            self.radio_view.cancel();
            self.switch_view.cancel();
        }
        self.radio_view.set_disabled(self.disabled);
        if self.focused == Some(20) {
            if !self.slider_view.is_focused() {
                self.slider_view.focus(
                    s.buttons
                        .get(&20)
                        .is_some_and(|button| button.state.focus_visible),
                );
            }
            if !self.switch_view.is_focused() {
                self.switch_view.focus(
                    s.buttons
                        .get(&20)
                        .is_some_and(|button| button.state.focus_visible),
                );
            }
        } else {
            self.slider_view.blur();
            self.switch_view.blur();
        }
        if self.focused.is_some_and(|id| (30..33).contains(&id)) {
            if self.radio_view.focused() != self.focused.map(|id| id - 30) {
                let focus_visible = self.focused.is_some_and(|id| {
                    s.buttons
                        .get(&id)
                        .is_some_and(|button| button.state.focus_visible)
                });
                self.radio_view
                    .focus(&self.radio, self.focused.map(|id| id - 30), focus_visible);
            }
        } else {
            self.radio_view.blur();
        }
        self.icon_button.button.state.disabled = self.disabled;
        self.link.button.state.disabled = self.disabled;
        for n in 0..3 {
            self.segmented.set_enabled(n, !self.disabled);
        }
        self.chart
            .set_focused(self.focused.is_some(), self.focused.is_some());
        match e.renderer() {
            "stack" => {
                self.stack.axis = controls::Axis::Horizontal;
                self.stack.gap = 8.;
                let items = self
                    .stack
                    .layout(Rect::new(bx, by + 20., bw.min(650.), 64.), 3);
                for (n, r) in items.into_iter().enumerate() {
                    paint::surface(scene, r, palette, true);
                    label(
                        ctx,
                        scene,
                        r.inset(10.),
                        ["Leading", "Center", "Trailing"][n],
                        false,
                    );
                }
                line(
                    ctx,
                    scene,
                    Rect::new(bx, by + 96., bw, 24.),
                    "Stack divides the available main axis evenly; gap is 8 pt.",
                );
            }
            "grid" => {
                self.grid.gap_x = 8.;
                self.grid.gap_y = 8.;
                let items = self.grid.layout(
                    Rect::new(bx, by + 16., bw.min(720.), (body.size.height - 28.).max(0.)),
                    9,
                    58.,
                );
                for (n, r) in items.into_iter().enumerate() {
                    paint::surface(scene, r, palette, true);
                    label(
                        ctx,
                        scene,
                        r.inset(8.),
                        &format!("Item {:02}", n + 1),
                        false,
                    );
                }
            }
            "separator" => {
                label(
                    ctx,
                    scene,
                    Rect::new(bx, by + 4., bw.min(300.), 28.),
                    "Account settings",
                    true,
                );
                controls::separator(
                    scene,
                    Rect::new(bx, by + 42., bw.min(600.), 12.),
                    palette,
                    controls::Axis::Horizontal,
                );
                label(
                    ctx,
                    scene,
                    Rect::new(bx, by + 62., bw.min(500.), 28.),
                    "Profile and preferences",
                    false,
                );
                controls::separator(
                    scene,
                    Rect::new(bx + 300., by + 110., 12., 160.),
                    palette,
                    controls::Axis::Vertical,
                );
            }
            "disclosure" => {
                action(
                    s,
                    ctx,
                    scene,
                    20,
                    Rect::new(bx, by + 12., bw.min(500.), 40.),
                    if self.disclosure.open {
                        "⌄  Details"
                    } else {
                        "›  Details"
                    },
                    (self.disclosure.open, self.disabled),
                );
                if self.disclosure.open {
                    paint::surface(
                        scene,
                        Rect::new(bx, by + 60., bw.min(500.), 92.),
                        palette,
                        true,
                    );
                    label(
                        ctx,
                        scene,
                        Rect::new(bx + 14., by + 72., bw.min(470.), 68.),
                        "Disclosure content is mounted only while open. State remains local to this story.",
                        false,
                    );
                }
            }
            "split-view" => {
                let bounds = Rect::new(
                    bx,
                    by + 8.,
                    bw.min(760.),
                    (body.size.height - 20.).max(120.),
                );
                self.split_bounds = bounds;
                let split_layout = self.split.layout_clipped(
                    bounds,
                    controls::Axis::Horizontal,
                    Some(control_clip),
                );
                let leading = split_layout.leading.frame();
                let divider = split_layout.divider.frame();
                let trailing = split_layout.trailing.frame();
                paint::surface(scene, leading, palette, true);
                paint::surface(scene, trailing, palette, true);
                if !self
                    .split
                    .is_constrained(bounds, controls::Axis::Horizontal)
                {
                    controls::separator(scene, divider, palette, controls::Axis::Vertical);
                    let divider_hit =
                        controls::ControlFrame::new(divider.inset(-4.), Some(control_clip))
                            .visible_frame();
                    if let Some(divider_hit) = divider_hit {
                        s.hits.push((90, divider_hit));
                    }
                } else {
                    quiet_action(
                        s,
                        ctx,
                        scene,
                        91,
                        Rect::new(bx, by + 8., 112., 32.),
                        "Show master",
                        (self.split.visible_pane() == controls::Pane::Leading, false),
                    );
                    quiet_action(
                        s,
                        ctx,
                        scene,
                        92,
                        Rect::new(bx + 120., by + 8., 112., 32.),
                        "Show detail",
                        (self.split.visible_pane() == controls::Pane::Trailing, false),
                    );
                }
                label(ctx, scene, leading.inset(12.), "Master pane", false);
                label(ctx, scene, trailing.inset(12.), "Detail pane", false);
                line(
                    ctx,
                    scene,
                    Rect::new(bx, bounds.max_y() + 8., bw, 24.),
                    &format!(
                        "Divider position: {:.0}% · drag, arrow keys, Home / End; Escape restores the drag start.",
                        self.split.ratio() * 100.
                    ),
                );
            }
            "icon-button" | "link" => {
                let is_link = e.renderer() == "link";
                let r = Rect::new(bx, by + 18., if is_link { 260. } else { 44. }, 40.);
                let component = if is_link {
                    self.link.layout(r, Some(control_clip))
                } else {
                    self.icon_button.layout(r, Some(control_clip))
                };
                let r = component.frame();
                if let Some(hit) = component.visible_frame() {
                    s.hits.push((20, hit));
                }
                let mut state = ControlState {
                    disabled: self.disabled,
                    focused: self.focused == Some(20),
                    focus_visible: self.focused == Some(20),
                    hovered: self.hovered == Some(20),
                    ..Default::default()
                };
                if is_link {
                    let ink = controls::link_underline(scene, r, palette, state);
                    ctx.text.proposal_label_in(
                        scene,
                        ctx.theme,
                        r.inset(8.),
                        "Open documentation ↗",
                        proposal::TextRole::UiBody,
                        ink,
                    );
                } else {
                    state.selected = false;
                    paint::button(scene, r, palette, state);
                    draw_icon(ctx, scene, r.inset(10.), Icon::Plus);
                }
                let help = if is_link {
                    "Activates with Enter. Space is not a link activation key.".to_owned()
                } else {
                    format!("Accessible name: {}", self.icon_button.accessible_name())
                };
                line(ctx, scene, r.offset(0., 52.), &help);
            }
            "slider" => {
                let control = Rect::new(bx, by + 28., bw.min(440.), 36.);
                let layout = self.slider_view.render(
                    scene,
                    self.slider,
                    control,
                    Some(control_clip),
                    palette,
                );
                if let Some(hit) = layout.visible {
                    s.hits.push((20, hit));
                } else if self.pointer_dragging == Some(20) {
                    self.pointer_dragging = None;
                }
                label(
                    ctx,
                    scene,
                    Rect::new(bx, by + 10., 160., 26.),
                    &format!("Value: {:.0}", self.slider.value()),
                    false,
                );
                line(
                    ctx,
                    scene,
                    Rect::new(bx, by + 62., bw.min(540.), 24.),
                    "Arrow keys change by 5; Home / End move to bounds. Drag the track to set a value.",
                );
            }
            "combo-box" => {
                let input_height = 38.0_f32.max(s.input.measure_search_height(ctx.text));
                let input = Rect::new(bx, by + 8., bw.min(440.), input_height);
                s.input.set_disabled(self.disabled);
                s.input
                    .build_search_clipped(ctx, input, s.button_clip, scene);
                self.combo.disabled = self.disabled;
                if self.combo.query != s.input.query() {
                    self.combo.set_query(s.input.query());
                }
                self.query = self.combo.query.clone();
                if let Some(visible) = s.input.visible_frame() {
                    self.hits.push((1000, visible));
                    s.hits.push((1000, visible));
                }
                if self.combo.open {
                    for (n, index) in self.combo.filtered().iter().copied().enumerate() {
                        let r = Rect::new(
                            bx,
                            by + 56. + (input_height - 38.) + n as f32 * 38.,
                            bw.min(440.),
                            34.,
                        );
                        quiet_action(
                            s,
                            ctx,
                            scene,
                            40 + index,
                            r,
                            &self.combo.items[index],
                            (self.combo.active == Some(index), self.disabled),
                        );
                    }
                    if self.combo.filtered().is_empty() {
                        line(
                            ctx,
                            scene,
                            Rect::new(bx, by + 60., bw.min(440.), 28.),
                            "No matching options",
                        );
                    }
                }
            }
            "radio-group" => {
                let labels: Vec<_> = (0..self.radio.len())
                    .map(|index| format!("Option {}", index + 1))
                    .collect();
                let label_refs: Vec<_> = labels.iter().map(String::as_str).collect();
                let layout = self.radio_view.render(
                    scene,
                    ctx.text,
                    &self.radio,
                    Rect::new(bx, by, bw.min(300.), 0.),
                    Some(control_clip),
                    palette,
                    &label_refs,
                );
                for (n, row) in layout.rows.iter().enumerate() {
                    let id = 30 + n;
                    if let Some(hit) = row.visible_frame() {
                        s.hits.push((id, hit));
                    }
                }
            }
            "switch" => {
                let label_text = if self.switch.checked {
                    "Notifications on"
                } else {
                    "Notifications off"
                };
                let component = self.switch_view.render_labeled(
                    scene,
                    ctx.text,
                    self.switch,
                    Rect::new(bx, by + 12., bw.min(382.), 32.),
                    Some(control_clip),
                    palette,
                    label_text,
                );
                if let Some(hit) = component.toggle.visible_frame() {
                    s.hits.push((20, hit));
                }
            }
            "segmented-control" => {
                let opts = ["Day", "Week", "Month"];
                for (n, r) in controls::Stack::new(controls::Axis::Horizontal)
                    .layout(Rect::new(bx, by + 18., bw.min(480.), 38.), 3)
                    .into_iter()
                    .enumerate()
                {
                    action(
                        s,
                        ctx,
                        scene,
                        30 + n,
                        r,
                        opts[n],
                        (self.segmented.selected == n, self.disabled),
                    );
                }
            }
            "breadcrumb" => {
                let mut xx = bx;
                for (n, title) in self.breadcrumb.items.iter().enumerate() {
                    let tw = ctx
                        .text
                        .proposal_label(title, proposal::TextRole::UiBody, None)
                        .width as f32
                        + 14.;
                    if n > 0 {
                        label(
                            ctx,
                            scene,
                            Rect::new(xx - 2., by + 22., 18., 30.),
                            "/",
                            false,
                        );
                        xx += 18.;
                    }
                    action(
                        s,
                        ctx,
                        scene,
                        30 + n,
                        Rect::new(xx, by + 18., tw, 34.),
                        title,
                        (n == self.selected, false),
                    );
                    xx += tw + 8.;
                }
            }
            "command-palette" => {
                action(
                    s,
                    ctx,
                    scene,
                    20,
                    Rect::new(bx, by + 8., 200., 36.),
                    "Open command palette",
                    (self.command.combo.open, false),
                );
                if self.command.combo.open {
                    let input_height = 38.0_f32.max(s.input.measure_search_height(ctx.text));
                    let input = Rect::new(bx, by + 52., bw.min(420.), input_height);
                    s.input.set_disabled(self.disabled);
                    s.input
                        .build_search_clipped(ctx, input, s.button_clip, scene);
                    if self.command.combo.query != s.input.query() {
                        self.command.combo.set_query(s.input.query());
                    }
                    if let Some(visible) = s.input.visible_frame() {
                        self.hits.push((1000, visible));
                        s.hits.push((1000, visible));
                    }
                    for (row, index) in self.command.combo.filtered().iter().copied().enumerate() {
                        let title = self.command.combo.items[index].clone();
                        action(
                            s,
                            ctx,
                            scene,
                            40 + index,
                            Rect::new(
                                bx,
                                by + 98. + (input_height - 38.) + row as f32 * 38.,
                                bw.min(420.),
                                34.,
                            ),
                            &title,
                            (self.command.combo.active == Some(index), self.disabled),
                        );
                    }
                }
            }
            "list" => {
                for n in 0..self.list.count {
                    let r = Rect::new(bx, by + n as f32 * 40., bw.min(360.), 36.);
                    self.rows.push(r);
                    action(
                        s,
                        ctx,
                        scene,
                        30 + n,
                        r,
                        ["Overview", "Documents", "Images", "Archive", "Trash"][n],
                        (self.list.selected == Some(n), self.disabled),
                    );
                }
                line(
                    ctx,
                    scene,
                    Rect::new(bx, by + 212., bw, 26.),
                    "Single selection. Up / Down move; Home / End jump to first / last.",
                );
            }
            "tree" => {
                let visible = self.tree.visible();
                for (row, node) in visible.iter().copied().enumerate() {
                    let item = &self.tree.nodes()[node];
                    let depth = depth(&self.tree, node);
                    let r = Rect::new(
                        bx + depth as f32 * 20.,
                        by + row as f32 * 38.,
                        (bw - depth as f32 * 20.).clamp(0., 420.),
                        34.,
                    );
                    let title = if self
                        .tree
                        .nodes()
                        .iter()
                        .any(|child| child.parent == Some(node))
                    {
                        if item.expanded {
                            format!("⌄  {}", item.label)
                        } else {
                            format!("›  {}", item.label)
                        }
                    } else {
                        format!("    {}", item.label)
                    };
                    action(
                        s,
                        ctx,
                        scene,
                        30 + node,
                        r,
                        &title,
                        (
                            self.tree.selected == Some(node),
                            self.disabled || item.disabled,
                        ),
                    );
                }
                line(
                    ctx,
                    scene,
                    Rect::new(bx, by + 128., bw, 28.),
                    "Right expands; Left collapses or moves to the parent. Up / Down navigate visible rows.",
                );
            }
            "data-table" => {
                let headers = ["Name", "Kind", "Updated"];
                let colw = bw.min(720.) / 3.;
                for (col, title) in headers.iter().enumerate() {
                    let header = if self.table.sort.is_some_and(|(c, _)| c == col) {
                        format!("{title}  ↕")
                    } else {
                        (*title).to_owned()
                    };
                    quiet_action(
                        s,
                        ctx,
                        scene,
                        20 + col,
                        Rect::new(bx + col as f32 * colw, by, colw, 34.),
                        &header,
                        (false, false),
                    );
                }
                let base = ["Project", "Notes", "Assets", "Archive", "Readme"];
                let mut order: Vec<usize> = (0..self.table.rows.min(base.len())).collect();
                if let Some((column, direction)) = self.table.sort {
                    order.sort_by_key(|index| match column {
                        0 => base[*index],
                        1 => ["Folder", "Text", "Image", "Folder", "Text"][*index],
                        _ => ["Today", "Yesterday", "Monday", "Friday", "Tuesday"][*index],
                    });
                    if direction == controls::SortDirection::Descending {
                        order.reverse();
                    }
                }
                self.visible_rows = order.clone();
                for (display, row) in order.into_iter().enumerate() {
                    let r = Rect::new(bx, by + 40. + display as f32 * 38., bw.min(720.), 34.);
                    self.rows.push(r);
                    quiet_action(
                        s,
                        ctx,
                        scene,
                        30 + display,
                        r,
                        "",
                        (self.table.selected_row == Some(row), false),
                    );
                    let values = [
                        format!("{} {}", base[row], row + 1),
                        ["Folder", "Text", "Image", "Folder", "Text"][row].to_owned(),
                        ["Today", "Yesterday", "Monday", "Friday", "Tuesday"][row].to_owned(),
                    ];
                    for (column, value) in values.iter().enumerate() {
                        centered_label(
                            ctx,
                            scene,
                            Rect::new(
                                bx + column as f32 * colw + 8.,
                                r.min_y(),
                                (colw - 16.).max(0.),
                                r.size.height,
                            ),
                            value,
                            proposal::TextRole::UiBody,
                            ColorRole::PrimaryText.resolve(ctx.theme),
                        );
                    }
                }
            }
            "chart" => {
                let bounds = Rect::new(bx, by + 8., bw.min(760.), (body.size.height - 36.).max(0.));
                let geometry = paint_bar_chart_with_text_scale(
                    scene,
                    bounds,
                    palette,
                    &self.chart,
                    ctx.text.type_scale(),
                );
                for bar in geometry.bars {
                    s.hits.push((30 + bar.index, bar.rect.inset(-6.)));
                    if bar.rect.size.height > 0. {
                        ctx.text.proposal_label_in(
                            scene,
                            ctx.theme,
                            bar.value_label,
                            &format!("{}", bar.value),
                            proposal::TextRole::UiCaption,
                            ColorRole::PrimaryText.resolve(ctx.theme),
                        );
                    }
                    ctx.text.proposal_label_in(
                        scene,
                        ctx.theme,
                        bar.category_label,
                        &bar.label,
                        proposal::TextRole::UiCaption,
                        ColorRole::SecondaryText.resolve(ctx.theme),
                    );
                }
                if geometry.invalid_count > 0 {
                    line(
                        ctx,
                        scene,
                        Rect::new(bx, bounds.max_y() + 4., bw, 22.),
                        &format!("{} non-finite values omitted", geometry.invalid_count),
                    );
                }
            }
            "tooltip" => {
                let r = Rect::new(bx, by + 16., 164., 36.);
                action(s, ctx, scene, 20, r, "Hover or focus me", (false, false));
                if (self.tooltip.visible || self.hovered == Some(20) || self.focused == Some(20))
                    && !self.tooltip_dismissed
                {
                    paint::surface(
                        scene,
                        Rect::new(bx + 8., by + 58., 276., 48.),
                        palette,
                        true,
                    );
                    label(
                        ctx,
                        scene,
                        Rect::new(bx + 18., by + 66., 256., 32.),
                        &self.tooltip.text,
                        false,
                    );
                }
                line(
                    ctx,
                    scene,
                    Rect::new(bx, by + 122., bw, 24.),
                    "Tooltip appears on hover or focus-visible. Escape dismisses it.",
                );
            }
            "popover" => {
                action(
                    s,
                    ctx,
                    scene,
                    20,
                    Rect::new(bx, by + 10., 150., 36.),
                    "More options",
                    (self.popover.open, false),
                );
                if self.popover.open {
                    paint::surface(
                        scene,
                        Rect::new(bx, by + 56., bw.min(260.), 96.),
                        palette,
                        true,
                    );
                    label(
                        ctx,
                        scene,
                        Rect::new(bx + 14., by + 66., 230., 30.),
                        "Popover content",
                        false,
                    );
                    action(
                        s,
                        ctx,
                        scene,
                        21,
                        Rect::new(bx + 10., by + 104., 120., 34.),
                        "Dismiss",
                        (false, false),
                    );
                }
                line(
                    ctx,
                    scene,
                    Rect::new(bx, by + 170., bw, 24.),
                    "Escape or outside click dismisses and restores the invoker focus.",
                );
            }
            "toast" => {
                if self.toast.visible {
                    paint::surface(
                        scene,
                        Rect::new(bx, by + 12., bw.min(520.), 62.),
                        palette,
                        true,
                    );
                    let status = match self.toast.tone {
                        controls::NoticeTone::Info => controls::StatusBadge::Info,
                        controls::NoticeTone::Success => controls::StatusBadge::Succeeded,
                        controls::NoticeTone::Warning | controls::NoticeTone::Error => {
                            controls::StatusBadge::Failed
                        }
                    };
                    controls::status_badge(
                        scene,
                        Rect::new(bx + 14., by + 30., 10., 10.),
                        palette,
                        status,
                    );
                    label(
                        ctx,
                        scene,
                        Rect::new(bx + 36., by + 24., 340., 34.),
                        &self.toast.message,
                        false,
                    );
                    quiet_action(
                        s,
                        ctx,
                        scene,
                        20,
                        Rect::new(bx + 380., by + 22., 90., 34.),
                        "Dismiss",
                        (false, false),
                    );
                    quiet_action(
                        s,
                        ctx,
                        scene,
                        21,
                        Rect::new(bx, by + 84., 156., 34.),
                        "Advance fixture timer",
                        (false, false),
                    );
                    line(
                        ctx,
                        scene,
                        Rect::new(bx + 166., by + 84., bw.min(300.), 28.),
                        &format!("{} ms remaining", self.toast.remaining_ms()),
                    );
                } else {
                    line(
                        ctx,
                        scene,
                        Rect::new(bx, by + 20., bw, 28.),
                        "Toast dismissed.",
                    );
                    quiet_action(
                        s,
                        ctx,
                        scene,
                        21,
                        Rect::new(bx, by + 54., 112., 34.),
                        "Show again",
                        (false, false),
                    );
                }
                line(
                    ctx,
                    scene,
                    Rect::new(bx, by + 126., bw, 24.),
                    "Time advances only when the fixture timer control is activated.",
                );
            }
            "banner" => {
                if self.banner.visible {
                    paint::surface(
                        scene,
                        Rect::new(bx, by + 12., bw.min(640.), 74.),
                        palette,
                        true,
                    );
                    controls::status_badge(
                        scene,
                        Rect::new(bx + 12., by + 24., 12., 12.),
                        palette,
                        controls::StatusBadge::Info,
                    );
                    label(
                        ctx,
                        scene,
                        Rect::new(bx + 34., by + 18., 420., 54.),
                        &self.banner.message,
                        false,
                    );
                    action(
                        s,
                        ctx,
                        scene,
                        20,
                        Rect::new(bx + 470., by + 28., 92., 34.),
                        "Dismiss",
                        (false, false),
                    );
                } else {
                    line(
                        ctx,
                        scene,
                        Rect::new(bx, by + 20., bw, 28.),
                        "Banner dismissed. Reset restores the initial fixture.",
                    );
                }
            }
            "status-badge" => {
                for (n, status) in [
                    controls::StatusBadge::Info,
                    controls::StatusBadge::Running,
                    controls::StatusBadge::Succeeded,
                    controls::StatusBadge::Failed,
                ]
                .into_iter()
                .enumerate()
                {
                    let r = Rect::new(bx + n as f32 * 116., by + 20., 106., 28.);
                    controls::status_badge(scene, r, palette, status);
                    centered_label(
                        ctx,
                        scene,
                        r.inset(5.),
                        ["Info", "Running", "Succeeded", "Failed"][n],
                        proposal::TextRole::UiCaption,
                        ColorRole::PrimaryText.resolve(ctx.theme),
                    );
                }
            }
            "progress" => {
                let r = Rect::new(bx, by + 26., bw.min(500.), 12.);
                controls::progress(scene, r, palette, self.progress);
                action(
                    s,
                    ctx,
                    scene,
                    20,
                    Rect::new(bx, by + 54., 118., 34.),
                    "Advance 10%",
                    (false, self.progress.value() >= 1.),
                );
                centered_label(
                    ctx,
                    scene,
                    Rect::new(bx + 132., by + 54., 120., 34.),
                    &format!("{:.0}%", self.progress.value() * 100.),
                    proposal::TextRole::UiBody,
                    ColorRole::PrimaryText.resolve(ctx.theme),
                );
            }
            "empty-state" => {
                let state = if self.empty_state_created {
                    controls::EmptyState {
                        title: "Documents".into(),
                        detail: "One fixture document was created.".into(),
                        action: None,
                    }
                } else {
                    controls::EmptyState {
                        title: "No documents yet".into(),
                        detail: "Create a document to begin your workspace.".into(),
                        action: Some("Create document".into()),
                    }
                };
                paint::surface(
                    scene,
                    Rect::new(bx, by + 12., bw.min(520.), 164.),
                    palette,
                    true,
                );
                label(
                    ctx,
                    scene,
                    Rect::new(bx + 20., by + 34., 420., 34.),
                    &state.title,
                    true,
                );
                label(
                    ctx,
                    scene,
                    Rect::new(bx + 20., by + 72., 460., 54.),
                    &state.detail,
                    false,
                );
                if let Some(title) = state.action.as_deref() {
                    action(
                        s,
                        ctx,
                        scene,
                        20,
                        Rect::new(bx + 20., by + 128., 150., 34.),
                        title,
                        (false, false),
                    );
                }
            }
            "markdown" => {
                let mut yy = by + 4.;
                for block in &self.markdown.blocks {
                    let (text, role) = match block {
                        controls::MarkdownBlock::Heading { text, .. } => {
                            (text.clone(), proposal::TextRole::UiHeading)
                        }
                        controls::MarkdownBlock::Paragraph(t) => {
                            (t.clone(), proposal::TextRole::UiBody)
                        }
                        controls::MarkdownBlock::Bullet(t) => {
                            (format!("• {t}"), proposal::TextRole::UiBody)
                        }
                        controls::MarkdownBlock::Code { source, .. } => {
                            (source.clone(), proposal::TextRole::Code)
                        }
                    };
                    let h = ctx.text.proposal_label(&text, role, Some(bw)).height as f32;
                    ctx.text.proposal_wrapped_in(
                        scene,
                        ctx.theme,
                        Rect::new(bx, yy, bw, h.max(24.)),
                        &text,
                        role,
                        ColorRole::PrimaryText.resolve(ctx.theme),
                    );
                    yy += h.max(24.) + 12.;
                }
                line(
                    ctx,
                    scene,
                    Rect::new(bx, (by + body.size.height - 28.).max(yy), bw, 24.),
                    "Supported subset: headings, paragraphs, bullets and fenced code.",
                );
            }
            "code-block" => {
                paint::surface(
                    scene,
                    Rect::new(bx, by + 8., bw.min(680.), (body.size.height - 18.).max(80.)),
                    palette,
                    true,
                );
                let code_style = proposal::TextRole::Code.style();
                for (n, text) in self.code.lines().enumerate() {
                    ctx.text.proposal_label_in(
                        scene,
                        ctx.theme,
                        Rect::new(
                            bx + 14.,
                            by + 22. + n as f32 * code_style.line_height,
                            bw.min(650.),
                            code_style.line_height,
                        ),
                        text,
                        proposal::TextRole::Code,
                        ColorRole::PrimaryText.resolve(ctx.theme),
                    );
                }
                line(
                    ctx,
                    scene,
                    Rect::new(bx + 14., (body.max_y() - 34.).max(by + 90.), bw, 24.),
                    "Plain light surface; syntax coloring and editing are not part of this component.",
                );
            }
            "diff-view" => {
                for (n, diff) in self.diff.lines.iter().enumerate() {
                    let (mark, role) = match diff.kind {
                        controls::DiffKind::Equal => ("  ", "primary-text"),
                        controls::DiffKind::Added => ("+ ", "status-succeeded"),
                        controls::DiffKind::Removed => ("− ", "status-failed"),
                    };
                    ctx.text.proposal_label_in(
                        scene,
                        ctx.theme,
                        Rect::new(bx + 8., by + n as f32 * 30., bw.min(700.), 28.),
                        &format!("{mark}{}", diff.text),
                        proposal::TextRole::Code,
                        palette
                            .color(role)
                            .unwrap_or_else(|| ColorRole::PrimaryText.resolve(ctx.theme)),
                    );
                }
                line(
                    ctx,
                    scene,
                    Rect::new(bx, by + self.diff.lines.len() as f32 * 30. + 12., bw, 24.),
                    "Deterministic line-based LCS fixture; large inputs fall back to delete/add blocks.",
                );
            }
            _ => {}
        }
        scene.pop_clip();
        let log_y = (c.max_y() - 112.).max(c.min_y());
        event_log(ctx, scene, x, log_y, w, &s.log, true);
        scene.pop_clip();
        let mut story_hits = s.hits.split_off(story_hit_start);
        story_hits.retain_mut(|(id, r)| {
            let clip = if *id == 10 { c } else { body };
            if let Some(clipped) = r.intersection(&clip) {
                *r = clipped;
                true
            } else {
                false
            }
        });
        s.hits.extend(story_hits);
        self.hits = s.hits.clone();
    }

    pub(super) fn hover(&mut self, id: Option<usize>) -> bool {
        let changed = self.hovered != id;
        if changed && id == Some(20) {
            self.tooltip_dismissed = false;
        }
        self.hovered = id;
        self.tooltip.visible = id == Some(20) && !self.tooltip_dismissed;
        self.chart.set_hovered(id.and_then(|id| id.checked_sub(30)));
        changed
    }
    pub(super) fn pointer_down(
        &mut self,
        renderer: &str,
        id: usize,
        point: Point,
        log: &mut impl FnMut(String),
    ) -> bool {
        if self.disabled && !matches!(id, 0 | 10) {
            return false;
        }
        if self.focused != Some(id) && id == 20 {
            self.tooltip_dismissed = false;
        }
        self.focused = Some(id);
        self.host_focus_changed(renderer, id, false);
        match renderer {
            "slider" if id == 20 => {
                let before = self.slider.value();
                self.slider_view.pointer_down(point, &mut self.slider);
                if before != self.slider.value() {
                    log(format!("value: {:.0}", self.slider.value()));
                }
                true
            }
            "radio-group" if (30..33).contains(&id) => {
                let event = self.radio_view.pointer_down(point, &self.radio);
                self.focused = self.radio_view.focused().map(|index| 30 + index);
                !matches!(event, SelectionEvent::Ignored)
            }
            "switch" if id == 20 => self.switch_view.pointer_down(point, &self.switch),
            "split-view" if id == 90 => {
                self.pointer_dragging = Some(id);
                self.split
                    .begin_drag(point.x, self.split_bounds, controls::Axis::Horizontal)
            }
            "icon-button" if id == 20 => {
                self.pointer_dragging = Some(id);
                self.icon_button.pointer_down();
                true
            }
            "link" if id == 20 => {
                self.pointer_dragging = Some(id);
                self.link.pointer_down();
                true
            }
            _ => false,
        }
    }
    pub(super) fn pointer_move(
        &mut self,
        renderer: &str,
        point: Point,
        hit: Option<usize>,
        log: &mut impl FnMut(String),
    ) -> bool {
        let mut changed = self.hover(hit);
        if renderer == "slider" {
            let before = self.slider.value();
            let moved = self.slider_view.pointer_move(point, &mut self.slider);
            if before != self.slider.value() {
                log(format!("value: {:.0}", self.slider.value()));
            }
            changed |= moved;
        }
        if renderer == "radio-group" {
            changed |= self.radio_view.pointer_move(point);
        }
        if renderer == "switch" {
            changed |= self.switch_view.pointer_move(point);
        }
        if let ("split-view", Some(90)) = (renderer, self.pointer_dragging) {
            let next = self
                .split
                .drag_to(point.x, self.split_bounds, controls::Axis::Horizontal);
            changed |= next;
            if next {
                log(format!("split: {:.0}%", self.split.ratio() * 100.));
            }
        }
        changed
    }
    pub(super) fn pointer_up(
        &mut self,
        renderer: &str,
        point: Point,
        hit: Option<usize>,
        log: &mut impl FnMut(String),
    ) -> bool {
        match renderer {
            "slider" => return self.slider_view.pointer_up(point, &self.slider),
            "radio-group" => {
                let result = self.radio_view.pointer_up(point, &mut self.radio);
                self.focused = self.radio_view.focused().map(|index| 30 + index);
                if result == SelectionEvent::Changed {
                    log(format!(
                        "radio: {}",
                        self.radio.selected.unwrap_or_default()
                    ));
                }
                return result != SelectionEvent::Ignored;
            }
            "switch" => {
                let result = self.switch_view.pointer_up(point, &mut self.switch);
                if result == SelectionEvent::Changed {
                    log(format!("switch: {}", self.switch.checked));
                }
                return result != SelectionEvent::Ignored;
            }
            _ => {}
        }
        let dragging = self.pointer_dragging.take();
        match (renderer, dragging) {
            ("split-view", Some(90)) => {
                self.split.end_drag();
                true
            }
            ("icon-button", Some(20)) => {
                let activated = self.icon_button.pointer_up(hit == Some(20));
                if activated {
                    log(format!(
                        "icon-button: {}",
                        self.icon_button.accessible_name()
                    ));
                }
                activated
            }
            ("link", Some(20)) => {
                let activated = self.link.pointer_up(hit == Some(20));
                if activated {
                    log("link: activated".into());
                }
                activated
            }
            _ => false,
        }
    }
    pub(super) fn cancel_pointer(&mut self) -> bool {
        let was_dragging = self.pointer_dragging.take().is_some();
        self.slider_view.cancel();
        self.radio_view.cancel();
        self.switch_view.cancel();
        self.split.cancel_drag();
        self.icon_button.button.cancel();
        self.link.button.cancel();
        was_dragging
    }
}

fn depth(tree: &controls::Tree, node: usize) -> usize {
    let mut d = 0;
    let mut parent = tree.nodes().get(node).and_then(|n| n.parent);
    while let Some(p) = parent {
        d += 1;
        parent = tree.nodes().get(p).and_then(|n| n.parent);
    }
    d
}

#[cfg(test)]
mod tests {
    use super::super::{Workbench, entries};
    use super::*;
    use crate::gallery::{static_text::StaticText, text::TextEngine};
    use tekes_ui_platform_macos::{
        Event, Modifiers, MouseButton, MouseEvent, MouseEventKind, Point as NativePoint,
    };

    fn index(renderer: &str) -> usize {
        entries()
            .iter()
            .position(|entry| entry.renderer() == renderer)
            .expect("registered story")
    }

    fn build(
        workbench: &mut Workbench,
        index: usize,
        text: &mut TextEngine,
        content: Rect,
        clip: Rect,
    ) {
        text.begin_frame();
        let mut static_text = StaticText::new(None);
        let mut ctx = PageCtx {
            theme: tekes_ui_tokens::Theme::LIGHT,
            text,
            static_text: &mut static_text,
        };
        workbench.build_clipped(index, &mut ctx, content, clip, &mut Scene::new());
    }

    fn mouse(point: Point, kind: MouseEventKind) -> Event {
        Event::Mouse(MouseEvent {
            position: NativePoint {
                x: point.x as f64,
                y: point.y as f64,
            },
            modifiers: Modifiers::NONE,
            kind,
        })
    }

    fn click(workbench: &mut Workbench, index: usize, point: Point, text: &mut TextEngine) {
        workbench.handle(
            index,
            &mouse(
                point,
                MouseEventKind::Down {
                    button: MouseButton::Left,
                    click_count: 1,
                },
            ),
            text,
        );
        workbench.handle(
            index,
            &mouse(
                point,
                MouseEventKind::Up {
                    button: MouseButton::Left,
                    click_count: 1,
                },
            ),
            text,
        );
    }

    #[test]
    fn slider_workbench_uses_full_thumb_hit_and_retained_visual_track_until_hidden() {
        let mut workbench = Workbench::default();
        let mut text = TextEngine::new();
        let index = index("slider");
        let content = Rect::new(312., 70., 1000., 820.);
        build(&mut workbench, index, &mut text, content, content);

        let state = workbench.state(index);
        let hit = state
            .hits
            .iter()
            .find(|(id, _)| *id == 20)
            .map(|(_, rect)| *rect)
            .expect("visible Slider hit frame");
        let track = state.extended.slider_view.layout().track;
        let thumb_point = Point::new(track.center().x + 12., track.center().y);
        assert!(
            hit.contains(thumb_point),
            "the full thumb frame is clickable"
        );

        workbench.handle(
            index,
            &mouse(
                thumb_point,
                MouseEventKind::Down {
                    button: MouseButton::Left,
                    click_count: 1,
                },
            ),
            &mut text,
        );
        assert_eq!(workbench.state(index).extended.slider.value(), 55.);
        let visual_track = workbench.state(index).extended.slider_view.layout().track;
        let drag_point = Point::new(
            visual_track.min_x() + visual_track.size.width * 0.75,
            visual_track.center().y,
        );
        workbench.handle(index, &mouse(drag_point, MouseEventKind::Moved), &mut text);
        assert_eq!(workbench.state(index).extended.slider.value(), 75.);
        assert!(workbench.state(index).extended.slider_view.is_captured());

        let outside = Rect::new(0., 0., 100., 100.);
        build(&mut workbench, index, &mut text, content, outside);
        assert!(!workbench.state(index).hits.iter().any(|(id, _)| *id == 20));
        assert_eq!(
            workbench.state(index).extended.slider_view.layout().visible,
            None
        );
        assert!(!workbench.state(index).extended.slider_view.is_captured());
        workbench.handle(index, &mouse(drag_point, MouseEventKind::Moved), &mut text);
        assert_eq!(workbench.state(index).extended.slider.value(), 75.);
    }

    #[test]
    fn icon_link_radio_and_switch_workbench_hits_are_unique_and_drive_models() {
        for renderer in ["icon-button", "link"] {
            let mut workbench = Workbench::default();
            let mut text = TextEngine::new();
            let index = index(renderer);
            let content = Rect::new(312., 70., 1000., 820.);
            build(&mut workbench, index, &mut text, content, content);
            let state = workbench.state(index);
            let hits: Vec<_> = state.hits.iter().filter(|(id, _)| *id == 20).collect();
            assert_eq!(hits.len(), 1, "{renderer} must register one effective hit");
            let point = hits[0].1.center();
            click(&mut workbench, index, point, &mut text);
            assert!(
                workbench.state(index).log.back().is_some_and(
                    |event| event.contains("activated") || event.contains("Create item")
                )
            );
        }

        for (renderer, id) in [("radio-group", 32), ("switch", 20)] {
            let mut workbench = Workbench::default();
            let mut text = TextEngine::new();
            let index = index(renderer);
            let content = Rect::new(312., 70., 1000., 820.);
            build(&mut workbench, index, &mut text, content, content);
            let point = workbench
                .state(index)
                .hits
                .iter()
                .find(|(hit_id, _)| *hit_id == id)
                .map(|(_, rect)| rect.center())
                .expect("visible component row hit");
            click(&mut workbench, index, point, &mut text);
            let story = &workbench.state(index).extended;
            match renderer {
                "radio-group" => assert_eq!(story.radio.selected, Some(2)),
                "switch" => assert!(story.switch.checked),
                _ => unreachable!(),
            }
        }
    }
}
