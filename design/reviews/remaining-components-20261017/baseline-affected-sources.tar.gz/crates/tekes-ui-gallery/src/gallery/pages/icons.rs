//! The native Gallery icon catalogue, reusing the component renderer.
use super::{
    PageCtx,
    showcase::{Icon, draw_icon},
};
use crate::gallery::icon_catalog::{IconCatalog, preview_sizes};
use tekes_ui_scene::{ImageQuad, Quad, Rect, Scene, Size};
use tekes_ui_tokens::{ColorRole, CornerRadius, Spacing, Stroke, proposal};

pub fn search_rect(content: Rect) -> Rect {
    Rect::new(content.min_x(), content.min_y(), content.size.width, 40.0)
}

fn matches(name: &str, query: &str) -> bool {
    // The common scrolling path has no query. Avoid allocating lowercase
    // strings for every catalogue entry on every frame in that case.
    query.is_empty() || name.to_lowercase().contains(&query.to_lowercase())
}

#[derive(Clone, Copy)]
enum CatalogIcon {
    Native(Icon),
    Legacy(usize),
}
fn filtered<'a>(catalog: &'a IconCatalog, query: &str) -> Vec<(CatalogIcon, &'a str)> {
    let mut found: Vec<_> = Icon::ALL
        .into_iter()
        .map(|(icon, name)| (CatalogIcon::Native(icon), name))
        .chain(
            catalog
                .entries
                .iter()
                .enumerate()
                .map(|(index, entry)| (CatalogIcon::Legacy(index), entry.name.as_str())),
        )
        .filter(|(icon, name)| {
            matches(name, query)
                || match icon {
                    CatalogIcon::Legacy(i) => matches(&catalog.entries[*i].label, query),
                    _ => false,
                }
        })
        .collect();
    found.sort_by_key(|(icon, _)| match icon {
        CatalogIcon::Legacy(i) if catalog.entries[*i].kind == "refine" => 0,
        CatalogIcon::Legacy(i) if !catalog.entries[*i].kind.is_empty() => 1,
        CatalogIcon::Native(_) => 2,
        _ => 3,
    });
    found
}
const GRID_TOP: f32 = 112.0;
const ROW_STEP: f32 = 164.0;
fn columns(width: f32) -> usize {
    let min_tile = 2.0 * (3.0 * preview_sizes()[2] + 4.0 * Spacing::Loose.value());
    if width >= min_tile * 2.0 + Spacing::Loose.value() {
        2
    } else {
        1
    }
}
fn tile_rect(content: Rect, index: usize) -> Rect {
    let gap = Spacing::Loose.value();
    let columns = columns(content.size.width);
    let width = (content.size.width - gap * (columns - 1) as f32) / columns as f32;
    Rect::new(
        content.min_x() + (index % columns) as f32 * (width + gap),
        content.min_y() + GRID_TOP + (index / columns) as f32 * ROW_STEP,
        width,
        148.0,
    )
}
pub fn extent(catalog: &IconCatalog, query: &str, width: f32) -> Size {
    // Computing height needs a count, not a sorted temporary catalogue.
    let count = if query.is_empty() {
        Icon::ALL.len() + catalog.entries.len()
    } else {
        filtered(catalog, query).len()
    };
    Size::new(
        width,
        (GRID_TOP + count.div_ceil(columns(width)) as f32 * ROW_STEP)
            .max(super::super::layout::PAGE_CONTENT.size.height),
    )
}
pub fn visible_legacy(
    catalog: &IconCatalog,
    query: &str,
    content: Rect,
    bounds: Rect,
) -> Vec<usize> {
    filtered(catalog, query)
        .into_iter()
        .enumerate()
        .filter_map(|(i, (icon, _))| {
            tile_rect(content, i).intersection(&bounds)?;
            match icon {
                CatalogIcon::Legacy(index) => Some(index),
                _ => None,
            }
        })
        .collect()
}
pub fn build(ctx: &mut PageCtx<'_>, content: Rect, scene: &mut Scene, query: &str) {
    build_catalog(ctx, content, scene, query, &IconCatalog::default(), content);
}
pub fn build_catalog(
    ctx: &mut PageCtx<'_>,
    content: Rect,
    scene: &mut Scene,
    query: &str,
    catalog: &IconCatalog,
    bounds: Rect,
) {
    let found = filtered(catalog, query);
    let ink = ColorRole::PrimaryText.resolve(ctx.theme);
    let muted = ColorRole::SecondaryText.resolve(ctx.theme);
    let label = format!(
        "{} / {} icons · 名称包含匹配 · 12 / 16 / 24 pt",
        found.len(),
        Icon::ALL.len() + catalog.entries.len()
    );
    ctx.text.proposal_label_in(
        scene,
        ctx.theme,
        Rect::new(
            content.min_x(),
            content.min_y() + 48.0,
            content.size.width,
            24.0,
        ),
        &label,
        proposal::TextRole::UiCaption,
        muted,
    );
    let defaults = catalog
        .entries
        .iter()
        .filter(|e| tekes_ui_icons::Icon::named(&e.name).is_some())
        .count();
    let comparisons = catalog
        .entries
        .iter()
        .filter(|e| e.before.is_some())
        .count();
    let proposals = catalog
        .entries
        .iter()
        .filter(|e| !e.kind.is_empty())
        .count();
    let source_note = format!(
        "图标增补 {proposals} · 已设为默认 {defaults} · 新旧对比 {comparisons} · {}{}",
        if catalog.source.is_some() {
            "原有图标集已加载"
        } else {
            "原有图标集未加载"
        },
        if catalog.notices.is_empty() {
            String::new()
        } else {
            format!(" · {} 项加载异常", catalog.notices.len())
        }
    );
    ctx.text.proposal_label_in(
        scene,
        ctx.theme,
        Rect::new(
            content.min_x(),
            content.min_y() + 76.0,
            content.size.width,
            24.0,
        ),
        &source_note,
        proposal::TextRole::UiCaption,
        muted,
    );
    if found.is_empty() {
        ctx.text.proposal_label_in(
            scene,
            ctx.theme,
            Rect::new(
                content.min_x(),
                content.min_y() + GRID_TOP,
                content.size.width,
                32.0,
            ),
            "没有匹配的图标",
            proposal::TextRole::UiBody,
            muted,
        );
    }
    let gap = Spacing::Loose.value();
    for (i, (icon, name)) in found.into_iter().enumerate() {
        let tile = tile_rect(content, i);
        if tile.intersection(&bounds).is_none() {
            continue;
        }
        let width = tile.size.width;
        scene.push_quad(
            Quad::new(tile, ColorRole::DocumentCanvas.resolve(ctx.theme))
                .with_corner_radius(CornerRadius::Panel.value())
                .with_border(
                    Stroke::Hairline.value(),
                    ColorRole::Border.resolve(ctx.theme),
                ),
        );
        ctx.text.proposal_label_in(
            scene,
            ctx.theme,
            Rect::new(
                tile.min_x() + gap,
                tile.min_y() + gap,
                width - gap * 2.0,
                24.0,
            ),
            name,
            proposal::TextRole::UiBody,
            ink,
        );
        let entry = match icon {
            CatalogIcon::Legacy(index) => Some(&catalog.entries[index]),
            _ => None,
        };
        let paired = entry.is_some_and(|e| e.before.is_some());
        let panels = if paired { 2 } else { 1 };
        for panel in 0..panels {
            let left = tile.min_x() + width * panel as f32 / panels as f32;
            let panel_width = width / panels as f32;
            let variant = entry.map(|e| {
                if paired && panel == 0 {
                    e.before.as_deref().unwrap()
                } else {
                    e
                }
            });
            let caption = match entry {
                Some(e) if paired => {
                    if panel == 0 {
                        "旧稿".into()
                    } else {
                        format!("默认使用 · {}", e.label)
                    }
                }
                Some(e) if e.kind == "refine" => format!("默认使用 · {} · 旧稿未加载", e.label),
                Some(e) if e.kind == "rebuild" => format!("重绘稿 · {}", e.label),
                Some(e) if e.kind == "new" => format!("新增 · {}", e.label),
                Some(_) => "原有图标".into(),
                None => "基础图标".into(),
            };
            ctx.text.proposal_label_in(
                scene,
                ctx.theme,
                Rect::new(
                    left + gap,
                    tile.min_y() + 42.0,
                    panel_width - gap * 2.0,
                    20.0,
                ),
                &caption,
                proposal::TextRole::UiCaption,
                muted,
            );
            for (column, size) in preview_sizes().into_iter().enumerate() {
                let center = left + panel_width * (column as f32 + 0.5) / 3.0;
                let rect = Rect::new(
                    center - size / 2.0,
                    tile.min_y() + 92.0 - size / 2.0,
                    size,
                    size,
                );
                match icon {
                    CatalogIcon::Native(icon) => draw_icon(ctx, scene, rect, icon),
                    CatalogIcon::Legacy(_) => {
                        if let Some(image) = variant.unwrap().images[column] {
                            scene.push_image(ImageQuad {
                                rect,
                                image,
                                opacity: 1.0,
                            });
                        }
                    }
                }
                ctx.text.proposal_label_in(
                    scene,
                    ctx.theme,
                    Rect::new(center - 16.0, tile.min_y() + 116.0, 32.0, 20.0),
                    &format!("{}", size as u32),
                    proposal::TextRole::UiCaption,
                    muted,
                );
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn icon_tiles_reflow_inside_narrow_viewports_without_horizontal_scroll() {
        for width in [384.0, 664.0, 1104.0] {
            let content = Rect::new(312.0, 104.0, width, 400.0);
            for index in 0..12 {
                let tile = tile_rect(content, index);
                assert!(tile.min_x() >= content.min_x());
                assert!(tile.max_x() <= content.max_x());
            }
        }
        assert_eq!(columns(384.0), 1);
        assert_eq!(columns(1104.0), 2);
    }

    #[test]
    fn name_filter_is_case_insensitive_literal_substring() {
        assert!(matches("chevron-right", "vron"));
        assert!(matches("chevron-down", "DOWN"));
        assert!(matches("search", ""));
        assert!(!matches("search", "xyz"));
        assert!(!matches("search", "%"));
        assert!(!matches("search", "_"));
        assert_eq!(
            Icon::ALL
                .iter()
                .filter(|(_, n)| matches(n, "chevron"))
                .count(),
            2
        );
    }
}

#[cfg(test)]
mod catalogue_review {
    use super::*;
    use crate::gallery::{layout, static_text::StaticText, text::TextEngine};
    use tekes_ui_render::Renderer;
    use tekes_ui_tokens::Theme;

    #[test]
    fn combined_search_and_the_last_row_use_the_same_filtered_geometry() {
        let catalog = IconCatalog::fixture(&["tekes-search", "tekes-web-search", "tekes-write"]);
        assert_eq!(filtered(&catalog, "").len(), 13);
        assert_eq!(filtered(&catalog, "SeArCh").len(), 3);
        assert_eq!(filtered(&catalog, "eb-sea").len(), 1);
        assert!(filtered(&catalog, "not-an-icon").is_empty());
        let content = layout::PAGE_CONTENT;
        let last = tile_rect(content, 12);
        assert!(
            last.max_y()
                <= content.min_y()
                    + extent(
                        &catalog,
                        "",
                        super::super::super::layout::PAGE_CONTENT.size.width
                    )
                    .height
        );
        let last_bounds = Rect::new(content.min_x(), last.min_y(), content.size.width, 120.0);
        assert_eq!(visible_legacy(&catalog, "", content, last_bounds), vec![2]);
        let first_bounds = Rect::new(
            content.min_x(),
            content.min_y(),
            content.size.width,
            GRID_TOP + 120.0,
        );
        assert!(visible_legacy(&catalog, "", content, first_bounds).is_empty());
        assert_eq!(
            visible_legacy(&catalog, "write", content, first_bounds),
            vec![2]
        );
    }

    #[test]
    fn new_old_and_refined_share_name_search_and_comparison_culling() {
        let mut catalog = IconCatalog::fixture(&["tekes-settings", "tekes-search"]);
        catalog.add_proposals();
        assert_eq!(filtered(&catalog, "SETT").len(), 1);
        assert_eq!(filtered(&catalog, "cad-").len(), 14);
        assert_eq!(filtered(&catalog, "drama-").len(), 14);
        assert_eq!(filtered(&catalog, "SeArCh").len(), 2);
        assert_eq!(filtered(&catalog, "设置").len(), 1);
        let visible = visible_legacy(
            &catalog,
            "settings",
            layout::PAGE_CONTENT,
            layout::PAGE_CONTENT,
        );
        assert_eq!(visible.len(), 1);
        assert!(catalog.entries[visible[0]].before.is_some());
    }

    /// Explicit local review: never runs with private assets on CI or in fixed snapshots.
    #[test]
    #[ignore = "requires explicit TEKESUI_ICON_DIR and TEKESUI_ICONS_REVIEW_OUT"]
    fn local_full_catalogue_pixels_and_scroll_culling() {
        let source = std::env::var_os("TEKESUI_ICON_DIR").expect("explicit local icon source");
        let out = std::path::PathBuf::from(
            std::env::var_os("TEKESUI_ICONS_REVIEW_OUT").expect("private evidence directory"),
        );
        std::fs::create_dir_all(&out).unwrap();
        let mut catalog = IconCatalog::load(std::path::Path::new(&source));
        catalog.add_proposals();
        assert_eq!(catalog.entries.len(), 176);
        assert_eq!(
            catalog
                .entries
                .iter()
                .filter(|e| e.before.is_some())
                .count(),
            8
        );
        assert!(catalog.notices.is_empty(), "{:?}", catalog.notices);
        assert_eq!(filtered(&catalog, "").len(), 186);
        assert_eq!(filtered(&catalog, "SeArCh").len(), 3);
        let mut renderer = Renderer::new_headless().unwrap();
        let bounds = layout::PAGE_CONTENT;
        for theme in Theme::ALL {
            for scale in [1.0, 2.0] {
                // Traverse every row: all 133 SVGs must actually produce raster handles.
                for row in 0..186_usize.div_ceil(2) {
                    let content = bounds.offset(0.0, -(row as f32 * ROW_STEP));
                    let visible = visible_legacy(&catalog, "", content, bounds);
                    catalog.prepare(&mut renderer, theme, scale, &visible);
                }
                assert_eq!(renderer.image_count(), (176 + 8) * 3);
                assert!(
                    catalog
                        .entries
                        .iter()
                        .all(|e| e.images.iter().all(Option::is_some))
                );
                for (state, query, offset) in [
                    ("all-top", "", 0.0),
                    (
                        "all-bottom",
                        "",
                        extent(
                            &catalog,
                            "",
                            super::super::super::layout::PAGE_CONTENT.size.width,
                        )
                        .height
                            - bounds.size.height,
                    ),
                    ("search", "SeArCh", 0.0),
                    ("empty", "no-such-icon", 0.0),
                ] {
                    let content = bounds.offset(0.0, -offset);
                    let mut text = TextEngine::new();
                    text.set_scale(scale);
                    text.begin_frame();
                    let mut st = StaticText::new(None);
                    let mut ctx = PageCtx {
                        theme,
                        text: &mut text,
                        static_text: &mut st,
                    };
                    let mut scene = Scene::new();
                    scene.push_clip(bounds);
                    // Reuse the actual search surface; only its input state is scripted.
                    let mut search = crate::gallery::text_demo::TextDemo::search_fixture();
                    if !query.is_empty() {
                        search.command("insertTab:");
                        search.paste(query);
                        search.blur();
                    }
                    search.build_search(&mut ctx, search_rect(content), &mut scene);
                    build_catalog(&mut ctx, content, &mut scene, query, &catalog, bounds);
                    scene.pop_clip();
                    let width = (layout::FRAME_W * scale) as u32;
                    let height = (layout::FRAME_H * scale) as u32;
                    let rgba = renderer
                        .render_to_rgba8(
                            &scene,
                            text.atlas_mut(),
                            (width, height),
                            scale,
                            ColorRole::DocumentCanvas.resolve(theme),
                        )
                        .unwrap();
                    let path = out.join(format!(
                        "icons-{state}-{}@{scale}x.png",
                        crate::gallery::theme::theme_slug(theme)
                    ));
                    let mut encoder =
                        png::Encoder::new(std::fs::File::create(path).unwrap(), width, height);
                    encoder.set_color(png::ColorType::Rgba);
                    encoder.set_depth(png::BitDepth::Eight);
                    encoder
                        .write_header()
                        .unwrap()
                        .write_image_data(&rgba)
                        .unwrap();
                }
            }
        }
    }
}
