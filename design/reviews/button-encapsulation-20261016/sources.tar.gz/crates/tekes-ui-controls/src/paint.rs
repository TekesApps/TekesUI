//! Shared token-driven control geometry; clients supply text shaping via their adapter.
use crate::{CheckState, ControlState};
use tekes_ui_scene::{Quad, Rect, Scene};
use tekes_ui_tokens::{Palette, Rgba, proposal};
pub fn color(theme: impl Into<Palette>, role: &str) -> Rgba {
    theme.into().color(role).expect("semantic control role")
}
pub fn surface(scene: &mut Scene, rect: Rect, theme: impl Into<Palette>, panel: bool) {
    let theme = theme.into();
    let mut q = Quad::new(rect, color(theme, "surface-1"))
        .with_corner_radius(proposal::metric("radius", "radius-panel").expect("panel radius"));
    if panel {
        q = q.with_border(
            proposal::metric("stroke", "stroke-rule").expect("panel stroke"),
            color(theme, "separator"),
        );
    }
    scene.push_quad(q);
}
/// Decorative frame, following layout.json hairline policy. Never use this
/// for a necessary control boundary or a focus/selection indicator.
pub fn decorative_border(theme: impl Into<Palette>, backing_scale: f32) -> (f32, Rgba) {
    let theme = theme.into();
    let width = if theme.theme.contrast == tekes_ui_tokens::Contrast::Increased {
        proposal::metric("stroke", "stroke-rule").expect("contrast stroke")
    } else {
        1.0 / if backing_scale.is_finite() && backing_scale > 0.0 {
            backing_scale
        } else {
            1.0
        }
    };
    (width, color(theme, "separator"))
}
pub fn button(
    scene: &mut Scene,
    rect: Rect,
    theme: impl Into<Palette>,
    state: ControlState,
) -> Rgba {
    let theme = theme.into();
    let fill = if state.disabled {
        "surface-2"
    } else if state.selected {
        if state.hovered {
            "row-selection-hover"
        } else {
            "row-selection"
        }
    } else if state.pressed {
        "button-pressed"
    } else if state.hovered {
        "button-hover"
    } else {
        "surface-2"
    };
    let border = if state.error {
        "status-failed"
    } else if state.focused && state.focus_visible {
        "border-focused"
    } else {
        "border"
    };
    scene.push_quad(
        Quad::new(rect, color(theme, fill))
            .with_corner_radius(
                proposal::metric("radius", "radius-control").expect("control radius"),
            )
            .with_border(
                proposal::metric(
                    "stroke",
                    if state.focused && state.focus_visible {
                        "c-focus-width"
                    } else {
                        "stroke-rule"
                    },
                )
                .expect("control stroke"),
                theme
                    .color(border)
                    .unwrap_or_else(|| color(theme, "border")),
            ),
    );
    color(
        theme,
        if state.disabled {
            "tertiary-text"
        } else {
            "primary-text"
        },
    )
}
pub fn checkbox(
    scene: &mut Scene,
    rect: Rect,
    theme: impl Into<Palette>,
    state: ControlState,
    checked: CheckState,
) -> Rgba {
    let theme = theme.into();
    let mut ink = button(scene, rect, theme, state);
    if checked != CheckState::Unchecked && !state.disabled {
        scene.push_quad(
            Quad::new(
                rect,
                color(
                    theme,
                    if state.pressed {
                        "control-checked-pressed"
                    } else if state.hovered {
                        "control-checked-hover"
                    } else {
                        "control-checked-ground"
                    },
                ),
            )
            .with_corner_radius(4.),
        );
        ink = color(theme, "control-checked-mark");
    }
    if checked == CheckState::Mixed {
        scene.push_quad(
            Quad::new(
                Rect::new(
                    rect.min_x() + 4.,
                    rect.center().y - 1.,
                    rect.size.width - 8.,
                    2.,
                ),
                ink,
            )
            .with_corner_radius(1.),
        );
    } else if checked == CheckState::Checked {
        let stroke = proposal::metric("size", "size-icon-artboard-stroke").expect("icon stroke");
        for (a, b) in [((0.20, 0.50), (0.42, 0.72)), ((0.42, 0.72), (0.80, 0.28))] {
            let ax = rect.min_x() + rect.size.width * a.0;
            let ay = rect.min_y() + rect.size.height * a.1;
            let dx = rect.size.width * (b.0 - a.0);
            let dy = rect.size.height * (b.1 - a.1);
            let steps = dx.abs().max(dy.abs()).ceil().max(1.) as usize;
            for n in 0..=steps {
                let t = n as f32 / steps as f32;
                scene.push_quad(
                    Quad::new(Rect::new(ax + dx * t, ay + dy * t, stroke, stroke), ink)
                        .with_corner_radius(stroke / 2.),
                );
            }
        }
    }

    ink
}
pub fn skeleton(scene: &mut Scene, rect: Rect, theme: impl Into<Palette>) {
    scene.push_quad(Quad::new(rect, color(theme, "surface-2")).with_corner_radius(4.));
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum ButtonVariant {
    #[default]
    Quiet,
    Primary,
    /// Quiet action whose resting surface inherits its parent panel.
    Panel,
}
pub fn button_variant(
    scene: &mut Scene,
    rect: Rect,
    theme: impl Into<Palette>,
    state: ControlState,
    variant: ButtonVariant,
) -> Rgba {
    let theme = theme.into();
    if variant == ButtonVariant::Panel {
        let fill = if state.disabled {
            "surface-2"
        } else if state.pressed {
            "button-pressed"
        } else if state.selected {
            if state.hovered {
                "row-selection-hover"
            } else {
                "row-selection"
            }
        } else if state.hovered {
            "button-hover"
        } else {
            "surface-panel"
        };
        let border = if state.error {
            "status-failed"
        } else if state.focused && state.focus_visible {
            "border-focused"
        } else {
            "border"
        };
        scene.push_quad(
            Quad::new(rect, color(theme, fill))
                .with_corner_radius(
                    proposal::metric("radius", "radius-control").expect("control radius"),
                )
                .with_border(
                    proposal::metric(
                        "stroke",
                        if state.focused && state.focus_visible {
                            "c-focus-width"
                        } else {
                            "stroke-rule"
                        },
                    )
                    .expect("control stroke"),
                    theme
                        .color(border)
                        .unwrap_or_else(|| color(theme, "border")),
                ),
        );
        return color(
            theme,
            if state.disabled {
                "tertiary-text"
            } else {
                "primary-text"
            },
        );
    }
    if variant == ButtonVariant::Quiet || state.disabled {
        return button(scene, rect, theme, state);
    }
    let role = if state.pressed {
        "action-primary-pressed"
    } else if state.hovered {
        "action-primary-hover"
    } else {
        "action-primary-ground"
    };
    let ring = if state.focused && state.focus_visible {
        "border-focused"
    } else {
        role
    };
    scene.push_quad(
        Quad::new(rect, color(theme, role))
            .with_corner_radius(
                proposal::metric("radius", "radius-control").expect("control radius"),
            )
            .with_border(
                if state.focused && state.focus_visible {
                    2.
                } else {
                    1.
                },
                color(theme, ring),
            ),
    );
    color(theme, "action-primary-foreground")
}

#[cfg(test)]
mod boundary_tests {
    use super::*;
    use tekes_ui_tokens::{Contrast, Theme};
    #[test]
    fn decorative_frames_follow_scale_and_contrast_without_weakening_controls() {
        for theme in Theme::ALL {
            for scale in [1., 2.] {
                let (width, ink) = decorative_border(theme, scale);
                assert_eq!(
                    width,
                    if theme.contrast == Contrast::Increased {
                        1.
                    } else {
                        1. / scale
                    }
                );
                assert_eq!(ink, color(theme, "separator"));
                let mut scene = Scene::new();
                button(
                    &mut scene,
                    Rect::new(0., 0., 100., 32.),
                    theme,
                    ControlState::default(),
                );
                let tekes_ui_scene::Primitive::Quad(q) = &scene.primitives()[0] else {
                    panic!("control quad")
                };
                assert_eq!(
                    q.border_width,
                    proposal::metric("stroke", "stroke-rule").unwrap()
                );
                assert_eq!(q.border_color, color(theme, "border"));
            }
        }
    }
}
