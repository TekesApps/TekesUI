//! Platform-independent interaction contracts. Rendering and native event translation
//! are adapters; these models are shared by applications and Gallery stories.
use tekes_ui_scene::{Point, Rect, Scene, Size};
use tekes_ui_tokens::{Palette, Rgba, proposal};

/// Button size roles resolve through the JSON Design System token table.
/// `Body` preserves the existing 24pt/12pt application toolbar action metric.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum ButtonSize {
    Xs,
    Sm,
    #[default]
    Md,
    Lg,
    Body,
}

impl ButtonSize {
    fn minimum_height(self) -> f32 {
        match self {
            Self::Xs => proposal::metric("size", "size-button-xs"),
            Self::Sm => proposal::metric("size", "size-button-sm"),
            Self::Md => proposal::metric("size", "size-button-md"),
            Self::Lg => proposal::metric("size", "size-button-lg"),
            Self::Body => proposal::metric("size", "size-action-button"),
        }
        .expect("button minimum size token")
    }

    fn inset(self) -> f32 {
        let name = match self {
            Self::Xs => "space-button-xs-inset",
            Self::Sm => "space-button-sm-inset",
            Self::Md => "space-button-md-inset",
            Self::Lg => "space-button-lg-inset",
            Self::Body => "space-relaxed",
        };
        proposal::metric("spacing", name).expect("button inset token")
    }

    fn vertical_inset(self, role: proposal::TextRole) -> f32 {
        ((self.minimum_height() - role.style().line_height) * 0.5).max(0.0)
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum ButtonTextAlign {
    Leading,
    #[default]
    Center,
}

/// Text shaping and glyph output are supplied by the host; layout and paint
/// remain owned by the production Button component.
pub trait ButtonTextRenderer {
    fn measure(&mut self, text: &str, role: proposal::TextRole, max_width: f32) -> Size;
    fn draw(
        &mut self,
        scene: &mut Scene,
        text: &str,
        role: proposal::TextRole,
        rect: Rect,
        align: ButtonTextAlign,
        ink: Rgba,
    );
}

/// Resolved geometry shared by button paint, text placement and hit testing.
/// `content` is the constrained text slot; it is deliberately the same width
/// used for shaping so the host cannot accidentally wrap at a second width.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ButtonLayout {
    pub frame: Rect,
    pub content: Rect,
    /// Visible hit and text clip after intersecting the ancestor clip.
    pub visible: Option<Rect>,
    /// Shaped extent returned by the host text backend.
    pub label_size: Size,
}

impl ButtonLayout {
    fn resolve(
        frame: Rect,
        clip: Option<Rect>,
        label_size: Size,
        size: ButtonSize,
        role: proposal::TextRole,
        align: ButtonTextAlign,
    ) -> Self {
        let horizontal_inset = size.inset();
        let vertical_inset = size.vertical_inset(role);
        let label_size = Size::new(
            finite_nonnegative(label_size.width),
            finite_nonnegative(label_size.height),
        );
        let label_height = finite_nonnegative(label_size.height);
        let min_height = size.minimum_height();
        let height = frame
            .size
            .height
            .max(min_height)
            .max(label_height + vertical_inset * 2.0);
        let frame = Rect::new(frame.min_x(), frame.min_y(), frame.size.width, height);
        let content_width = (frame.size.width - horizontal_inset * 2.0).max(0.0);
        let content_height = label_height.min((frame.size.height - vertical_inset * 2.0).max(0.0));
        let content_x = match align {
            ButtonTextAlign::Leading | ButtonTextAlign::Center => frame.min_x() + horizontal_inset,
        };
        let content = Rect::new(
            content_x,
            frame.center().y - content_height * 0.5,
            content_width,
            content_height,
        );
        let visible = clip.map_or(Some(frame), |clip| frame.intersection(&clip));
        Self {
            frame,
            content,
            visible,
            label_size,
        }
    }

    fn empty() -> Self {
        Self {
            frame: Rect::default(),
            content: Rect::default(),
            visible: None,
            label_size: Size::default(),
        }
    }

    pub fn hit_test(&self, point: Point) -> bool {
        self.visible.is_some_and(|rect| rect.contains(point))
    }
}

fn finite_nonnegative(value: f32) -> f32 {
    if value.is_finite() {
        value.max(0.0)
    } else {
        0.0
    }
}

fn valid_frame(frame: Rect) -> bool {
    frame.min_x().is_finite()
        && frame.min_y().is_finite()
        && frame.size.width.is_finite()
        && frame.size.height.is_finite()
        && frame.max_x().is_finite()
        && frame.max_y().is_finite()
        && frame.size.width > 0.0
        && frame.size.height >= 0.0
}

fn valid_clip(clip: Rect) -> bool {
    clip.min_x().is_finite()
        && clip.min_y().is_finite()
        && clip.size.width.is_finite()
        && clip.size.height.is_finite()
        && clip.max_x().is_finite()
        && clip.max_y().is_finite()
        && clip.size.width > 0.0
        && clip.size.height > 0.0
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ControlKey {
    Enter,
    Space,
    Left,
    Right,
    Up,
    Down,
    Home,
    End,
    Escape,
    Tab { reverse: bool },
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct ControlState {
    pub hovered: bool,
    pub pressed: bool,
    pub focused: bool,
    pub focus_visible: bool,
    pub disabled: bool,
    pub loading: bool,
    pub selected: bool,
    pub error: bool,
}
#[derive(Clone, Debug, Default)]
pub struct Button {
    pub state: ControlState,
    arm: ButtonArm,
    placement: Option<ButtonLayout>,
    last_pointer: Option<Point>,
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
enum ButtonArm {
    #[default]
    None,
    Pointer,
    Space,
}
impl Button {
    /// Measure the natural outer button size under an outer width constraint.
    /// The result includes token-driven horizontal and vertical insets and the
    /// button size role's minimum height.
    pub fn measure(
        text: &mut impl ButtonTextRenderer,
        label: &str,
        max_width: f32,
        size: ButtonSize,
        role: proposal::TextRole,
    ) -> Size {
        let inset = size.inset();
        let vertical_inset = size.vertical_inset(role);
        let max_width = if max_width.is_finite() {
            max_width.max(0.0)
        } else {
            f32::MAX
        };
        let label_size = if label.is_empty() {
            Size::default()
        } else {
            text.measure(label, role, (max_width - inset * 2.0).max(0.0))
        };
        Size::new(
            if label.is_empty() {
                (inset * 2.0).min(max_width)
            } else {
                (finite_nonnegative(label_size.width) + inset * 2.0).min(max_width)
            },
            size.minimum_height()
                .max(finite_nonnegative(label_size.height) + vertical_inset * 2.0),
        )
    }

    /// Lay out and paint the complete button, including its label. The host
    /// supplies text shaping and glyph output through `ButtonTextRenderer`.
    #[allow(clippy::too_many_arguments)]
    pub fn render(
        &mut self,
        scene: &mut Scene,
        text: &mut impl ButtonTextRenderer,
        label: &str,
        frame: Rect,
        clip: Option<Rect>,
        palette: impl Into<Palette>,
        variant: crate::paint::ButtonVariant,
        size: ButtonSize,
        role: proposal::TextRole,
        align: ButtonTextAlign,
    ) -> ButtonLayout {
        if self.state.disabled || self.state.loading {
            self.cancel();
        } else if !self.state.focused && self.arm == ButtonArm::Space {
            // A controlled focus transition can happen between key-down and
            // key-up. Do not let the stale Space arm activate after focus is
            // restored; pointer capture remains independent of focus.
            self.cancel();
        }
        if !valid_frame(frame) || clip.is_some_and(|clip| !valid_clip(clip)) {
            self.placement = Some(ButtonLayout::empty());
            self.cancel();
            self.last_pointer = None;
            self.state.hovered = false;
            return ButtonLayout::empty();
        }
        let palette = palette.into();
        let inset = size.inset();
        let max_width = (frame.size.width - inset * 2.0).max(0.0);
        let label_size = if label.is_empty() {
            Size::default()
        } else {
            text.measure(label, role, max_width)
        };
        let layout = ButtonLayout::resolve(frame, clip, label_size, size, role, align);
        self.placement = Some(layout);
        self.refresh_pointer_state();

        if let Some(visible) = layout.visible {
            scene.push_clip(visible);
            let ink =
                crate::paint::button_variant(scene, layout.frame, palette, self.state, variant);
            if !label.is_empty() && !layout.content.is_empty() {
                text.draw(scene, label, role, layout.content, align, ink);
            }
            scene.pop_clip();
        }
        layout
    }

    pub fn layout(&self) -> Option<ButtonLayout> {
        self.placement
    }

    pub fn clear_layout(&mut self) {
        self.placement = None;
        self.cancel();
        self.last_pointer = None;
        self.state.hovered = false;
    }

    pub fn pointer_move_at(&mut self, point: Point) {
        self.last_pointer = Some(point);
        self.refresh_pointer_state();
    }

    fn refresh_pointer_state(&mut self) {
        let Some(point) = self.last_pointer else {
            return;
        };
        let inside = self.placement.is_some_and(|layout| layout.hit_test(point));
        self.state.hovered = inside && !self.state.disabled && !self.state.loading;
        if self.arm == ButtonArm::Pointer {
            self.state.pressed = self.state.hovered;
        }
    }

    pub fn pointer_down_at(&mut self, point: Point) -> bool {
        if !self.placement.is_some_and(|layout| layout.hit_test(point)) {
            self.pointer_move_at(point);
            return false;
        }
        self.pointer_move_at(point);
        self.pointer_down();
        self.arm == ButtonArm::Pointer
    }

    pub fn pointer_up_at(&mut self, point: Point) -> bool {
        self.last_pointer = Some(point);
        let inside = self.placement.is_some_and(|layout| layout.hit_test(point));
        let activated = self.pointer_up(inside);
        self.state.hovered = inside && !self.state.disabled && !self.state.loading;
        activated
    }

    pub fn pointer_down(&mut self) {
        if self.arm != ButtonArm::None {
            return;
        }
        let armed = !self.state.disabled && !self.state.loading;
        self.arm = if armed {
            ButtonArm::Pointer
        } else {
            ButtonArm::None
        };
        self.state.pressed = armed;
        self.state.focused = armed;
        self.state.focus_visible = false;
    }
    pub fn pointer_up(&mut self, inside: bool) -> bool {
        if self.arm != ButtonArm::Pointer {
            return false;
        }
        let activated = inside && !self.state.disabled && !self.state.loading;
        self.cancel();
        activated
    }
    pub fn cancel(&mut self) {
        self.arm = ButtonArm::None;
        self.state.pressed = false;
    }

    /// Cancel only an active pointer press, preserving a keyboard Space press.
    pub fn cancel_pointer(&mut self) {
        if self.arm == ButtonArm::Pointer {
            self.cancel();
        }
    }

    /// Cancel active activation when the owning focus scope loses focus.
    pub fn blur(&mut self) {
        self.cancel();
        self.last_pointer = None;
        self.state.focused = false;
        self.state.focus_visible = false;
        self.state.hovered = false;
    }

    pub fn key(&mut self, key: ControlKey, down: bool) -> bool {
        if self.state.disabled || self.state.loading {
            self.cancel();
            return false;
        }
        if !self.state.focused {
            if self.arm == ButtonArm::Space {
                self.cancel();
            }
            return false;
        }
        match key {
            ControlKey::Enter => down,
            ControlKey::Space => {
                if down {
                    if self.arm != ButtonArm::None {
                        return false;
                    }
                    self.arm = ButtonArm::Space;
                    self.state.pressed = true;
                    false
                } else {
                    if self.arm != ButtonArm::Space {
                        return false;
                    }
                    self.cancel();
                    true
                }
            }
            _ => false,
        }
    }
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum CheckState {
    #[default]
    Unchecked,
    Checked,
    Mixed,
}
#[derive(Clone, Debug, Default)]
pub struct Checkbox {
    pub button: Button,
    pub checked: CheckState,
}
impl Checkbox {
    pub fn toggle(&mut self) -> bool {
        if self.button.state.disabled || self.button.state.loading {
            return false;
        }
        self.checked = if self.checked == CheckState::Checked {
            CheckState::Unchecked
        } else {
            CheckState::Checked
        };
        true
    }
}
#[derive(Clone, Debug)]
pub struct Tabs {
    pub selected: usize,
    pub count: usize,
}
impl Tabs {
    pub fn new(count: usize) -> Self {
        Self { selected: 0, count }
    }
    pub fn select(&mut self, i: usize) -> bool {
        if i >= self.count || i == self.selected {
            return false;
        }
        self.selected = i;
        true
    }
    pub fn key(&mut self, key: ControlKey) -> bool {
        if self.count == 0 {
            return false;
        }
        let n = match key {
            ControlKey::Left => (self.selected + self.count - 1) % self.count,
            ControlKey::Right => (self.selected + 1) % self.count,
            ControlKey::Home => 0,
            ControlKey::End => self.count - 1,
            _ => return false,
        };
        self.select(n)
    }
}
#[derive(Clone, Debug)]
pub struct Menu {
    pub open: bool,
    pub items: Tabs,
    pub last_action: Option<usize>,
}
impl Menu {
    pub fn new(count: usize) -> Self {
        Self {
            open: false,
            items: Tabs::new(count),
            last_action: None,
        }
    }
    pub fn show(&mut self) {
        self.open = true;
        self.items.selected = 0;
    }
    pub fn key(&mut self, key: ControlKey) -> Option<usize> {
        if !self.open {
            return None;
        }
        match key {
            ControlKey::Escape => self.open = false,
            ControlKey::Enter | ControlKey::Space if self.items.count > 0 => {
                let i = self.items.selected;
                self.last_action = Some(i);
                self.open = false;
                return Some(i);
            }
            ControlKey::Up => {
                self.items.key(ControlKey::Left);
            }
            ControlKey::Down => {
                self.items.key(ControlKey::Right);
            }
            ControlKey::Home | ControlKey::End => {
                self.items.key(key);
            }
            _ => {}
        }
        None
    }
}
#[derive(Clone, Debug, Default)]
pub struct Dialog {
    pub open: bool,
    pub focus: usize,
    return_focus: Option<usize>,
}
impl Dialog {
    pub fn show(&mut self, invoker: usize) {
        self.open = true;
        self.focus = 0;
        self.return_focus = Some(invoker);
    }
    pub fn close(&mut self) -> Option<usize> {
        self.open = false;
        self.return_focus.take()
    }
    pub fn tab(&mut self, reverse: bool, count: usize) {
        if self.open && count > 0 {
            self.focus = if reverse {
                (self.focus + count - 1) % count
            } else {
                (self.focus + 1) % count
            };
        }
    }
}
#[derive(Clone, Debug)]
pub struct Select {
    pub menu: Menu,
    pub selected: usize,
}
impl Select {
    pub fn new(count: usize) -> Self {
        Self {
            menu: Menu::new(count),
            selected: 0,
        }
    }
    pub fn choose(&mut self, i: usize) -> bool {
        if i >= self.menu.items.count {
            return false;
        }
        self.selected = i;
        self.menu.open = false;
        true
    }
}
#[derive(Clone, Copy, Debug)]
pub struct NumberField {
    value: f64,
    min: f64,
    max: f64,
    step: f64,
}
impl NumberField {
    pub fn new(value: f64, min: f64, max: f64, step: f64) -> Option<Self> {
        if ![value, min, max, step].iter().all(|v| v.is_finite()) || min > max || step <= 0.0 {
            return None;
        }
        Some(Self {
            value: value.clamp(min, max),
            min,
            max,
            step,
        })
    }
    pub fn value(self) -> f64 {
        self.value
    }
    pub fn set(&mut self, value: f64) -> bool {
        if !value.is_finite() {
            return false;
        }
        let next = value.clamp(self.min, self.max);
        let changed = next != self.value;
        self.value = next;
        changed
    }
    pub fn increment(&mut self, up: bool) -> bool {
        self.set(self.value + if up { self.step } else { -self.step })
    }
}
/// Semantic field metadata, separate from the input's editing model.
#[derive(Clone, Debug, Default)]
pub struct Field {
    pub label: String,
    pub help: String,
    pub error: Option<String>,
    pub required: bool,
}
impl Field {
    pub fn message(&self) -> &str {
        self.error.as_deref().unwrap_or(&self.help)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tekes_ui_scene::Primitive;
    use tekes_ui_tokens::{Theme, proposal};

    struct FixedText {
        measured: Size,
        drawn: Option<(Rect, ButtonTextAlign)>,
    }

    impl ButtonTextRenderer for FixedText {
        fn measure(&mut self, _text: &str, _role: proposal::TextRole, max_width: f32) -> Size {
            Size::new(self.measured.width.min(max_width), self.measured.height)
        }

        fn draw(
            &mut self,
            _scene: &mut Scene,
            _text: &str,
            _role: proposal::TextRole,
            rect: Rect,
            align: ButtonTextAlign,
            _ink: Rgba,
        ) {
            self.drawn = Some((rect, align));
        }
    }

    #[test]
    fn rendered_button_owns_large_text_layout_clipping_and_hit_geometry() {
        let mut button = Button::default();
        let mut text = FixedText {
            measured: Size::new(88.0, 54.0),
            drawn: None,
        };
        let mut scene = Scene::new();
        let layout = button.render(
            &mut scene,
            &mut text,
            "Large label",
            Rect::new(10.0, 20.0, 140.0, 32.0),
            Some(Rect::new(0.0, 30.0, 300.0, 100.0)),
            Theme::LIGHT,
            crate::paint::ButtonVariant::Quiet,
            ButtonSize::Md,
            proposal::TextRole::UiBody,
            ButtonTextAlign::Center,
        );

        assert!(
            layout.frame.size.height
                >= 54.0 + ButtonSize::Md.vertical_inset(proposal::TextRole::UiBody) * 2.0
        );
        assert_eq!(button.layout(), Some(layout));
        assert_eq!(
            layout.visible,
            Some(Rect::new(
                10.0,
                30.0,
                140.0,
                layout.frame.size.height - 10.0
            ))
        );
        assert!(layout.hit_test(Point::new(20.0, 31.0)));
        assert!(!layout.hit_test(Point::new(20.0, 29.0)));
        assert_eq!(text.drawn, Some((layout.content, ButtonTextAlign::Center)));
        assert!(
            scene
                .primitives()
                .iter()
                .any(|primitive| matches!(primitive, Primitive::PushClip(_)))
        );
    }

    #[test]
    fn button_measure_keeps_legacy_height_at_default_text_and_expands_for_large_text() {
        let mut text = FixedText {
            measured: Size::new(80.0, proposal::TextRole::ButtonXs.style().line_height),
            drawn: None,
        };
        let default = Button::measure(
            &mut text,
            "Motion action",
            160.0,
            ButtonSize::Xs,
            proposal::TextRole::ButtonXs,
        );
        assert_eq!(
            default.height,
            ButtonSize::Xs.minimum_height().max(
                proposal::TextRole::ButtonXs.style().line_height
                    + ButtonSize::Xs.vertical_inset(proposal::TextRole::ButtonXs) * 2.0
            )
        );
        text.measured.height = proposal::TextRole::ButtonXs.style().line_height * 1.5;
        let large = Button::measure(
            &mut text,
            "Motion action",
            160.0,
            ButtonSize::Xs,
            proposal::TextRole::ButtonXs,
        );
        assert!(large.height > default.height);
        assert!(large.width <= 160.0);
    }

    #[test]
    fn invalid_geometry_and_empty_labels_never_emit_invalid_or_unclipped_text() {
        let mut button = Button::default();
        let mut text = FixedText {
            measured: Size::new(f32::NAN, f32::INFINITY),
            drawn: None,
        };
        let mut scene = Scene::new();
        let invalid = button.render(
            &mut scene,
            &mut text,
            "Invalid",
            Rect::new(f32::NAN, 0.0, 0.0, 20.0),
            None,
            Theme::LIGHT,
            crate::paint::ButtonVariant::Quiet,
            ButtonSize::Xs,
            proposal::TextRole::ButtonXs,
            ButtonTextAlign::Center,
        );
        assert_eq!(invalid.visible, None);
        assert!(scene.is_empty());

        let empty = button.render(
            &mut scene,
            &mut text,
            "",
            Rect::new(10.0, 10.0, 60.0, 26.0),
            None,
            Theme::LIGHT,
            crate::paint::ButtonVariant::Quiet,
            ButtonSize::Xs,
            proposal::TextRole::ButtonXs,
            ButtonTextAlign::Center,
        );
        assert!(empty.frame.min_x().is_finite());
        assert!(empty.frame.size.width.is_finite());
        assert!(text.drawn.is_none());
    }

    #[test]
    fn button_point_interaction_uses_clipped_placement_and_cancels_outside_release() {
        let mut button = Button::default();
        let mut text = FixedText {
            measured: Size::new(40.0, 16.0),
            drawn: None,
        };
        button.render(
            &mut Scene::new(),
            &mut text,
            "Action",
            Rect::new(10.0, 20.0, 100.0, 32.0),
            Some(Rect::new(10.0, 20.0, 50.0, 32.0)),
            Theme::LIGHT,
            crate::paint::ButtonVariant::Panel,
            ButtonSize::Xs,
            proposal::TextRole::ButtonXs,
            ButtonTextAlign::Leading,
        );
        assert!(!button.pointer_down_at(Point::new(70.0, 30.0)));
        assert!(button.pointer_down_at(Point::new(20.0, 30.0)));
        assert!(button.state.pressed);
        button.pointer_move_at(Point::new(70.0, 30.0));
        assert!(!button.state.pressed);
        assert!(!button.pointer_up_at(Point::new(70.0, 30.0)));
        assert!(!button.state.pressed);
        assert!(!button.pointer_up_at(Point::new(20.0, 30.0)));
        button.clear_layout();
        assert_eq!(button.layout(), None);
    }

    #[test]
    fn stationary_pointer_rehits_after_layout_translation_and_restoration() {
        let mut button = Button::default();
        let mut text = FixedText {
            measured: Size::new(40.0, 16.0),
            drawn: None,
        };
        let mut scene = Scene::new();
        let render = |button: &mut Button,
                      frame: Rect,
                      clip: Option<Rect>,
                      text: &mut FixedText,
                      scene: &mut Scene| {
            button.render(
                scene,
                text,
                "Animated",
                frame,
                clip,
                Theme::LIGHT,
                crate::paint::ButtonVariant::Quiet,
                ButtonSize::Xs,
                proposal::TextRole::ButtonXs,
                ButtonTextAlign::Center,
            );
        };

        render(
            &mut button,
            Rect::new(10.0, 10.0, 100.0, 30.0),
            None,
            &mut text,
            &mut scene,
        );
        assert!(button.pointer_down_at(Point::new(20.0, 20.0)));
        assert!(button.state.hovered && button.state.pressed);

        render(
            &mut button,
            Rect::new(120.0, 10.0, 100.0, 30.0),
            None,
            &mut text,
            &mut scene,
        );
        assert!(!button.state.hovered && !button.state.pressed);

        render(
            &mut button,
            Rect::new(10.0, 10.0, 100.0, 30.0),
            None,
            &mut text,
            &mut scene,
        );
        assert!(button.state.hovered && button.state.pressed);
        assert!(button.pointer_up_at(Point::new(20.0, 20.0)));
    }

    #[test]
    fn stationary_pointer_hover_tracks_new_ancestor_clip() {
        let mut button = Button::default();
        let mut text = FixedText {
            measured: Size::new(40.0, 16.0),
            drawn: None,
        };
        let mut scene = Scene::new();
        let frame = Rect::new(10.0, 10.0, 100.0, 30.0);
        let render = |button: &mut Button, clip, text: &mut FixedText, scene: &mut Scene| {
            button.render(
                scene,
                text,
                "Clipped",
                frame,
                clip,
                Theme::LIGHT,
                crate::paint::ButtonVariant::Quiet,
                ButtonSize::Xs,
                proposal::TextRole::ButtonXs,
                ButtonTextAlign::Center,
            );
        };
        render(&mut button, None, &mut text, &mut scene);
        button.pointer_move_at(Point::new(20.0, 20.0));
        assert!(button.state.hovered);
        render(
            &mut button,
            Some(Rect::new(50.0, 10.0, 60.0, 30.0)),
            &mut text,
            &mut scene,
        );
        assert!(!button.state.hovered);
        render(
            &mut button,
            Some(Rect::new(10.0, 10.0, 100.0, 30.0)),
            &mut text,
            &mut scene,
        );
        assert!(button.state.hovered);
    }

    #[test]
    fn leading_and_centered_label_positions_are_component_owned() {
        let mut leading = Button::default();
        let mut centered = Button::default();
        for (button, align) in [
            (&mut leading, ButtonTextAlign::Leading),
            (&mut centered, ButtonTextAlign::Center),
        ] {
            let mut text = FixedText {
                measured: Size::new(40.0, 16.0),
                drawn: None,
            };
            button.render(
                &mut Scene::new(),
                &mut text,
                "Label",
                Rect::new(10.0, 20.0, 140.0, 32.0),
                None,
                Theme::LIGHT,
                crate::paint::ButtonVariant::Panel,
                ButtonSize::Body,
                proposal::TextRole::UiBody,
                align,
            );
            let (drawn, actual_align) = text.drawn.unwrap();
            assert_eq!(actual_align, align);
            assert_eq!(drawn.min_x(), 22.0);
            assert_eq!(drawn.size.width, 140.0 - ButtonSize::Body.inset() * 2.0);
        }
    }

    #[test]
    fn button_release_contract_and_disabled_loading() {
        let mut b = Button::default();
        b.pointer_down();
        assert!(!b.pointer_up(false));
        b.pointer_down();
        assert!(b.pointer_up(true));
        assert!(!b.pointer_up(true));
        b.state.focused = true;
        assert!(!b.key(ControlKey::Space, true));
        assert!(b.key(ControlKey::Space, false));
        for loading in [false, true] {
            b.state.loading = loading;
            b.state.disabled = !loading;
            b.pointer_down();
            assert!(!b.pointer_up(true));
            assert!(!b.key(ControlKey::Enter, true));
        }
    }

    #[test]
    fn keyboard_and_pointer_arms_cannot_release_or_activate_each_other() {
        let mut button = Button::default();
        button.state.focused = true;
        assert!(!button.key(ControlKey::Space, true));
        assert!(!button.key(ControlKey::Space, true)); // key repeat does not re-arm
        assert!(button.state.pressed);
        assert!(!button.pointer_up(true));
        assert!(button.state.pressed);
        assert!(button.key(ControlKey::Space, false));
        assert!(!button.key(ControlKey::Space, false)); // one activation per press

        button.pointer_down();
        assert!(!button.key(ControlKey::Space, false));
        assert!(button.state.pressed);
        assert!(button.pointer_up(true));

        button.state.focused = true;
        assert!(!button.key(ControlKey::Space, true));
        button.blur();
        assert!(!button.key(ControlKey::Space, false));
        assert!(!button.state.pressed);

        button.state.focused = true;
        assert!(!button.key(ControlKey::Space, true));
        button.state.disabled = true;
        assert!(!button.key(ControlKey::Space, false));
        assert!(!button.state.pressed);

        button.state.disabled = false;
        button.pointer_down();
        button.state.loading = true;
        assert!(!button.pointer_up(true));
        assert!(!button.state.pressed);
    }

    #[test]
    fn pointer_cancellation_preserves_keyboard_space_arm() {
        let mut button = Button::default();
        button.state.focused = true;
        assert!(!button.key(ControlKey::Space, true));
        button.cancel_pointer();
        assert!(button.state.pressed);
        assert!(button.key(ControlKey::Space, false));

        button.pointer_down();
        assert!(button.state.pressed);
        button.cancel_pointer();
        assert!(!button.state.pressed);
        assert!(!button.pointer_up(true));
    }

    #[test]
    fn render_cancels_pointer_and_space_arms_when_disabled_or_loading() {
        let mut button = Button::default();
        let mut text = FixedText {
            measured: Size::new(40.0, 16.0),
            drawn: None,
        };
        let frame = Rect::new(10.0, 10.0, 100.0, 30.0);
        let render = |button: &mut Button, text: &mut FixedText| {
            button.render(
                &mut Scene::new(),
                text,
                "Action",
                frame,
                None,
                Theme::LIGHT,
                crate::paint::ButtonVariant::Quiet,
                ButtonSize::Xs,
                proposal::TextRole::ButtonXs,
                ButtonTextAlign::Center,
            );
        };

        render(&mut button, &mut text);
        for loading in [false, true] {
            button.state.disabled = false;
            button.state.loading = false;
            render(&mut button, &mut text);
            assert!(button.pointer_down_at(Point::new(20.0, 20.0)));
            button.state.disabled = !loading;
            button.state.loading = loading;
            render(&mut button, &mut text);
            button.state.disabled = false;
            button.state.loading = false;
            render(&mut button, &mut text);
            assert!(!button.pointer_up_at(Point::new(20.0, 20.0)));

            button.state.focused = true;
            assert!(!button.key(ControlKey::Space, true));
            button.state.disabled = !loading;
            button.state.loading = loading;
            render(&mut button, &mut text);
            button.state.disabled = false;
            button.state.loading = false;
            render(&mut button, &mut text);
            assert!(!button.key(ControlKey::Space, false));
            assert!(!button.state.pressed);
        }
    }

    #[test]
    fn render_cancels_space_arm_when_controlled_focus_is_lost() {
        let mut button = Button::default();
        let mut text = FixedText {
            measured: Size::new(40.0, 16.0),
            drawn: None,
        };
        let render = |button: &mut Button, text: &mut FixedText| {
            button.render(
                &mut Scene::new(),
                text,
                "Action",
                Rect::new(10.0, 10.0, 100.0, 30.0),
                None,
                Theme::LIGHT,
                crate::paint::ButtonVariant::Quiet,
                ButtonSize::Xs,
                proposal::TextRole::ButtonXs,
                ButtonTextAlign::Center,
            );
        };
        button.state.focused = true;
        assert!(!button.key(ControlKey::Space, true));
        button.state.focused = false;
        render(&mut button, &mut text);
        button.state.focused = true;
        render(&mut button, &mut text);
        assert!(!button.key(ControlKey::Space, false));
        assert!(!button.state.pressed);
    }
    #[test]
    fn mixed_checkbox_and_disabled_combination() {
        let mut c = Checkbox {
            checked: CheckState::Mixed,
            ..Default::default()
        };
        assert!(c.toggle());
        assert_eq!(c.checked, CheckState::Checked);
        c.button.state.disabled = true;
        assert!(!c.toggle());
        assert_eq!(c.checked, CheckState::Checked);
    }
    #[test]
    fn tab_menu_boundaries_and_escape() {
        let mut t = Tabs::new(3);
        t.key(ControlKey::Left);
        assert_eq!(t.selected, 2);
        t.key(ControlKey::Home);
        assert_eq!(t.selected, 0);
        let mut m = Menu::new(3);
        m.show();
        m.key(ControlKey::Down);
        assert_eq!(m.key(ControlKey::Enter), Some(1));
        assert!(!m.open);
        m.show();
        m.key(ControlKey::Escape);
        assert!(!m.open);
        assert!(!Tabs::new(0).key(ControlKey::End));
    }
    #[test]
    fn modal_traps_focus_and_restores_invoker() {
        let mut d = Dialog::default();
        d.show(7);
        d.tab(true, 2);
        assert_eq!(d.focus, 1);
        d.tab(false, 2);
        assert_eq!(d.focus, 0);
        assert_eq!(d.close(), Some(7));
        assert_eq!(d.close(), None);
    }
    #[test]
    fn numeric_clamps_and_rejects_invalid_values() {
        assert!(NumberField::new(0., 1., 0., 1.).is_none());
        let mut n = NumberField::new(99., 0., 10., 1.).unwrap();
        assert_eq!(n.value(), 10.);
        assert!(!n.increment(true));
        assert!(n.increment(false));
        assert!(!n.set(f64::NAN));
        assert_eq!(n.value(), 9.);
    }
}
/// Toolbar geometry is shared by clients; narrow bounds wrap rather than overflow.
#[derive(Clone, Copy, Debug, Default)]
pub struct Toolbar;
impl Toolbar {
    pub fn layout(
        bounds: tekes_ui_scene::Rect,
        count: usize,
        gap: f32,
    ) -> Vec<tekes_ui_scene::Rect> {
        if count == 0 {
            return Vec::new();
        }
        let width = ((bounds.size.width - gap * (count - 1) as f32) / count as f32).max(0.);
        (0..count)
            .map(|i| {
                tekes_ui_scene::Rect::new(
                    bounds.min_x() + i as f32 * (width + gap),
                    bounds.min_y(),
                    width,
                    bounds.size.height,
                )
            })
            .collect()
    }
}
