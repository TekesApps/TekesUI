//! Immutable semantic environment. Presets are outputs of the existing brand compiler,
//! never a second hand-authored color ramp. Reference (0) keeps the consumer bundle.
use crate::{Rgba, Theme, proposal};
include!(concat!(env!("OUT_DIR"), "/brand_colors.rs"));
#[derive(Clone, Copy, Debug)]
pub struct Palette {
    pub theme: Theme,
    pub brand: usize,
}
impl From<Theme> for Palette {
    fn from(theme: Theme) -> Self {
        Self { theme, brand: 0 }
    }
}
impl Palette {
    pub fn color(self, role: &str) -> Option<Rgba> {
        let base = proposal::render_color(role, self.theme)?;
        if self.brand == 0 {
            return Some(base);
        }
        let index = Theme::ALL.iter().position(|t| *t == self.theme)?;
        let mut color = brand_color(self.brand, role, index).unwrap_or(base);
        color.a = base.a;
        Some(color)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn presets_change_semantic_actions_but_keep_neutral_text() {
        for theme in Theme::ALL {
            let a = Palette { theme, brand: 1 };
            let b = Palette { theme, brand: 2 };
            assert_ne!(
                a.color("action-primary-ground"),
                b.color("action-primary-ground")
            );
            assert_eq!(a.color("primary-text"), b.color("primary-text"));
            assert_eq!(
                a.color("scrim").unwrap().a,
                proposal::render_color("scrim", theme).unwrap().a
            );
        }
    }
}
