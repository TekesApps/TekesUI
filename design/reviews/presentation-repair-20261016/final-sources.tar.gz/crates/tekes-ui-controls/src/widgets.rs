//! Platform-independent interaction contracts. Rendering and native event translation
//! are adapters; these models are shared by applications and Gallery stories.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ControlKey {
    Enter,
    Space,
    Left,
    Right,
    Up,
    Down,
    Home,
    End,
    Escape,
    Tab { reverse: bool },
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct ControlState {
    pub hovered: bool,
    pub pressed: bool,
    pub focused: bool,
    pub focus_visible: bool,
    pub disabled: bool,
    pub loading: bool,
    pub selected: bool,
    pub error: bool,
}
#[derive(Clone, Debug, Default)]
pub struct Button {
    pub state: ControlState,
    armed: bool,
}
impl Button {
    pub fn pointer_down(&mut self) {
        self.armed = !self.state.disabled && !self.state.loading;
        self.state.pressed = self.armed;
        self.state.focused = self.armed;
        self.state.focus_visible = false;
    }
    pub fn pointer_up(&mut self, inside: bool) -> bool {
        let activated = self.armed && inside && !self.state.disabled && !self.state.loading;
        self.cancel();
        activated
    }
    pub fn cancel(&mut self) {
        self.armed = false;
        self.state.pressed = false;
    }
    pub fn key(&mut self, key: ControlKey, down: bool) -> bool {
        if !self.state.focused || self.state.disabled || self.state.loading {
            self.cancel();
            return false;
        }
        match key {
            ControlKey::Enter => down,
            ControlKey::Space => {
                if down {
                    self.armed = true;
                    self.state.pressed = true;
                    false
                } else {
                    self.pointer_up(true)
                }
            }
            _ => false,
        }
    }
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum CheckState {
    #[default]
    Unchecked,
    Checked,
    Mixed,
}
#[derive(Clone, Debug, Default)]
pub struct Checkbox {
    pub button: Button,
    pub checked: CheckState,
}
impl Checkbox {
    pub fn toggle(&mut self) -> bool {
        if self.button.state.disabled || self.button.state.loading {
            return false;
        }
        self.checked = if self.checked == CheckState::Checked {
            CheckState::Unchecked
        } else {
            CheckState::Checked
        };
        true
    }
}
#[derive(Clone, Debug)]
pub struct Tabs {
    pub selected: usize,
    pub count: usize,
}
impl Tabs {
    pub fn new(count: usize) -> Self {
        Self { selected: 0, count }
    }
    pub fn select(&mut self, i: usize) -> bool {
        if i >= self.count || i == self.selected {
            return false;
        }
        self.selected = i;
        true
    }
    pub fn key(&mut self, key: ControlKey) -> bool {
        if self.count == 0 {
            return false;
        }
        let n = match key {
            ControlKey::Left => (self.selected + self.count - 1) % self.count,
            ControlKey::Right => (self.selected + 1) % self.count,
            ControlKey::Home => 0,
            ControlKey::End => self.count - 1,
            _ => return false,
        };
        self.select(n)
    }
}
#[derive(Clone, Debug)]
pub struct Menu {
    pub open: bool,
    pub items: Tabs,
    pub last_action: Option<usize>,
}
impl Menu {
    pub fn new(count: usize) -> Self {
        Self {
            open: false,
            items: Tabs::new(count),
            last_action: None,
        }
    }
    pub fn show(&mut self) {
        self.open = true;
        self.items.selected = 0;
    }
    pub fn key(&mut self, key: ControlKey) -> Option<usize> {
        if !self.open {
            return None;
        }
        match key {
            ControlKey::Escape => self.open = false,
            ControlKey::Enter | ControlKey::Space if self.items.count > 0 => {
                let i = self.items.selected;
                self.last_action = Some(i);
                self.open = false;
                return Some(i);
            }
            ControlKey::Up => {
                self.items.key(ControlKey::Left);
            }
            ControlKey::Down => {
                self.items.key(ControlKey::Right);
            }
            ControlKey::Home | ControlKey::End => {
                self.items.key(key);
            }
            _ => {}
        }
        None
    }
}
#[derive(Clone, Debug, Default)]
pub struct Dialog {
    pub open: bool,
    pub focus: usize,
    return_focus: Option<usize>,
}
impl Dialog {
    pub fn show(&mut self, invoker: usize) {
        self.open = true;
        self.focus = 0;
        self.return_focus = Some(invoker);
    }
    pub fn close(&mut self) -> Option<usize> {
        self.open = false;
        self.return_focus.take()
    }
    pub fn tab(&mut self, reverse: bool, count: usize) {
        if self.open && count > 0 {
            self.focus = if reverse {
                (self.focus + count - 1) % count
            } else {
                (self.focus + 1) % count
            };
        }
    }
}
#[derive(Clone, Debug)]
pub struct Select {
    pub menu: Menu,
    pub selected: usize,
}
impl Select {
    pub fn new(count: usize) -> Self {
        Self {
            menu: Menu::new(count),
            selected: 0,
        }
    }
    pub fn choose(&mut self, i: usize) -> bool {
        if i >= self.menu.items.count {
            return false;
        }
        self.selected = i;
        self.menu.open = false;
        true
    }
}
#[derive(Clone, Copy, Debug)]
pub struct NumberField {
    value: f64,
    min: f64,
    max: f64,
    step: f64,
}
impl NumberField {
    pub fn new(value: f64, min: f64, max: f64, step: f64) -> Option<Self> {
        if ![value, min, max, step].iter().all(|v| v.is_finite()) || min > max || step <= 0.0 {
            return None;
        }
        Some(Self {
            value: value.clamp(min, max),
            min,
            max,
            step,
        })
    }
    pub fn value(self) -> f64 {
        self.value
    }
    pub fn set(&mut self, value: f64) -> bool {
        if !value.is_finite() {
            return false;
        }
        let next = value.clamp(self.min, self.max);
        let changed = next != self.value;
        self.value = next;
        changed
    }
    pub fn increment(&mut self, up: bool) -> bool {
        self.set(self.value + if up { self.step } else { -self.step })
    }
}
/// Semantic field metadata, separate from the input's editing model.
#[derive(Clone, Debug, Default)]
pub struct Field {
    pub label: String,
    pub help: String,
    pub error: Option<String>,
    pub required: bool,
}
impl Field {
    pub fn message(&self) -> &str {
        self.error.as_deref().unwrap_or(&self.help)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn button_release_contract_and_disabled_loading() {
        let mut b = Button::default();
        b.pointer_down();
        assert!(!b.pointer_up(false));
        b.pointer_down();
        assert!(b.pointer_up(true));
        assert!(!b.pointer_up(true));
        b.state.focused = true;
        assert!(!b.key(ControlKey::Space, true));
        assert!(b.key(ControlKey::Space, false));
        for loading in [false, true] {
            b.state.loading = loading;
            b.state.disabled = !loading;
            b.pointer_down();
            assert!(!b.pointer_up(true));
            assert!(!b.key(ControlKey::Enter, true));
        }
    }
    #[test]
    fn mixed_checkbox_and_disabled_combination() {
        let mut c = Checkbox {
            checked: CheckState::Mixed,
            ..Default::default()
        };
        assert!(c.toggle());
        assert_eq!(c.checked, CheckState::Checked);
        c.button.state.disabled = true;
        assert!(!c.toggle());
        assert_eq!(c.checked, CheckState::Checked);
    }
    #[test]
    fn tab_menu_boundaries_and_escape() {
        let mut t = Tabs::new(3);
        t.key(ControlKey::Left);
        assert_eq!(t.selected, 2);
        t.key(ControlKey::Home);
        assert_eq!(t.selected, 0);
        let mut m = Menu::new(3);
        m.show();
        m.key(ControlKey::Down);
        assert_eq!(m.key(ControlKey::Enter), Some(1));
        assert!(!m.open);
        m.show();
        m.key(ControlKey::Escape);
        assert!(!m.open);
        assert!(!Tabs::new(0).key(ControlKey::End));
    }
    #[test]
    fn modal_traps_focus_and_restores_invoker() {
        let mut d = Dialog::default();
        d.show(7);
        d.tab(true, 2);
        assert_eq!(d.focus, 1);
        d.tab(false, 2);
        assert_eq!(d.focus, 0);
        assert_eq!(d.close(), Some(7));
        assert_eq!(d.close(), None);
    }
    #[test]
    fn numeric_clamps_and_rejects_invalid_values() {
        assert!(NumberField::new(0., 1., 0., 1.).is_none());
        let mut n = NumberField::new(99., 0., 10., 1.).unwrap();
        assert_eq!(n.value(), 10.);
        assert!(!n.increment(true));
        assert!(n.increment(false));
        assert!(!n.set(f64::NAN));
        assert_eq!(n.value(), 9.);
    }
}
/// Toolbar geometry is shared by clients; narrow bounds wrap rather than overflow.
#[derive(Clone, Copy, Debug, Default)]
pub struct Toolbar;
impl Toolbar {
    pub fn layout(
        bounds: tekes_ui_scene::Rect,
        count: usize,
        gap: f32,
    ) -> Vec<tekes_ui_scene::Rect> {
        if count == 0 {
            return Vec::new();
        }
        let width = ((bounds.size.width - gap * (count - 1) as f32) / count as f32).max(0.);
        (0..count)
            .map(|i| {
                tekes_ui_scene::Rect::new(
                    bounds.min_x() + i as f32 * (width + gap),
                    bounds.min_y(),
                    width,
                    bounds.size.height,
                )
            })
            .collect()
    }
}
