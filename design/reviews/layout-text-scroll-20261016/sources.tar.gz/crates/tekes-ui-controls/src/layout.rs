//! Shared, immutable container and scroll geometry snapshots.
//!
//! These helpers keep layout, clipping, and pointer conversion on the same
//! logical-pixel rectangles. They describe geometry only; content realization
//! and scheduling remain the responsibility of their consumers.
use tekes_ui_scene::{Point, Rect, Size};

/// Insets applied to each edge of a container, in logical points.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Insets {
    pub top: f32,
    pub right: f32,
    pub bottom: f32,
    pub left: f32,
}

impl Insets {
    pub const ZERO: Self = Self {
        top: 0.0,
        right: 0.0,
        bottom: 0.0,
        left: 0.0,
    };

    pub const fn new(top: f32, right: f32, bottom: f32, left: f32) -> Self {
        Self {
            top,
            right,
            bottom,
            left,
        }
    }

    fn normalized(self) -> Self {
        Self {
            top: finite_nonnegative(self.top),
            right: finite_nonnegative(self.right),
            bottom: finite_nonnegative(self.bottom),
            left: finite_nonnegative(self.left),
        }
    }
}

/// A normalized container frame, its inner content rectangle, and its
/// effective ancestor-clipped region.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ContainerLayout {
    frame: Rect,
    content: Rect,
    ancestor_clip: Option<Rect>,
    visible_clip: Option<Rect>,
}

impl ContainerLayout {
    /// Insets are applied in order: frame border first, then content padding.
    /// Each side consumes only the space remaining on that side, so excessive
    /// or non-finite values collapse safely to an empty rectangle.
    pub fn new(frame: Rect, border: Insets, content: Insets, ancestor_clip: Option<Rect>) -> Self {
        let frame = normalized_rect(frame);
        let border = border.normalized();
        let content_insets = content.normalized();
        let ancestor_clip = ancestor_clip.map(normalized_rect);
        let bordered = inset_edges(frame, border);
        let content = inset_edges(bordered, content_insets);
        let visible_clip = match ancestor_clip {
            Some(clip) => content.intersection(&clip),
            None if !content.is_empty() => Some(content),
            None => None,
        };
        Self {
            frame,
            content,
            ancestor_clip,
            visible_clip,
        }
    }

    pub const fn frame(&self) -> Rect {
        self.frame
    }

    pub const fn content(&self) -> Rect {
        self.content
    }

    pub const fn ancestor_clip(&self) -> Option<Rect> {
        self.ancestor_clip
    }

    pub const fn visible_clip(&self) -> Option<Rect> {
        self.visible_clip
    }
}

/// A coherent scroll transform for one layout pass.
///
/// `viewport` and `ancestor_clip` are in the same parent coordinate space;
/// document coordinates start at `(0, 0)`. Normal offset is clamped to the
/// document's scrollable range, while elastic displacement remains separate.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ScrollGeometry {
    viewport: Rect,
    document_bounds: Rect,
    normal_offset: Point,
    overscroll: Point,
    visible_viewport_rect: Option<Rect>,
    visible_document_rect: Option<Rect>,
}

impl ScrollGeometry {
    pub fn new(
        viewport: Rect,
        document_extent: Size,
        offset: Point,
        overscroll: Point,
        ancestor_clip: Option<Rect>,
    ) -> Self {
        let viewport = normalized_rect(viewport);
        let document = Size::new(
            finite_nonnegative(document_extent.width),
            finite_nonnegative(document_extent.height),
        );
        let document_bounds = Rect::new(0.0, 0.0, document.width, document.height);
        let normal_offset = Point::new(
            finite_or_zero(offset.x).clamp(0.0, (document.width - viewport.size.width).max(0.0)),
            finite_or_zero(offset.y).clamp(0.0, (document.height - viewport.size.height).max(0.0)),
        );
        let overscroll = Point::new(finite_or_zero(overscroll.x), finite_or_zero(overscroll.y));
        let effective_clip = match ancestor_clip.map(normalized_rect) {
            Some(clip) => viewport.intersection(&clip),
            None if !viewport.is_empty() => Some(viewport),
            None => None,
        };
        let visible_document_rect = effective_clip.and_then(|visible| {
            let origin = Point::new(
                viewport.origin.x - normal_offset.x - overscroll.x,
                viewport.origin.y - normal_offset.y - overscroll.y,
            );
            let visible_in_document = Rect::new(
                visible.origin.x - origin.x,
                visible.origin.y - origin.y,
                visible.size.width,
                visible.size.height,
            );
            visible_in_document.intersection(&document_bounds)
        });
        Self {
            viewport,
            document_bounds,
            normal_offset,
            overscroll,
            visible_viewport_rect: effective_clip,
            visible_document_rect,
        }
    }

    pub const fn viewport(&self) -> Rect {
        self.viewport
    }

    pub const fn document_bounds(&self) -> Rect {
        self.document_bounds
    }

    pub const fn normal_offset(&self) -> Point {
        self.normal_offset
    }

    pub const fn overscroll(&self) -> Point {
        self.overscroll
    }

    pub const fn visual_offset(&self) -> Point {
        Point::new(
            self.normal_offset.x + self.overscroll.x,
            self.normal_offset.y + self.overscroll.y,
        )
    }

    /// Document origin in the viewport's parent coordinate space.
    pub const fn content_origin(&self) -> Point {
        Point::new(
            self.viewport.origin.x - self.visual_offset().x,
            self.viewport.origin.y - self.visual_offset().y,
        )
    }

    pub const fn visible_viewport_rect(&self) -> Option<Rect> {
        self.visible_viewport_rect
    }

    /// Visible document content. Elastic blank space is excluded by
    /// intersecting the transformed viewport with the finite document bounds.
    pub const fn visible_document_rect(&self) -> Option<Rect> {
        self.visible_document_rect
    }

    /// Convert a point in parent coordinates into document coordinates.
    /// Points outside the effective viewport, in ancestor-clipped regions, or
    /// in elastic blank space do not hit document content.
    pub fn viewport_to_document(&self, point: Point) -> Option<Point> {
        let visible = self.visible_viewport_rect?;
        if !point_is_finite(point) || !visible.contains(point) {
            return None;
        }
        let origin = self.content_origin();
        let document_point = Point::new(point.x - origin.x, point.y - origin.y);
        self.document_bounds
            .contains(document_point)
            .then_some(document_point)
    }

    /// Convert a document rectangle into parent coordinates and clip it to
    /// the effective viewport. Empty or fully clipped content returns `None`.
    pub fn document_to_viewport(&self, rect: Rect) -> Option<Rect> {
        let rect = normalized_rect(rect);
        let rect = rect.intersection(&self.document_bounds)?;
        let origin = self.content_origin();
        let transformed = rect.offset(origin.x, origin.y);
        transformed.intersection(&self.visible_viewport_rect?)
    }
}

fn finite_or_zero(value: f32) -> f32 {
    if value.is_finite() { value } else { 0.0 }
}

fn finite_nonnegative(value: f32) -> f32 {
    finite_or_zero(value).max(0.0)
}

fn normalized_rect(rect: Rect) -> Rect {
    if !rect.origin.x.is_finite() || !rect.origin.y.is_finite() {
        return Rect::default();
    }
    Rect::new(
        rect.origin.x,
        rect.origin.y,
        finite_nonnegative(rect.size.width),
        finite_nonnegative(rect.size.height),
    )
}

fn inset_edges(rect: Rect, insets: Insets) -> Rect {
    let left = insets.left.min(rect.size.width);
    let right = insets.right.min(rect.size.width - left);
    let top = insets.top.min(rect.size.height);
    let bottom = insets.bottom.min(rect.size.height - top);
    Rect::new(
        rect.origin.x + left,
        rect.origin.y + top,
        rect.size.width - left - right,
        rect.size.height - top - bottom,
    )
}

fn point_is_finite(point: Point) -> bool {
    point.x.is_finite() && point.y.is_finite()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn container_insets_are_applied_once_and_clip_to_ancestor() {
        let layout = ContainerLayout::new(
            Rect::new(10.0, 20.0, 200.0, 100.0),
            Insets::new(1.0, 2.0, 3.0, 4.0),
            Insets::new(5.0, 6.0, 7.0, 8.0),
            Some(Rect::new(30.0, 30.0, 150.0, 60.0)),
        );
        assert_eq!(layout.frame(), Rect::new(10.0, 20.0, 200.0, 100.0));
        assert_eq!(layout.content(), Rect::new(22.0, 26.0, 180.0, 84.0));
        assert_eq!(
            layout.ancestor_clip(),
            Some(Rect::new(30.0, 30.0, 150.0, 60.0))
        );
        assert_eq!(
            layout.visible_clip(),
            Some(Rect::new(30.0, 30.0, 150.0, 60.0))
        );
    }

    #[test]
    fn nested_clip_and_bounce_share_the_same_forward_and_reverse_transform() {
        let geometry = ScrollGeometry::new(
            Rect::new(20.0, 30.0, 100.0, 80.0),
            Size::new(200.0, 240.0),
            Point::new(40.0, 50.0),
            Point::new(0.0, -12.0),
            Some(Rect::new(30.0, 40.0, 70.0, 55.0)),
        );
        assert_eq!(geometry.content_origin(), Point::new(-20.0, -8.0));
        assert_eq!(
            geometry.visible_viewport_rect(),
            Some(Rect::new(30.0, 40.0, 70.0, 55.0))
        );
        assert_eq!(
            geometry.visible_document_rect(),
            Some(Rect::new(50.0, 48.0, 70.0, 55.0))
        );
        let point = Point::new(42.0, 52.0);
        let doc = geometry.viewport_to_document(point).unwrap();
        assert_eq!(doc, Point::new(62.0, 60.0));
        assert_eq!(
            geometry.document_to_viewport(Rect::new(doc.x, doc.y, 4.0, 4.0)),
            Some(Rect::new(point.x, point.y, 4.0, 4.0))
        );
    }

    #[test]
    fn normal_offset_clamps_after_resize_and_bounce_blank_has_no_hit() {
        let geometry = ScrollGeometry::new(
            Rect::new(0.0, 0.0, 100.0, 80.0),
            Size::new(90.0, 120.0),
            Point::new(30.0, 50.0),
            Point::new(0.0, 14.0),
            None,
        );
        assert_eq!(geometry.normal_offset(), Point::new(0.0, 40.0));
        assert_eq!(
            geometry.visible_document_rect(),
            Some(Rect::new(0.0, 54.0, 90.0, 66.0))
        );
        assert_eq!(geometry.viewport_to_document(Point::new(50.0, 79.0)), None);
    }

    #[test]
    fn zero_nonfinite_and_empty_geometry_is_safe() {
        let container = ContainerLayout::new(
            Rect::new(f32::NAN, 2.0, -4.0, f32::INFINITY),
            Insets::new(f32::NAN, -1.0, 0.0, 0.0),
            Insets::ZERO,
            None,
        );
        assert_eq!(container.frame(), Rect::default());
        assert_eq!(container.visible_clip(), None);
        let geometry = ScrollGeometry::new(
            Rect::new(4.0, 5.0, 0.0, 10.0),
            Size::new(f32::NAN, 40.0),
            Point::new(f32::INFINITY, 8.0),
            Point::new(0.0, f32::NAN),
            None,
        );
        assert_eq!(geometry.normal_offset(), Point::new(0.0, 8.0));
        assert_eq!(geometry.visible_viewport_rect(), None);
        assert_eq!(geometry.visible_document_rect(), None);
        assert_eq!(geometry.viewport_to_document(Point::new(4.0, 5.0)), None);
        let invalid_origin = ContainerLayout::new(
            Rect::new(f32::INFINITY, 5.0, 20.0, 20.0),
            Insets::ZERO,
            Insets::ZERO,
            None,
        );
        assert_eq!(invalid_origin.content(), Rect::default());
        assert_eq!(invalid_origin.visible_clip(), None);
    }

    #[test]
    fn document_render_mapping_rejects_content_outside_extent() {
        let geometry = ScrollGeometry::new(
            Rect::new(0.0, 0.0, 100.0, 100.0),
            Size::new(60.0, 80.0),
            Point::default(),
            Point::default(),
            None,
        );
        assert_eq!(
            geometry.document_to_viewport(Rect::new(60.0, 10.0, 10.0, 10.0)),
            None
        );
        assert_eq!(
            geometry.document_to_viewport(Rect::new(55.0, 10.0, 10.0, 10.0)),
            Some(Rect::new(55.0, 10.0, 5.0, 10.0))
        );
    }
}
