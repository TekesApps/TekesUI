//! Shared token-driven control geometry; clients supply text shaping via their adapter.
use crate::{CheckState, ControlState};
use tekes_ui_scene::{Quad, Rect, Scene};
use tekes_ui_tokens::{Palette, Rgba, proposal};

/// Semantic surface roles mapped directly to the JSON Design System tokens.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SurfaceKind {
    Canvas,
    Panel,
    Floating,
    Dialog,
    Code,
}

pub fn color(theme: impl Into<Palette>, role: &str) -> Rgba {
    theme.into().color(role).expect("semantic control role")
}
pub fn surface(scene: &mut Scene, rect: Rect, theme: impl Into<Palette>, panel: bool) {
    surface_at_scale(scene, rect, theme, panel, 1.0);
}

/// Paints a Surface/Panel at the renderer's backing scale. Decorative panel
/// boundaries follow the JSON hairline policy; the legacy `surface` API uses
/// a 1x backing scale for source compatibility.
pub fn surface_at_scale(
    scene: &mut Scene,
    rect: Rect,
    theme: impl Into<Palette>,
    panel: bool,
    backing_scale: f32,
) {
    surface_kind_at_scale(
        scene,
        rect,
        theme,
        if panel {
            SurfaceKind::Panel
        } else {
            SurfaceKind::Canvas
        },
        backing_scale,
    );
}

/// Paint a semantic surface role using existing color, radius and boundary
/// tokens. All non-canvas roles retain a boundary; its width follows the
/// decorative hairline policy at the host backing scale.
pub fn surface_kind_at_scale(
    scene: &mut Scene,
    rect: Rect,
    theme: impl Into<Palette>,
    kind: SurfaceKind,
    backing_scale: f32,
) {
    let theme = theme.into();
    let (fill, radius, boundary) = match kind {
        SurfaceKind::Canvas => ("surface-1", "radius-panel", false),
        SurfaceKind::Panel => ("surface-panel", "radius-panel", true),
        SurfaceKind::Floating => ("surface-popover", "radius-floating", true),
        SurfaceKind::Dialog => ("surface-popover", "c-dialog-radius", true),
        SurfaceKind::Code => ("code-surface", "c-code-radius", true),
    };
    let mut q = Quad::new(rect, color(theme, fill))
        .with_corner_radius(proposal::metric("radius", radius).expect("surface radius"));
    if boundary {
        let (width, ink) = decorative_border(theme, backing_scale);
        q = q.with_border(width, ink);
    }
    scene.push_quad(q);
}
/// Decorative frame, following layout.json hairline policy. Never use this
/// for a necessary control boundary or a focus/selection indicator.
pub fn decorative_border(theme: impl Into<Palette>, backing_scale: f32) -> (f32, Rgba) {
    let theme = theme.into();
    let width = if theme.theme.contrast == tekes_ui_tokens::Contrast::Increased {
        proposal::metric("stroke", "stroke-rule").expect("contrast stroke")
    } else {
        1.0 / if backing_scale.is_finite() && backing_scale > 0.0 {
            backing_scale
        } else {
            1.0
        }
    };
    (width, color(theme, "separator"))
}
/// Independent keyboard/editing focus ring. The quad shader draws borders
/// inward, so expand by offset + width to retain the full visible gap. Hosts
/// keep their ancestor viewport clip; this never changes layout or hit targets.
pub fn focus_ring(scene: &mut Scene, rect: Rect, theme: impl Into<Palette>, radius: f32) {
    let theme = theme.into();
    let width = proposal::metric("stroke", "c-focus-width").expect("focus width");
    let gap = proposal::metric("spacing", "c-focus-offset").expect("focus offset");
    let outset = gap + width;
    scene.push_quad(
        Quad::new(rect.inset(-outset), Rgba::new(0., 0., 0., 0.))
            .with_corner_radius(radius + outset)
            .with_border(width, color(theme, "border-focused")),
    );
}

pub fn button(
    scene: &mut Scene,
    rect: Rect,
    theme: impl Into<Palette>,
    state: ControlState,
) -> Rgba {
    button_with_radius(
        scene,
        rect,
        theme.into(),
        state,
        proposal::metric("radius", "c-button-md-radius").expect("button radius"),
    )
}
fn button_with_radius(
    scene: &mut Scene,
    rect: Rect,
    theme: Palette,
    state: ControlState,
    radius: f32,
) -> Rgba {
    let fill = if state.disabled {
        "surface-2"
    } else if state.selected {
        if state.hovered {
            "row-selection-hover"
        } else {
            "row-selection"
        }
    } else if state.pressed {
        "button-pressed"
    } else if state.hovered {
        "button-hover"
    } else {
        "surface-2"
    };
    let border = if state.error {
        "status-failed"
    } else {
        "border"
    };
    scene.push_quad(
        Quad::new(rect, color(theme, fill))
            .with_corner_radius(radius)
            .with_border(
                proposal::metric("stroke", "stroke-rule").expect("control stroke"),
                theme
                    .color(border)
                    .unwrap_or_else(|| color(theme, "border")),
            ),
    );
    if state.focused && state.focus_visible && !state.disabled {
        focus_ring(scene, rect, theme, radius);
    }
    color(
        theme,
        if state.disabled {
            "tertiary-text"
        } else {
            "primary-text"
        },
    )
}
pub fn checkbox(
    scene: &mut Scene,
    rect: Rect,
    theme: impl Into<Palette>,
    state: ControlState,
    checked: CheckState,
) -> Rgba {
    let theme = theme.into();
    let checked_ink = checked != CheckState::Unchecked && !state.disabled;
    let fill = if state.disabled {
        "surface-2"
    } else if checked_ink {
        if state.pressed {
            "control-checked-pressed"
        } else if state.hovered {
            "control-checked-hover"
        } else {
            "control-checked-ground"
        }
    } else if state.selected {
        if state.hovered {
            "row-selection-hover"
        } else {
            "row-selection"
        }
    } else if state.pressed {
        "button-pressed"
    } else if state.hovered {
        "button-hover"
    } else {
        "surface-2"
    };
    let border = if state.error {
        "status-failed"
    } else {
        "border"
    };
    let radius = proposal::metric("radius", "c-checkbox-radius").expect("checkbox radius");
    let ink = color(
        theme,
        if checked_ink {
            "control-checked-mark"
        } else if state.disabled {
            "tertiary-text"
        } else {
            "primary-text"
        },
    );
    scene.push_quad(
        Quad::new(rect, color(theme, fill))
            .with_corner_radius(radius)
            .with_border(
                proposal::metric("stroke", "stroke-rule").expect("checkbox stroke"),
                color(theme, border),
            ),
    );
    if checked == CheckState::Mixed {
        scene.push_quad(
            Quad::new(
                Rect::new(
                    rect.min_x() + 4.,
                    rect.center().y - 1.,
                    rect.size.width - 8.,
                    2.,
                ),
                ink,
            )
            .with_corner_radius(1.),
        );
    } else if checked == CheckState::Checked {
        let stroke = proposal::metric("size", "size-icon-artboard-stroke").expect("icon stroke");
        for (a, b) in [((0.20, 0.50), (0.42, 0.72)), ((0.42, 0.72), (0.80, 0.28))] {
            let ax = rect.min_x() + rect.size.width * a.0;
            let ay = rect.min_y() + rect.size.height * a.1;
            let dx = rect.size.width * (b.0 - a.0);
            let dy = rect.size.height * (b.1 - a.1);
            let steps = dx.abs().max(dy.abs()).ceil().max(1.) as usize;
            for n in 0..=steps {
                let t = n as f32 / steps as f32;
                scene.push_quad(
                    Quad::new(Rect::new(ax + dx * t, ay + dy * t, stroke, stroke), ink)
                        .with_corner_radius(stroke / 2.),
                );
            }
        }
    }

    if state.focused && state.focus_visible && !state.disabled {
        focus_ring(scene, rect, theme, radius);
    }
    ink
}
pub fn skeleton(scene: &mut Scene, rect: Rect, theme: impl Into<Palette>) {
    scene.push_quad(Quad::new(rect, color(theme, "surface-2")).with_corner_radius(4.));
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum ButtonVariant {
    #[default]
    Quiet,
    Primary,
    /// Quiet action whose resting surface inherits its parent panel.
    Panel,
}
pub fn button_variant(
    scene: &mut Scene,
    rect: Rect,
    theme: impl Into<Palette>,
    state: ControlState,
    variant: ButtonVariant,
) -> Rgba {
    button_variant_with_radius(
        scene,
        rect,
        theme.into(),
        state,
        variant,
        proposal::metric("radius", "c-button-md-radius").expect("button radius"),
    )
}
/// Size-aware production Button paint; legacy painters retain their md radius.
pub fn button_variant_with_radius(
    scene: &mut Scene,
    rect: Rect,
    theme: Palette,
    state: ControlState,
    variant: ButtonVariant,
    radius: f32,
) -> Rgba {
    if variant == ButtonVariant::Panel {
        let fill = if state.disabled {
            "surface-2"
        } else if state.pressed {
            "button-pressed"
        } else if state.selected {
            if state.hovered {
                "row-selection-hover"
            } else {
                "row-selection"
            }
        } else if state.hovered {
            "button-hover"
        } else {
            "surface-panel"
        };
        let border = if state.error {
            "status-failed"
        } else {
            "border"
        };
        scene.push_quad(
            Quad::new(rect, color(theme, fill))
                .with_corner_radius(radius)
                .with_border(
                    proposal::metric("stroke", "stroke-rule").expect("control stroke"),
                    theme
                        .color(border)
                        .unwrap_or_else(|| color(theme, "border")),
                ),
        );
        if state.focused && state.focus_visible && !state.disabled {
            focus_ring(scene, rect, theme, radius);
        }
        return color(
            theme,
            if state.disabled {
                "tertiary-text"
            } else {
                "primary-text"
            },
        );
    }
    if variant == ButtonVariant::Quiet || state.disabled {
        return button_with_radius(scene, rect, theme, state, radius);
    }
    let role = if state.pressed {
        "action-primary-pressed"
    } else if state.hovered {
        "action-primary-hover"
    } else {
        "action-primary-ground"
    };
    let ring = role;
    scene.push_quad(
        Quad::new(rect, color(theme, role))
            .with_corner_radius(radius)
            .with_border(
                proposal::metric("stroke", "stroke-rule").expect("control stroke"),
                color(theme, ring),
            ),
    );
    if state.focused && state.focus_visible && !state.disabled {
        focus_ring(scene, rect, theme, radius);
    }
    color(theme, "action-primary-foreground")
}

#[cfg(test)]
mod boundary_tests {
    use super::*;
    use tekes_ui_tokens::{Contrast, Theme};
    #[test]
    fn decorative_frames_follow_scale_and_contrast_without_weakening_controls() {
        for theme in Theme::ALL {
            for scale in [1., 2.] {
                let (width, ink) = decorative_border(theme, scale);
                assert_eq!(
                    width,
                    if theme.contrast == Contrast::Increased {
                        1.
                    } else {
                        1. / scale
                    }
                );
                assert_eq!(ink, color(theme, "separator"));
                let mut scene = Scene::new();
                button(
                    &mut scene,
                    Rect::new(0., 0., 100., 32.),
                    theme,
                    ControlState::default(),
                );
                let tekes_ui_scene::Primitive::Quad(q) = &scene.primitives()[0] else {
                    panic!("control quad")
                };
                assert_eq!(
                    q.border_width,
                    proposal::metric("stroke", "stroke-rule").unwrap()
                );
                assert_eq!(q.border_color, color(theme, "border"));
            }
        }
    }

    #[test]
    fn checkbox_base_and_marked_states_share_the_component_square_radius() {
        let frame = Rect::new(4.0, 6.0, 16.0, 16.0);
        let states = [
            (ControlState::default(), CheckState::Unchecked),
            (ControlState::default(), CheckState::Checked),
            (
                ControlState {
                    hovered: true,
                    pressed: true,
                    ..Default::default()
                },
                CheckState::Mixed,
            ),
            (
                ControlState {
                    disabled: true,
                    ..Default::default()
                },
                CheckState::Unchecked,
            ),
            (
                ControlState {
                    disabled: true,
                    focused: true,
                    focus_visible: true,
                    ..Default::default()
                },
                CheckState::Checked,
            ),
        ];
        let radius = proposal::metric("radius", "c-checkbox-radius").unwrap();
        assert_eq!(radius, 4.0);
        assert!(radius < frame.size.width.min(frame.size.height) * 0.5);

        for theme in Theme::ALL {
            for (state, checked) in states {
                let mut scene = Scene::new();
                checkbox(&mut scene, frame, theme, state, checked);
                let tekes_ui_scene::Primitive::Quad(outline) = &scene.primitives()[0] else {
                    panic!("checkbox outline")
                };
                assert_eq!(outline.rect, frame);
                assert_eq!(
                    outline.corner_radii,
                    tekes_ui_scene::CornerRadii::uniform(radius),
                    "outer shape must not change for {checked:?} / {state:?} / {theme:?}"
                );
            }
        }
    }

    #[test]
    fn panel_surface_uses_panel_token_and_scale_aware_decorative_boundary() {
        for theme in Theme::ALL {
            for scale in [1.0, 2.0] {
                let panel_rect = Rect::new(2.0, 3.0, 120.0, 64.0);
                let mut panel_scene = Scene::new();
                surface_at_scale(&mut panel_scene, panel_rect, theme, true, scale);
                let tekes_ui_scene::Primitive::Quad(panel) = &panel_scene.primitives()[0] else {
                    panic!("panel surface quad")
                };
                let (width, ink) = decorative_border(theme, scale);
                assert_eq!(panel.rect, panel_rect);
                assert_eq!(panel.fill, color(theme, "surface-panel"));
                assert_eq!(panel.border_color, ink);
                assert_eq!(panel.border_width, width);

                let mut surface_scene = Scene::new();
                surface_at_scale(&mut surface_scene, panel_rect, theme, false, scale);
                let tekes_ui_scene::Primitive::Quad(surface) = &surface_scene.primitives()[0]
                else {
                    panic!("surface quad")
                };
                assert_eq!(surface.rect, panel_rect);
                assert_eq!(surface.fill, color(theme, "surface-1"));
                assert_eq!(surface.border_width, 0.0);
            }
        }
    }

    #[test]
    fn semantic_surface_roles_use_existing_fill_radius_and_hairline_tokens() {
        let cases = [
            (SurfaceKind::Canvas, "surface-1", "radius-panel", false),
            (SurfaceKind::Panel, "surface-panel", "radius-panel", true),
            (
                SurfaceKind::Floating,
                "surface-popover",
                "radius-floating",
                true,
            ),
            (
                SurfaceKind::Dialog,
                "surface-popover",
                "c-dialog-radius",
                true,
            ),
            (SurfaceKind::Code, "code-surface", "c-code-radius", true),
        ];
        for theme in Theme::ALL {
            for scale in [1.0, 2.0] {
                for (kind, fill, radius, bordered) in cases {
                    let frame = Rect::new(10.0, 20.0, 180.0, 90.0);
                    let mut scene = Scene::new();
                    surface_kind_at_scale(&mut scene, frame, theme, kind, scale);
                    let tekes_ui_scene::Primitive::Quad(q) = &scene.primitives()[0] else {
                        panic!("semantic surface quad")
                    };
                    assert_eq!(q.rect, frame);
                    assert_eq!(q.fill, color(theme, fill));
                    assert_eq!(
                        q.corner_radii,
                        tekes_ui_scene::CornerRadii::uniform(
                            proposal::metric("radius", radius).expect("radius token"),
                        )
                    );
                    if bordered {
                        assert_eq!(q.border_color, color(theme, "separator"));
                        assert_eq!(q.border_width, decorative_border(theme, scale).0);
                    } else {
                        assert_eq!(q.border_width, 0.0);
                    }
                }
            }
        }
    }
}

#[cfg(test)]
mod focus_tests {
    use super::*;
    use tekes_ui_scene::Primitive;
    use tekes_ui_tokens::Theme;

    #[test]
    fn focus_is_an_independent_two_point_ring_with_two_point_visible_gap() {
        for theme in Theme::ALL {
            for brand in [0, 1, 2] {
                for scale in [1.0, 2.0] {
                    let palette = Palette { theme, brand };
                    let frame = Rect::new(20.25, 22.5, 120., 36.);
                    let mut scene = Scene::new();
                    button(
                        &mut scene,
                        frame,
                        palette,
                        ControlState {
                            focused: true,
                            focus_visible: true,
                            error: true,
                            ..Default::default()
                        },
                    );
                    let quads = scene
                        .primitives()
                        .iter()
                        .filter_map(|p| match p {
                            Primitive::Quad(q) => Some(q),
                            _ => None,
                        })
                        .collect::<Vec<_>>();
                    assert_eq!(quads.len(), 2);
                    assert_eq!(quads[0].rect, frame);
                    assert_eq!(quads[0].border_color, color(palette, "status-failed"));
                    let ring = quads[1];
                    assert_eq!(ring.fill.a, 0.);
                    assert_eq!(ring.rect, frame.inset(-4.));
                    assert_eq!(ring.border_width * scale, 2. * scale);
                    assert_eq!(frame.min_x() - (ring.rect.min_x() + ring.border_width), 2.);
                    assert_eq!(ring.border_color, color(palette, "border-focused"));
                }
            }
        }
    }

    #[test]
    fn disabled_controls_do_not_paint_keyboard_focus() {
        for variant in [
            ButtonVariant::Quiet,
            ButtonVariant::Primary,
            ButtonVariant::Panel,
        ] {
            let mut scene = Scene::new();
            button_variant(
                &mut scene,
                Rect::new(0., 0., 80., 32.),
                Theme::LIGHT,
                ControlState {
                    focused: true,
                    focus_visible: true,
                    disabled: true,
                    ..Default::default()
                },
                variant,
            );
            assert_eq!(scene.primitives().len(), 1);
        }
    }
}
